"""Session-only input observations. Flags are descriptive, never verdicts."""
from collections import deque
from datetime import datetime
from time import monotonic
from fair_files import inspect


class InputReview:
    def __init__(self):
        self.started = monotonic()
        self.events = deque(maxlen=240)
        self.guards = deque(maxlen=20)
        self.pending = False
        self.route_seen = False
        self.reset_route()

    def record(self, description):
        self.events.append(f"{monotonic()-self.started:8.3f}秒  {description}")

    def export(self, folder, built):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        path = folder / f"戦闘記録_{stamp}.txt"
        lines = ["Ashvale III 戦闘記録", self.report(), "ゲームファイルの照合",
                 *inspect(folder, built), "直近240件（冒険開始からの経過時間）",
                 *self.events]
        path.write_text("\n".join(lines), encoding="utf-8-sig")
        return path

    def reset_route(self):
        self.legs = deque(maxlen=12)
        self.direction = None
        self.elapsed = 0.0

    def press(self):
        self.record("ガード受付")
        self.guards.append(None)
        self.pending = True

    def success(self, offset):
        if self.pending:
            self.record(f"ガード成功  命中に対する入力 {offset*1000:+.0f} ms（負は命中前）")
            self.guards[-1] = offset
            self.pending = False

    def move(self, direction, dt):
        if direction != self.direction:
            if self.direction and self.direction != (0, 0) and self.elapsed >= .12:
                self.legs.append((self.direction, self.elapsed))
                if len(self.legs) == 12:
                    legs = list(self.legs)
                    if len({leg[0] for leg in legs[:4]}) >= 3 and all(
                        a == b and abs(t - u) <= .035
                        for (a, t), (b, u) in zip(legs, legs[4:])
                    ):
                        if not self.route_seen:
                            self.record("移動入力の反復を観測")
                        self.route_seen = True
            if self.direction == (0, 0) and self.elapsed > .5:
                self.legs.clear()
            self.direction = direction
            self.elapsed = 0.0
        self.elapsed += dt

    def report(self):
        offsets = sorted(x for x in self.guards if x is not None)
        cluster = max((sum(0 <= y-x <= .035 for y in offsets) for x in offsets), default=0)
        guard = "同じタイミングが続いています" if len(self.guards) >= 16 and cluster >= .9*len(self.guards) else "観測中"
        route = "同じ移動入力の反復あり" if self.route_seen else "移動の反復なし"
        return f"ガード {len(offsets)}/{len(self.guards)}成功・{guard}　{route}"
