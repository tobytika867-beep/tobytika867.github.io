@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>&1
if errorlevel 1 (
    echo Python Launcher was not found. Install Python only on this build PC, then try again.
    pause
    exit /b 1
)

echo Installing the packaging tools on this build PC...
py -3 -m pip install --upgrade pygame pyinstaller
if errorlevel 1 goto :failed

echo Building the standalone Windows game...
py -3 -m PyInstaller --noconfirm --clean --windowed --onedir --name AshvaleIII --add-data "assets;assets" legend_of_ashvale.py
if errorlevel 1 goto :failed

py -3 fair_files.py dist\AshvaleIII --exe
if errorlevel 1 goto :failed

powershell -NoProfile -Command "Compress-Archive -Path dist\AshvaleIII\* -DestinationPath AshvaleIII_Windows.zip -Force"
if errorlevel 1 goto :failed

echo.
echo Finished. Run dist\AshvaleIII\AshvaleIII.exe
echo Share AshvaleIII_Windows.zip with players who do not have Python.
echo The game players do not need Python installed.
pause
exit /b 0

:failed
echo.
echo Build failed. Check the error message above.
pause
exit /b 1
