"""Short local patrols: walk to the end of a clear lane, pause, and return."""
from dataclasses import dataclass
from math import dist

RUNNERS={"急使","トウマ"}

@dataclass
class Patrol:
    origin: tuple
    end: tuple
    pace: float
    length: float=0
    distance: float=0
    returning: bool=False
    rest: float=0
    step: float=0
    pose: int=0

    @property
    def position(self):
        dx,dy=self.end
        return (round(self.origin[0]+dx*self.distance),round(self.origin[1]+dy*self.distance))

    def tick(self,dt,player):
        self.pose=0
        if not self.length:
            return
        if self.rest>0:
            self.rest=max(0,self.rest-dt)
            return
        if dist(self.position,player)<44:
            return
        length=self.length
        self.distance=max(0,min(length,self.distance+dt*self.pace*(-1 if self.returning else 1)))
        self.step+=dt*self.pace
        self.pose=(1 if int(self.step/9)%2==0 else -1)*(2 if self.pace>65 else 1)
        if self.distance in (0,length):
            self.returning=not self.returning
            self.rest=1.25 if self.pace>65 else 2.8


def route(name,x,y,clear):
    seed=sum(map(ord,name))+x+y
    axes=((1,0),(-1,0),(0,1),(0,-1))
    order=axes[seed%4:]+axes[:seed%4]
    best=0
    heading=(0,0)
    runner=name in RUNNERS
    for dx,dy in order:
        for length in range(4,145 if runner else 89,4):
            if not clear(x+dx*length,y+dy*length):
                break
            if length>best:
                best,heading=length,(dx,dy)
    return Patrol((x,y),heading,86 if runner else 30+seed%13,rest=(seed%15)/10,length=best)
