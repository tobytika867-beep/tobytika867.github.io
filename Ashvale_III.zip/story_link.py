"""Host-owned campaign. The second PC sends controls and receives the shared camera."""
import math
import struct
import zlib
from time import monotonic

from stamp_notice import RejectedInput, show as show_stamp
from lan_duel import Room, INPUT, FACES

SIZE = (640, 480)
RAW = SIZE[0]*SIZE[1]*3
HEADER = struct.Struct("!I")


class StoryRoom(Room):
    read_size = 512 * 1024
    notice_packet = HEADER.pack(0)
    port = 41827
    query, advert, hello = b"Ashvale/Story?", b"Ashvale/Story!", b"ASST001!"
    def __init__(self):
        super().__init__()
        self.frame_at = self.input_at = 0
        self.last_frame = None
        self.buddy = None

    def flush(self):
        if self.tx:
            try:
                sent = self.peer.send(self.tx)
                del self.tx[:sent]
            except BlockingIOError:
                pass

    def poll(self):
        self.poll_connection()
        if self.mode != "playing":
            return
        self.flush()
        if not self.ready:
            return
        if self.is_host:
            while len(self.rx)>=INPUT.size:
                x,y,a,reserved = INPUT.unpack_from(self.rx)
                del self.rx[:INPUT.size]
                if abs(x)>1 or abs(y)>1 or a>3 or reserved:
                    self.reject_input()
                self.remote_dir = (x,y)
                self.remote_actions |= a
        else:
            while len(self.rx)>=4:
                n, = HEADER.unpack_from(self.rx)
                if n == 0:
                    raise RejectedInput
                if not 0<n<=RAW+1024:
                    raise ConnectionError
                if len(self.rx)<4+n:
                    break
                decoder = zlib.decompressobj()
                try:
                    data = decoder.decompress(self.rx[4:4+n],RAW+1)
                except zlib.error as exc:
                    raise ConnectionError from exc
                if len(data)!=RAW or not decoder.eof or decoder.unused_data:
                    raise ConnectionError
                self.last_frame = data
                del self.rx[:4+n]

    def send_frame(self, screen):
        import pygame as pg
        if self.ready and not self.tx and monotonic()>=self.frame_at:
            self.frame_at = monotonic()+1/24
            raw = pg.image.tostring(pg.transform.scale(screen,SIZE),"RGB")
            frame = zlib.compress(raw,1)
            self.tx.extend(HEADER.pack(len(frame))+frame)
            self.flush()

    def controls(self, direction, actions):
        self.actions |= actions
        if self.ready and not self.tx and monotonic()>=self.input_at:
            self.input_at = monotonic()+1/45
            self.tx.extend(INPUT.pack(*direction,self.actions,0))
            self.actions = 0
            self.flush()


class Companion:
    def __init__(self):
        self.location = self.body = None
        self.face = (0,1)
        self.walk = self.swing = self.cool = self.guard = self.guard_cd = 0.
        self.invulnerable = self.down = 0.
        self.hp = 5

    def hit(self,g,attacker):
        if self.down or self.invulnerable:
            return
        if self.guard:
            self.guard = self.guard_cd = 0
            if attacker is not None:
                attacker.stun = max(attacker.stun,.8)
            g.burst_effect("parry",*self.body.center,(249,220,117),12)
        else:
            self.hp -= 1
            if self.hp==0:
                self.down = 5.
        self.invulnerable = .75

    def update(self,g,dt,direction,action):
        import pygame as pg
        loc = g.location_key()
        if self.body is None or loc!=self.location or math.dist(g.player.center,self.body.center)>365:
            self.body = g.player.copy()
            for off in ((30,0),(-30,0),(0,30),(0,-30)):
                candidate = self.body.move(off)
                if not g.blocked(candidate):
                    self.body = candidate
                    break
            self.location = loc
        if any((g.game_over,g.ending_open,g.inventory_open,g.map_open,g.warp_open,g.seal_open,g.name_editing)):
            return
        for attr in ("cool","swing","guard","guard_cd","invulnerable"):
            setattr(self,attr,max(0,getattr(self,attr)-dt))
        if self.down:
            self.down=max(0,self.down-dt)
            if not self.down:
                self.body=g.player.copy()
                self.hp,self.invulnerable=5,1.
            return
        dx,dy=direction
        if dx or dy:
            self.face=direction
            self.walk+=dt
            step=190*dt/math.hypot(dx,dy)
            for off in ((round(dx*step),0),(0,round(dy*step))):
                r=self.body.move(off)
                sx,sy=g.to_screen_point(*r.center)
                if 14<=sx<=786 and 55<=sy<=582 and not g.blocked(r):
                    self.body=r
        if action&2 and not self.guard_cd:
            self.guard,self.guard_cd=.25,.8
        if action&1 and not self.cool:
            self.swing,self.cool=.19,.38
            start,end=self.blade()
            living=list(g.enemies)
            for e in living:
                if e.hp>0 and pg.Rect(round(e.x)-4,round(e.y)-4,33,33).clipline(start,end):
                    g.damage_enemy(e,2,*self.face)
            if living:
                g.enemies=[e for e in g.enemies if e.hp>0]
                if not g.enemies:
                    g.cleared_rooms.add(g.location_key())
                    if g.room is not None:
                        g.room_specials()
        for e in g.enemies:
            if e.hp>0 and not e.stun and self.body.colliderect(pg.Rect(round(e.x),round(e.y),24,24)):
                self.hit(g,e)
                break

    def blade(self):
        x,y=self.body.center
        dx,dy=self.face
        length=55/math.hypot(dx,dy)
        return (x,y),(round(x+dx*length),round(y+dy*length))

    def hazard(self,g,h,r):
        if self.body is None or self.location!=g.location_key() or h.get("guest_hit"):
            return
        dx,dy=self.body.centerx-h["x"],self.body.centery-h["y"]
        distance=abs(dx) if h["kind"]=="down" else abs(dy) if h["kind"]=="across" else math.hypot(dx,dy)
        if distance<=r:
            self.hit(g,h.get("attacker"))
            h["guest_hit"]=True

    def draw(self,g,screen,sprites,font):
        import pygame as pg
        if self.body is None or self.location!=g.location_key():
            return
        x,y=g.to_screen_point(*self.body.midbottom)
        direction=round(math.atan2(self.face[1],self.face[0])*4/math.pi)%8
        sprite=sprites[FACES[direction]][(0,1,2,1)[int(self.walk/.13)%4]]
        if not self.down:
            screen.blit(sprite,sprite.get_rect(midbottom=(x,y)))
            if self.swing:
                start,end=self.blade()
                pg.draw.line(screen,(185,241,255),g.to_screen_point(*start),g.to_screen_point(*end),5)
            if self.guard:
                pg.draw.circle(screen,(116,218,245),(x,y-15),22,2)
        text=f"2P {self.hp}/5" if not self.down else f"2P 復帰 {math.ceil(self.down)}"
        label=font.render(text,True,(152,235,255))
        screen.blit(label,label.get_rect(midbottom=(x,y-38)))


def join(screen,font):
    import pygame as pg
    room=StoryRoom()
    clock=pg.time.Clock()
    address=""
    choice=0
    hint=""
    try:
        try:
            room.search()
        except OSError:
            room.mode="error"
        while True:
            clock.tick(60)
            action=0
            try:
                for e in pg.event.get():
                    if e.type==pg.QUIT:return False
                    if e.type!=pg.KEYDOWN:continue
                    if e.key==pg.K_ESCAPE:return True
                    if room.mode=="search":
                        if e.key==pg.K_F2:
                            room.stamps_enabled=not room.stamps_enabled
                            continue
                        rooms=sorted(room.rooms)
                        if rooms and e.key in (pg.K_UP,pg.K_DOWN):
                            choice=(choice+(1 if e.key==pg.K_DOWN else -1))%len(rooms)
                        elif e.key==pg.K_BACKSPACE:address=address[:-1]
                        elif e.key in (pg.K_RETURN,pg.K_KP_ENTER):
                            target=address or (rooms[choice%len(rooms)] if rooms else "")
                            if target:
                                try:room.join(target)
                                except ValueError:hint="IPv4の数字を確認してください"
                        elif e.unicode and e.unicode in "0123456789." and len(address)<15:
                            address+=e.unicode
                    elif room.ready and not getattr(e,"repeat",False):
                        if e.key==pg.K_j:action|=1
                        if e.key==pg.K_p:action|=2
                if room.mode!="error":
                    room.poll()
                    keys=pg.key.get_pressed()
                    room.controls((int(keys[pg.K_d])-int(keys[pg.K_a]),int(keys[pg.K_s])-int(keys[pg.K_w])),action)
            except RejectedInput:
                room.close()
                if room.stamps_enabled:
                    show_stamp()
                return True
            except OSError:
                room.close()
                room.mode="error"
            if room.last_frame and room.mode=="playing":
                surf=pg.image.frombuffer(room.last_frame,SIZE,"RGB")
                pg.transform.scale(surf,screen.get_size(),screen)
            else:
                screen.fill((24,35,45))
                ips=sorted(room.rooms)
                lines=["本編ストーリーに参加","ホストは冒険中に F3 で募集",
                       "↑↓で選択・Enterで参加　または IPv4 を入力",
                       address or (ips[choice%len(ips)] if ips else "募集中の冒険を検索中…"),hint,"F2　別窓の警告スタンプ演出　"+("オン" if room.stamps_enabled else "オフ"),"Esc　戻る"]
                if room.mode!="search":
                    lines=["通信が終了しました" if room.mode=="error" else "ホストに接続中…","Esc　戻る"]
                for i,line in enumerate(lines):
                    surf=font.render(line,True,(238,226,197))
                    screen.blit(surf,surf.get_rect(center=(400,135+52*i)))
            pg.display.flip()
    finally:
        room.close()
