"""白帆の泊地の序幕。音声の長さを各カットの尺にする。"""
import math
from pathlib import Path
import pygame
import tide_art

CAPTIONS=(
 ("私はミオ。この港で、毎朝、雨の量を測っている。","父を葬った朝、空は晴れていた。"),
 ("それなのに、測り瓶に一滴だけ雨が落ちた。","瓶に刻まれた日付は、明日だった。"),
 ("海の向こうには、夜が来るたび一日若くなる町がある。","その朝を買うために、ここの誰かの明日が消える。"),
 ("瓶の底には、小さな字でこうあった。","「姉さん。僕が生まれる日を、売らないで。」"),
 ("私には、弟はいない。まだ。","旅人さん。あの子に会うまで、船の灯を消さないで。"),
)

class Prologue:
    def __init__(self):
        self.active=False
        self.channel=None
        self.voices=[]
    def start(self,root):
        if not self.voices and pygame.mixer.get_init():
            self.voices=[pygame.mixer.Sound(str(Path(root)/"assets"/"voice"/f"mio{i}.ogg")) for i in range(len(CAPTIONS))]
        self.active=True
        self.cut(0)
    def cut(self,i):
        if self.channel:self.channel.stop()
        self.index=i
        self.age=0
        if i>=len(CAPTIONS):
            self.active=False
            return
        if self.voices:
            self.channel=pygame.mixer.find_channel(True)
            self.channel.play(self.voices[i])
        self.duration=self.voices[i].get_length()+.7 if self.voices else (8,8,11,8,8)[i]
    def draw(self,screen,font,small,dt):
        self.age+=dt
        if self.age>=self.duration:
            self.cut(self.index+1)
            if not self.active:return
        i=self.index
        t=self.age
        w=400
        canvas=pygame.Surface((w,205))
        d=pygame.draw
        if i in (0,4):
            bg=tide_art.backdrop(0)
            canvas.blit(pygame.transform.scale(bg,(490,368)),(-40+round(4*math.sin(t*.21)), -18))
            water=tide_art.wave_frames()[int(t*9)%24]
            canvas.blit(pygame.transform.scale(water,(490,116)),(-40+round(4*math.sin(t*.21)),-18))
            if i==0:
                for k in range(3):
                    x=(48+k*105+int(t*6))%400;y=22+5*k
                    d.lines(canvas,(179,191,179),False,[(x-4,y-2),(x,y),(x+4,y-2)],1)
        elif i in (1,3):
            canvas.fill((25,39,53))
            for y in range(90,205,9):
                d.line(canvas,(62+y//10,55+y//14,48),(0,y),(400,y),7)
            if i==1:
                d.polygon(canvas,(114,153,151),[(178,40),(221,40),(221,64),(236,86),(233,162),(171,162),(168,86),(178,64)],3)
                level=131+round(1.5*math.sin(t*3))
                d.polygon(canvas,(52,116,135),[(172,level),(231,level-1),(229,157),(175,157)])
                drop=(t%2)/2
                if drop<.72:d.line(canvas,(193,229,225),(202,int(15+110*(drop/.72)**2)),(202,int(19+110*(drop/.72)**2)),2)
                else:d.ellipse(canvas,(188,224,218),(202-int(60*(drop-.72)),level-2,max(2,int(120*(drop-.72))),4),1)
                for j in range(7):d.line(canvas,(196,204,176),(173,92+j*9),(180+j%2*4,92+j*9))
            else:
                y=50+round(3*math.sin(t*.6))
                d.polygon(canvas,(206,186,143),[(94,y+9),(287,y),(302,y+96),(101,y+107)])
                for j in range(4):
                    for k in range(min(18,int(t*5)-j*4)):
                        x=117+8*k;yy=y+26+15*j-k//4
                        d.lines(canvas,(85,80,72),False,[(x,yy),(x+2,yy-3),(x+3,yy+2),(x+5,yy-1)])
        else:
            canvas.fill((17,32,53))
            for j in range(18):
                x=j*25-9;h=24+(j*31)%55
                d.rect(canvas,(48,68,90),(x,120-h,21,h));d.polygon(canvas,(67,83,105),[(x-3,120-h),(x+10,109-h),(x+24,120-h)])
                for k in range(2):
                    if (j+k+int(t*.6))%4:d.rect(canvas,(184,158,94),(x+4+8*k,111-h//2,3,6))
            for j in range(29):
                y=124+j*3;x=int(44*j+12*math.sin(t+y))%400
                d.line(canvas,(64,105,123),(x,y),(min(399,x+28),y))
            cx,cy=315,37;d.circle(canvas,(196,175,118),(cx,cy),24,2)
            angle=-t*.9;d.line(canvas,(223,204,151),(cx,cy),(cx+round(17*math.sin(angle)),cy-round(17*math.cos(angle))),2)
        screen.fill((12,19,29))
        screen.blit(pygame.transform.scale(canvas,(800,410)),(0,35))
        for j,line in enumerate(CAPTIONS[i]):
            txt=font.render(line,True,(244,232,204));screen.blit(txt,txt.get_rect(center=(400,490+32*j)))
        screen.blit(small.render("雨量係ミオ",True,(222,181,109)),(32,451))
        screen.blit(small.render("Enter　次へ　　 Esc　スキップ",True,(170,184,190)),(530,563))
        opacity=int(255*max(0,1-t/.32,1-(self.duration-t)/.34))
        if opacity:
            shade=pygame.Surface((800,410));shade.set_alpha(min(255,opacity));screen.blit(shade,(0,35))
        pygame.display.flip()
