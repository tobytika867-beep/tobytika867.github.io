"""星図の旅人 III ― 白暦の海。巡航番号を種にして海図を再現する。"""
import sea_encounters as legends
import math
import random
from functools import lru_cache
from collections import deque
import pygame
import tide_art as art

PORT = "meridian_home"
# Chapter, witness, physical evidence, testimony, consequence, adversary.
STORY = [
("雨の来ない港","雨量係ミオ","空の雨瓶","父の葬式の日だけ、雨量計に明日の雨が入っていた。","瓶の底から、まだ生まれていない弟の筆跡が出た。","旱天の徴税官"),
("七日遅れの郵便","配達夫ロク","青い封蝋","届けた手紙が七日後に白紙で戻る。宛名だけが少しずつ幼くなる。","消された日を覚えているのは、手紙を開けなかった人だった。","逆配の飛脚"),
("沈鐘村の朝食","パン屋イネ","焦げた匙","毎朝六人分を焼く。椅子は五脚。誰が六つ目を食べていたの。","匙の歯形でイネは妹の名を思い出した。名が最初の航路になる。","朝を盗む竈守"),
("国境の長椅子","駅員ハル","片道切符","列車は空なのに、降りた足跡だけが雪に残る。","切符を重ねると線路は北の病院まで延びた。","空席の検札長"),
("余命の病棟","医師ユラ","硝子の脈時計","この子の明日を買った人がいる。領収書には私の署名がある。","延命した一日は、遠い村の一日を丸ごと奪っていた。","白衣の秤"),
("母の偽印","印守サイ","割れた母印","印を偽ったのは私だ。けれど最初の印を押したのは君の母だ。","母の印に残る潮が、沖の採暦場への水路を開いた。","朱肉の番犬"),
("春を掘る子","坑夫ネム","芽吹く鉱石","坑夫は春を一日ずつ掘る。弟は昨日、十歳から十二歳になった。","鉱車の行先は王宮ではなく、凍海に浮かぶ小舟だった。","春喰いの穿孔機"),
("氷原の乳母","船医レナ","温かい毛布","小舟には百人の赤子がいる。一人ずつ別の春を待っている。","毛布を洗うと、生まれるはずだった百の町の名が現れた。","凍海の産婆"),
("砂糖の国会","議員トリ","溶けた投票札","票は砂糖でできている。採決の前に雨を降らせた者がいる。","濡れずに残った反対票は、母のものだった。","甘雨の議長"),
("借りた日曜日","仕立屋アコ","袖の短い喪服","息子の休日を買った。翌朝、あの子は私より年上だった。","喪服をほどくと裁判所の傍聴券が縫い込まれていた。","針暦の仕立師"),
("声なき法廷","通訳リセ","空の速記帳","証人の口は動くのに、書き取った文字は翌日まで読めない。","母の最後の証言は『機械を止めれば全員が戻る』の否定だった。","無音の陪審"),
("盗まれた満月","測量士ジン","歪んだ六分儀","月が一晩に二度昇る。片方には海面の反射がない。","偽の月は海底を照らす鏡だった。その下にもう一つの港がある。","月裏の測量官"),
("海底の故郷","潜水士ミオ","裏文字の表札","私の家が沈んでる。台所には明日の朝食まで並んでる。","海底の町は失われた未来そのものだった。弟はここで暮らしていた。","深床の戸主"),
("姉を知らない弟","少年ナギ","二人分の絵日記","姉さんなら、僕が嫌いな魚を言える？　名前だけなら帳簿にもある。","二人は絵日記に新しい一頁を描いた。初めて帳簿にない日が生まれた。","模写師の影"),
("忘却灯台","灯守エノ","黒い灯芯","火を消せば忘れる。火を守れば沖の船が岩場へ吸い寄せられる。","灯芯を二つに裂くと、船が自分で曲がれる弱い光になった。","盲灯の船長"),
("葦原の反乱","渡守ケイ","折れた櫂","昨日を返せと人々が叫ぶ。けれど、返してほしくない昨日もある。","櫂に結ばれた白布が、望む人だけが渡る最初の旗になった。","百艘の提督"),
("母の捕虜船","料理人ヨナ","塩抜きの献立","独房だけ塩を使わない。中にいる人が海水を飲んで帰ったから。","母は逃げなかった。彼女が舵を離せば海底の百の町が浮いて砕ける。","鎖帆の看守"),
("二本目の舵","機関士ガロ","逆巻き歯車","二人で反対に回せば、船は初めて潮の速さを選べる。","ナギが未来側の舵を取った。母は十八年ぶりに手を放した。","反転機関長"),
("逃げる王宮","庭師キト","歩く根株","根は水脈を覚えている。城が逃げても庭は嘘をつけない。","根をたどると、城は毎晩同じ墓の前で止まっていた。","樹脚の近衛"),
("最初の一日","墓守フウ","王女の靴","最初に盗られたのは国民の日ではない。王が娘に与えた、自分の明日だ。","娘は最後まで靴を履かなかった。誰かの時間で歩くのを拒んだ。","墓標の騎士"),
("靴音の会談","王女セナ","未使用の靴紐","父に会う。けれど、生き返らせてくれてありがとうとは言わない。","王女は自分の余命を議場で公開した。港が初めて王宮に返事をした。","静聴の宰相"),
("海のストライキ","網元トワ","結び目の網","潮が止まったんじゃない。海底の皆が一斉に舵から手を放したのさ。","船を一隻ずつ曳くと、本物の潮が細く流れ始めた。","停潮の水夫王"),
("返却不能の朝","出納係ミオ","穴あき台帳","返した日は傷も返す。それでも本人に選ばせたい。","返却を拒んだ欄にも初めて署名が並んだ。帳簿は命令書でなくなった。","残債の執達吏"),
("星のない航路","少年ナギ","手描きの星図","星が消えても姉さんを見つけられる。二人で描いた島があるから。","絵日記の島に上陸すると、暦を動かす最後の心臓が鳴った。","無星の操舵手"),
("最後の閏日","母ユイ","二十七枚目の暦","最後に一日余る。誰にも借りずに生まれたあんたたちの日だよ。","母は自分の名を帳簿から消した。海の両側で同じ朝焼けが始まる。","白暦の創設者"),
("明日を決める人","暦師ミオ","白紙の航海図","私たちは明日を配れる。でも、誰がそれを頼んだんだろう。","靴音が桟橋を渡る。今度こそ誰の帳簿にも、その足数は載っていない。","千年を巻く白鯨"),
]
LEGS = ("漂着浜","水没街道","検潮林","塩の地下道","旧市街","暦の内庭","白の中枢")
TASKS = ("難破船の発信地を割り出す","救援隊の帰路を開く","偽の証言を照合する","封鎖水路を逆流させる","散った原本をつなぐ","守備隊の包囲を破る","潮の主から証拠を奪還する")
GLYPHS = ("錨","灯","帆","月")
DIRS = (("北へ",0,-1,400,110),("東へ",1,0,694,300),("南へ",0,1,400,503),("西へ",-1,0,107,300))
W,H=10,9
TOTAL=len(STORY)*len(LEGS)
def area(v,r):return f"voy_{v}_{r}"
CELLS={area(v,r):(v,r) for v in range(TOTAL) for r in range(W*H)}
NAMES={a:f"{LEGS[v%7]} {r%W+1}列{r//W+1}段" for a,(v,r) in CELLS.items()}
NAMES[PORT]="白帆の泊地"

@lru_cache(maxsize=8)
def chart(v):
    rng=random.Random(81003+v)
    graph=[[] for _ in range(W*H)]
    stack=[0];seen={0}
    while stack:
        r=stack[-1];x,y=r%W,r//W
        options=[nx+ny*W for _,dx,dy,_,_ in DIRS if 0<=(nx:=x+dx)<W and 0<=(ny:=y+dy)<H and nx+ny*W not in seen]
        if not options:
            stack.pop();continue
        n=rng.choice(options);graph[r].append(n);graph[n].append(r);stack.append(n);seen.add(n)
    # A handful of loops allow a different return route.
    for _ in range(14):
        r=rng.randrange(W*H-1);n=r+1
        if n%W and n not in graph[r]:graph[r].append(n);graph[n].append(r)
    distance={0:0};queue=deque([0])
    while queue:
        r=queue.popleft()
        for n in graph[r]:
            if n not in distance:distance[n]=distance[r]+1;queue.append(n)
    ranked=sorted(distance,key=distance.get)
    targets=tuple(rng.choice(ranked[i:i+7]) for i in (21,44,66))+(ranked[-1],)
    order=list(GLYPHS);rng.shuffle(order)
    return graph,targets,order

def voyage(g):return min(TOTAL,g.talk_counts.get("voyage",0))
def key(v,k):return f"v{v}_{k}"
def ending(g):
    return "白紙の航海図は各家の窓辺に配られた。" if "open_sea" in g.chapter_flags else "泊地の灯は、望む人だけに明日を預かる。"
def goal(g):
    v=voyage(g)
    if v==TOTAL:return "白暦編 完結　"+ending(g)
    if "tide_arms" not in g.chapter_flags:return "左の武器箱でE。ミオが桟橋で最初の便りを待っている。"
    return f"第{v//7+1}章「{STORY[v//7][0]}」 {v%7+1}/7　{BRIEFS[v%7]}"
def boss_name(v):return STORY[v//7][5] if v%7==6 else ("霧の斥候","鎖門の衛士","鏡面の証人","逆潮の番人","黒札の書記","包囲隊長")[v%7]
BRIEFS=("観測碑で船の信号を読む","水門盤で嵐 N を使う","証言箱から原本を救出","水門盤で雷 G を使う","二つの証拠で水門の暗号を解く","包囲隊長を撃破","章の主を倒し記録の行先を選ぶ")
def mission_done(g,v):
    mark=("survey","engine","letter","engine","sluice",None,None)[v%7]
    return mark is None or key(v,mark) in g.chapter_flags

def launch_sites(g,v,r,targets):
    # The skiff follows the mission. Players may still chart the surrounding passages.
    if r==0:
        first=(0,1,2,1,0,3,3)[v%7]
        return [("先遣艇に乗る",535,375,targets[first])]
    if v%7==4 and r==targets[0]:return [("証言箱行き",545,445,targets[2])]
    if v%7==4 and r==targets[2]:return [("水門行き",545,445,targets[1])]
    if mission_done(g,v) and r in targets[:3]:return [("帰還桟橋行き",545,445,targets[3])]
    return []

def sites(g):
    if g.interior==PORT:
        return rite_sites(g)+[("港の依頼板",370,315),("武器箱",230,382),("船鍛冶",566,377),("宿の火",400,435),("航海日誌",180,215),("遠征船",400,145),("暦師ミオ",600,215)]
    v,r=CELLS[g.interior];graph,targets,_=chart(v)
    s=[(n,x,y) for n,dx,dy,x,y in DIRS if r+dx+dy*W in graph[r]]
    s.extend((label,x,y) for label,x,y,dest in launch_sites(g,v,r,targets))
    if r==0:s.append(("泊地へ",275,390))
    if r in targets[:3]:s.append((("観測碑","水門盤","証言箱")[targets.index(r)],400,250))
    if r==targets[1]:s.extend([(n,210+120*i,365) for i,n in enumerate(GLYPHS)])
    if r==targets[3]:
        s.append(("帰還の舵",400,220))
        if v%7==6:s.extend([(LEGACIES[v//7][0],255,350),(LEGACIES[v//7][1],545,350)])
    return s
def nearby(g):
    n,x,y=min(sites(g),key=lambda p:math.dist(g.player.center,p[1:]))
    return n if math.dist(g.player.center,(x,y))<68 else None
def travel(g,a,pos=(400,440)):
    g.hostile_attacks.clear()
    if a in CELLS:
        v,r=CELLS[a];g.talk_counts["berth"]=r;g.talk_counts["survey"]=g.talk_counts.get("survey",0)|(1<<r)
    g.royal_travel(a,pos);g.invulnerable=1.2;g.last_clue=goal(g)
def marks(g,v):
    return [key(v,k) in g.chapter_flags for k in ("survey","sluice","letter")]
def act(g):
    n=nearby(g);v=voyage(g);f=g.chapter_flags
    if not n:g.tell(goal(g));return
    if g.interior==PORT:
        if n=="港の依頼板":accept_rites(g);return
        for d in RITES.values():
            if n==d[2]:g.tell(d[4],7);return
        if n=="武器箱":
            g.owned_gear.update(("sword","spear","bow","shield"))
            if "tide_arms" not in f:g.weapon="sword";g.shield_equipped=True
            f.add("tide_arms");g.tell("盾を装備した。P でジャストガード。中央奥の遠征船へ。")
        elif n=="宿の火":g.hp=g.max_hp;g.tell("火が指に戻る。全回復した。")
        elif n=="船鍛冶":
            price=12+9*g.weapon_level
            if g.weapon_level<5 and g.rupees>=price:g.rupees-=price;g.weapon_level+=1;g.tell(f"武器を +{g.weapon_level} に強化した。")
            else:g.tell("五段階まで鍛えられる。次の費用は"+str(price)+"石。" if g.weapon_level<5 else "もう最高の刃だ。")
        elif n=="航海日誌":
            pages=[line for i in range(v//7) for line in (legends.CHAPTERS[i][2],STORY[i][4],legends.CHAPTERS[i][3],legacy(g,i))]+[goal(g)]
            g.tell(g.conversation("voy_log",*pages),8)
        elif v==TOTAL:g.tell(ending(g),8)
        elif n=="暦師ミオ":
            chapter=v//7
            pages=[STORY[chapter][1]+"からの便り：「"+STORY[chapter][3]+"」",legends.CHAPTERS[chapter][2]]
            if chapter:pages.append("前の港から返事だよ。"+legacy(g,chapter-1))
            g.tell(g.conversation("mio_story_"+str(chapter),*pages),9)
        elif "tide_arms" not in f:g.tell("先に武器箱で装備を受け取ろう。")
        else:
            travel(g,area(v,g.talk_counts.get("berth",0)))
            g.tell(BRIEFS[v%7]+"。入口の先遣艇で現場へ直行できる。",7)
        return
    _,r=CELLS[g.interior];graph,targets,order=chart(v)
    alive=any(e.hp>0 for e in g.enemies)
    for label,x,y,dest in launch_sites(g,v,r,targets):
        if n==label:
            travel(g,area(v,dest))
            if dest==targets[3] and v%7==6:g.tell(legends.CHAPTERS[v//7][2],8)
            return
    for label,dx,dy,x,y in DIRS:
        if n==label:
            dest=r+dx+dy*W
            travel(g,area(v,dest),(400-dx*236,300-dy*148));return
    if n=="泊地へ":travel(g,PORT);return
    if alive:g.tell("魔物が通路を見張っている。先に退けよう。");return
    if n=="観測碑":
        f.add(key(v,"survey"));g.tell("刻印の順は「"+order[0]+"」から。最後は「"+order[3]+"」。",8)
    elif n=="証言箱":
        f.add(key(v,"letter"));g.tell(STORY[v//7][2]+"の走り書き。「"+order[1]+"のすぐ後に"+order[2]+"」。",8)
    elif n=="水門盤":
        if v%7 in (1,3,5) and key(v,"engine") not in f:
            g.tell({1:"嵐 N で救援船の風車を回そう。",3:"雷 G で水路の電極をつなごう。",5:"焔 B で包囲網の導火線に火を。"}[v%7],7)
        else:g.tell(CIPHERS[v%7][0],7)
    elif n in GLYPHS:
        if key(v,"sluice") in f:g.tell("水門は開いた。");return
        if not (marks(g,v)[0] and marks(g,v)[2]):g.tell("観測碑と証言箱を先に調べよう。");return
        step=g.talk_counts.get("dial",0)
        if v%7 in (1,3,5) and key(v,"engine") not in f:g.tell("水門盤の前でE。機関の動力を調べよう。");return
        if n==code(v)[step]:
            g.talk_counts["dial"]=(step+1)%4
            if step==3:f.add(key(v,"sluice"))
            g.tell("水門が開いた。" if step==3 else f"刻印 {step+1}/4")
        else:
            g.talk_counts["dial"]=0;g.add_boss_hazard("meteor",*g.player.center,.85,40);g.tell("刻印が逆流した！")
    elif n in (*LEGACIES[v//7][:2],"帰還の舵"):
        if not mission_done(g,v):g.tell(BRIEFS[v%7]);return
        if v%7==6 and n=="帰還の舵":g.tell("左なら次章に住民の援軍、右なら薬三瓶。記録を誰に届ける？",7);return
        if n!="帰還の舵":
            if g.talk_counts.get("pledge",0)!=(1 if n==LEGACIES[v//7][0] else 2):
                g.talk_counts["pledge"]=1 if n==LEGACIES[v//7][0] else 2;g.tell(n+("。次章に援軍。" if n==LEGACIES[v//7][0] else "。薬三瓶。")+"もう一度Eで決定。");return
            if n==LEGACIES[v//7][0]:f.add(key(v//7,"public"))
            else:g.potions+=3
        g.talk_counts.update(voyage=v+1,berth=0,survey=0,dial=0,pledge=0)
        if v==TOTAL-1 and n==LEGACIES[v//7][0]:f.add("open_sea")
        if v in (1,3,5):g.abilities.add({1:"lightning",3:"flame",5:"earth"}[v])
        if v%21==20 and g.max_hp<12:g.max_hp+=1
        g.hp=g.max_hp;g.potions+=1;travel(g,PORT)
        for a in list(g.castle_state):
            if a in CELLS:del g.castle_state[a]
        g.tell(ending(g) if v+1==TOTAL else legacy(g,v//7) if v%7==6 else legends.CHAPTERS[v//7][2] if v%7==4 else REPORTS[v%7].format(*STORY[v//7]),9)
        g.save_game(silent=True)
REPORTS=("漂着物に『{2}』の印。次は水没街道の生存者へ。","渡し場を開いた。{1}が検潮林で待っている。","{1}「{3}」","水が引いた床に『{2}』の保管場所が刻まれていた。","原本がそろった。追手の名は{5}。","包囲が崩れた。{5}が中枢に退いた。")

def harbor_water(body):
    # The image has a quay at source row 95 and three 19-pixel piers at 2x scale.
    feet_y=body.bottom-1
    if feet_y>=190:return False
    half=min(5,body.width//2)
    return feet_y<142 or not any(left<=body.centerx-half and body.centerx+half<left+38
                                 for left in (152,382,612))

def obstacles(a):
    if a not in CELLS:return ()
    v,r=CELLS[a]
    if r==0 or r in chart(v)[1]:return ()
    return (((222,177,38,68),(540,342,38,68)),((240,330,66,29),(502,180,66,29)),((330,195,34,49),(444,355,34,49)),())[(v+3*r)%4]

def spawn(g,Enemy):
    if g.interior==PORT:return []
    v,r=CELLS[g.interior];chapter=v//7;leg=v%7
    if r==0:return []
    if r==chart(v)[1][-1]:
        if leg not in (2,5,6):return []
        return [Enemy(389,167,"boss",72+chapter*4+leg*4,90+min(32,chapter*2), (175,107,133),boss_id=(chapter+leg)%6)]
    rng=random.Random(v*103+r)
    count=2+min(3,chapter//6)+rng.randrange(2)
    if key(chapter-1,"public") in g.chapter_flags:count=max(2,count-1)
    spots=rng.sample([(162,183),(390,159),(625,212),(182,395),(596,408),(399,369)],count)
    return [Enemy(x,y,rng.choice(("bat","stalfos","slime")),4+chapter//3+leg//3,92+rng.randrange(26)+chapter,(123,153,141)) for x,y in spots]

LOCK_TIME=.52
WAVE_RADIUS=316

def draw_wave(surface,x,y,hazard):
    radius=hazard["radius"]
    delay=hazard["delay"]
    color=(117,199,239) if delay>LOCK_TIME else (255,165,76) if delay>0 else (234,246,255)
    veil=pygame.Surface((2*radius+2,2*radius+2),pygame.SRCALPHA)
    center=(radius+1,radius+1)
    pygame.draw.circle(veil,(*color,36 if delay>0 else 108),center,radius)
    pygame.draw.circle(veil,color,center,radius,4)
    pygame.draw.circle(veil,color,center,10,2)
    if 0<delay<=LOCK_TIME:
        pygame.draw.circle(veil,color,center,max(2,round(radius*(1-delay/LOCK_TIME))),3)
    elif delay<=0:
        for r in (75,150,225,300):pygame.draw.circle(veil,color,center,r,3)
    surface.blit(veil,(x-center[0],y-center[1]))

def attack(g,e):
    v,_=CELLS[g.interior];x,y=g.player.center
    phase=int(e.hp<e.max_hp*.68)+int(e.hp<e.max_hp*.36)
    if v%7==6:
        legends.chapter_attack(g,e,v//7)
        return
    if v%7==5 and e.special_count%4==0:
        # The blue area tracks the player while blink recovers, then locks in place.
        delay=max(1.55,g.shukuchi_cooldown+.5)+LOCK_TIME
        g.add_boss_hazard("tidal_disk",x,y,delay,WAVE_RADIUS,.20)
        e.special_count+=1
        e.special_timer=delay+1.65
        g.tell("大潮接近！　槍を構え、橙の円に変わったら外へ I → J",delay)
        return
    if v%7==2:
        # The mirror witness fires a real fan followed by a reflected volley.
        g.aimed_fan(e.x+12,e.y+12,x,y,.72)
        g.aimed_fan(800-e.x-12,e.y+12,x,y,1.42)
        style=(v//7)%3
        if style==1:g.add_boss_hazard("across",x,y,1.8,17,.38)
        if style==2:
            for side in (-1,1):g.add_boss_hazard("meteor",x+side*55,y,1.7,34,.4)
        if phase:g.add_boss_hazard("down",x,y,2.05,16,.35)
        e.special_count+=1;e.special_timer=3.1
        return
    # Captains close flanks before shooting through the gap. Each fleet has a doctrine.
    fleet=(("gate","fleet","seam"),("rail","anchor","post"),("net","cradle","fan"),
           ("drill","roots","ring"),("pulse","ledger","quake"))[(v//7)%5]
    legends.cast(g,e,fleet[(e.special_count-1)%3],.8,phase,v+e.special_count)
    if phase:legends.cast(g,e,"post" if phase==1 else "cross",1.55,phase,v)
    e.special_count+=1;e.special_timer=3.6-.25*phase
def boss_down(g):
    v,_=CELLS[g.interior]
    if v%7==6:
        g.tell(legends.CHAPTERS[v//7][3]+"　記録の行先を選ぼう。",9)
        return
    g.tell("番人が退いた。調査を終えて帰還の舵へ。章末は記録の行先を選ぼう。",7)
def arena_volley(g,boss,v):
    """The engraved floor keeps its own beat, even when the sword arm is stunned."""
    phase=int(boss.hp<=boss.max_hp*.67)+int(boss.hp<=boss.max_hp*.33)
    beat=g.arena_beat
    g.arena_beat+=1
    g.tide_warning=(2.15,1.85,1.55)[phase] + random.uniform(-.20, .30)
    x,y=g.player.center
    first=len(g.hostile_attacks)
    # Always aim at the marked position. Crossing a warning is a viable escape.
    axis="down" if (v//7+beat)%2 else "across"
    floor=("meteor","root_burst","fire_pillar","quake")[(v//7+beat)%4]
    if v%7==2:
        # A mirror seal on the far side shoots back across the player's old path.
        sx=710 if x<400 else 90
        g.aimed_fan(sx,max(90,min(490,y+72*(-1)**beat)),x,y,.67)
        g.add_boss_hazard(floor,x,y,1.27,33,.33)
    elif v%7==5:
        # The captain first cuts off one axis, then shells the crossing.
        g.add_boss_hazard(axis,x,y,.72,17,.32)
        g.add_boss_hazard("meteor",x,y,1.30,39,.34)
    else:
        # Different chapter seals alternate point-first and line-first volleys.
        point_first=(v//7+beat)%2==0
        g.add_boss_hazard(floor,x,y,.76 if point_first else 1.31,36,.34)
        g.add_boss_hazard(axis,x,y,1.31 if point_first else .76,16,.34)
    if phase:
        side=1 if beat%2 else -1
        xx=max(55,min(745,x+side*58))
        g.add_boss_hazard(floor,xx,y,1.70,32,.32)
    if phase==2:
        g.add_boss_hazard("across" if axis=="down" else "down",x,y,2.08,13,.28)
    for hazard in g.hostile_attacks[first:]:
        hazard.update(attacker=boss,arena_seal=True)

def hazard_tick(g,dt):
    if g.interior not in CELLS:return
    v,r=CELLS[g.interior]
    if not g.enemies:return
    if r==chart(v)[1][-1]:
        boss=next((e for e in g.enemies if e.kind=="boss" and e.hp>0),None)
        if boss is not None:
            g.tide_warning-=dt
            if g.tide_warning<=0:arena_volley(g,boss,v)
        return
    if (r+v)%3:return
    g.tide_warning-=dt
    if g.tide_warning>0:return
    g.tide_warning=4.8-min(1.15,v*.007)
    kind=("down","meteor","across","fire_pillar","root_burst","wind_blast","quake")[v%7]
    casters=[e for e in g.enemies if e.hp>0 and e.stun<=0 and e.kind!="slime"]
    if not casters:return
    caster=min(casters,key=lambda e:math.dist(g.player.center,(e.x+12,e.y+12)))
    g.add_boss_hazard(kind,*g.player.center,1.1,18 if kind in ("across","down") else 40,.45,100)
    g.hostile_attacks[-1]["attacker"]=caster
def draw(g,s,font):
    v,r=CELLS.get(g.interior,(0,0))
    s.blit(art.backdrop(0 if g.interior==PORT else 1+(v%7+r//18)%9),(0,0))
    art.ambient(s,g.interior==PORT,pygame.time.get_ticks())
    for x,y,w,h in obstacles(g.interior):
        pygame.draw.rect(s,(62,65,68),(x,y,w,h));pygame.draw.line(s,(166,150,119),(x,y),(x+w,y),4)
        for yy in range(y+13,y+h,13):pygame.draw.line(s,(87,86,83),(x,yy),(x+w,yy))
    for n,x,y in sites(g):
        if n in ("暦師ミオ","船鍛冶"):
            g.draw_npc(dict(name=n,x=x,y=y,coat=(87,137,151),hair=(84,60,49),skin=(196,151,111)))
        else:
            art.fixture(s,n,x,y);g.center_text(n,x,y+15,font,(250,229,175))
    n=nearby(g)
    if n:g.center_text("E　"+n,400,468,font,(255,217,116))
def draw_chart(g,s,font):
    v=min(voyage(g),TOTAL-1);graph,targets,_=chart(v)
    seen=g.talk_counts.get("survey",0);r=g.talk_counts.get("berth",0)
    s.fill((23,35,46));g.center_text(goal(g),400,71,font,(249,218,142))
    def point(k):return (198+(k%W)*44,130+(k//W)*42)
    for k,edges in enumerate(graph):
        if seen>>k&1:
            for n in edges:pygame.draw.line(s,(113,137,143),point(k),point(n),3)
    for k in range(W*H):
        if seen>>k&1:pygame.draw.circle(s,(139,176,170),point(k),5)
    for k,c in zip(targets,((231,234,229),(89,165,221),(244,195,93),(211,96,98))):
        pygame.draw.circle(s,c,point(k),8,2)
    pygame.draw.circle(s,(118,242,145),point(r),4)
    g.center_text("緑 現在地　白 観測碑　青 水門　金 証言箱　赤 番人",400,518,font,(222,219,198))

# The engraved instructions describe how this expedition decodes its two records.
CIPHERS = (
    ("港の読み順は刻印どおり。",(0,1,2,3)),
    ("救援隊は最後の印から一歩ずつ退く。",(3,2,1,0)),
    ("偽札は中央の二印だけが入れ替わっている。",(0,2,1,3)),
    ("逆流水路は二組の印を、後ろの組から読む。",(2,3,0,1)),
    ("旧市街の綴じ順は外側の左、右、内側の左、右。",(0,3,1,2)),
    ("隊列は偶数番を先に、次に奇数番を読む。",(1,3,0,2)),
    ("中枢は内側の右、左、外側の右、左で解錠。",(2,1,3,0)),
)
def code(v):
    order=chart(v)[2]
    return tuple(order[i] for i in CIPHERS[v%7][1])

def use_power(g,power):
    if g.interior==PORT and power in RITES and nearby(g)==RITES[power][2]:
        g.chapter_flags.add("master_"+power)
        g.burst_effect("heal",*g.player.center,(250,217,122),24)
        g.tell(RITES[power][5],8)
        return True
    if g.interior not in CELLS:return False
    v,r=CELLS[g.interior]
    if r!=chart(v)[1][1] or v%7 not in (1,3,5) or nearby(g)!="水門盤":return False
    needed={1:"wind",3:"lightning",5:"flame"}[v%7]
    if needed!=power:return False
    if any(e.hp>0 for e in g.enemies):g.tell("守備隊を退けてから機関へ。");return True
    g.chapter_flags.add(key(v,"engine"))
    g.burst_effect("heal",400,250,(148,210,228),14);g.tell("水門が動いた。帰還桟橋行きの舟へ。",7)
    return True

# Each pair changes who receives the original evidence.
LEGACIES = [
("雨瓶を広場へ","瓶を遺族へ","子どもたちが空瓶を並べて、失われた雨の日を数え始めた。","父の枕元で瓶が一度だけ曇った。ミオはその日付を手帳に残した。"),
("開封して朗読","宛先まで届ける","郵便局の前に椅子が並び、読めない人にも手紙が届いた。","ロクは一軒ずつノックした。最初の一通だけで一晩かかった。"),
("六人分を配る","六席目を残す","村の食卓に一切れずつ、消えた妹のパンが載った。","空席に湯気の立つスープを置くと、椅子の脚が少しきしんだ。"),
("切符を掲示","駅員に渡す","帰れなかった客の家族が駅で互いを見つけた。","ハルは帰りの列車が来るまで、改札の明かりを残した。"),
("病棟で説明","子に時計を返す","病床を囲んで、誰の日を誰が使ったのか初めて話し合った。","子は時計を裏返した。今日は自分で眠る時を決めたかった。"),
("偽印を公表","印守に預ける","偽物の朱を見分ける子が役所の前に列を作った。","サイは母印を削り、誰も押せない小さな匙にした。"),
("春を畑へ","春を弟へ","坑口に一筋、誰も植えなかった麦が芽を出した。","弟は借りた二歳を返し、背伸びして兄の帽子を取った。"),
("船名を放送","毛布を返す","百の町から舟の灯を探す返事が届いた。","一枚ずつ繕った毛布に、乳母が百の子守歌を縫い込んだ。"),
("票を数え直す","票の主を守る","溶けた札の皿まで、一票として議場に並べた。","名を伏せた証人が、翌朝初めて自分で議場に立った。"),
("型紙を配る","袖を縫い直す","町の時計屋が日曜だけ針を止め、親子の席を開けた。","仕立屋は息子の袖を測り直した。今の腕にぴったり合った。"),
("証言を放送","通訳に託す","港じゅうの窓が開いた。母の否定の一語が最後まで響いた。","リセは証言を手話に移し、最初に遺族の家へ向かった。"),
("鏡を岸へ向ける","潜水士に渡す","海底の灯に岸辺の子どもたちが白い布を振った。","ミオは鏡を胸に結び、初めて独りで故郷へ潜った。"),
("二つの町を結ぶ","古い家を守る","海上と海底で同じ表札を掲げる家が一軒生まれた。","水底の台所には、誰でも座れる七脚目の椅子が残った。"),
("絵を港に飾る","絵日記を閉じる","同じ島を見た子たちが、地図にそれぞれの浜を描き足した。","姉弟は表紙に二人の指紋を押した。ここだけは二人の秘密だ。"),
("灯を皆で守る","灯守へ鍵を返す","一晩ずつ交代で灯を守る名簿が波止場に掛かった。","エノは窓を少し開けた。岸からでも消灯を頼めるように。"),
("白旗を掲げる","渡守に旗を託す","白旗を見た船が戦列を離れ、渡し舟の後ろに並んだ。","ケイは旗を畳んだ。手を上げた人だけを静かに迎えた。"),
("献立を張り出す","母に食事を運ぶ","港の鍋という鍋から、塩を抜いた湯気が上がった。","母は一匙だけ飲んだ。海の味がしない、と泣いた。"),
("設計図を配る","ナギに舵を託す","小舟の工房が二本舵を写し、誰も一人で夜を越さなくなった。","ナギは母の掌を舵から剥がし、温かい鉢を持たせた。"),
("根の道を開く","墓の道を隠す","城の通った道に花を植え、墓まで迷わず歩けるようにした。","庭師は根の端をそっと土へ戻した。王にも独りの夜が残った。"),
("靴を議場へ","靴を王女へ","議員たちは空の靴の前で初めて帽子を取った。","セナは片方ずつ紐を通した。歩く時は自分で決める。"),
("会談を中継","父娘を見送る","海底の家々にも王女の声が届いた。拍手は一つもなかった。","扉が閉じた。中から聞こえたのは、二脚の椅子を引く音だった。"),
("網を海峡に渡す","網元に託す","百艘が一つの網を曳き、港に小さな潮騒が戻った。","トワは網をほどいて、一人で引ける長さの綱を配った。"),
("署名を公開","台帳を封じる","返さないという署名も、広場では同じ大きさで写された。","ミオは台帳を閉じた。理由は誰にも書かせなかった。"),
("星図を印刷","原図を弟へ","知らない島から写しが戻った。星が一つ描き足されていた。","ナギは星図を裏返し、姉と帰る航路を鉛筆で引いた。"),
("閏日を皆に","母の休みに","海の両側で、その日だけ暦を閉じて朝食を作った。","母は初めて潮を気にせず椅子で眠った。窓から雨の音がした。"),
("白紙を各家へ","灯台に預ける","弟は一枚目に日付を書かなかった。まず姉の似顔絵を描いた。","泊地の灯に小舟が来た。ミオは預かり札を一枚、手でちぎった。"),
]
def legacy(g,chapter):
    return LEGACIES[chapter][2 if key(chapter,"public") in g.chapter_flags else 3]

# Each rite restores a different part of the harbor. Progress survives leaving town.
RITES={
 "heal":("回復","診療船","薬師の水鉢",(159,166),"潮熱の患者が待っている。水鉢に回復 Y を。","患者の呼吸がそろった。回復量が3から5に上がった。"),
 "wind":("嵐","帆縫い場","破れた試験帆",(633,166),"重い帆を張りたい。試験帆へ嵐 N を送って。","帆が風を受けた。嵐の範囲と魔物の気絶時間が伸びた。"),
 "lightning":("雷","灯台の修理場","灯台の蓄電器",(681,266),"沖の標灯が暗い。蓄電器に雷 G を。","沖に灯が戻った。雷の射程と威力が上がった。"),
 "flame":("焔","窯場","消えた窯火",(143,467),"窯が湿って舟釘が焼けない。焔 B で種火を。","舟釘が赤く染まった。焔の持続が8秒から12秒に。"),
 "earth":("大地","石工の詰所","沈む礎石",(641,476),"満潮で岸壁が沈む。礎石を大地 M で押し戻せ。","岸壁が持ち上がった。壁の押し込み距離と圧壊の威力が上がった。"),
}
def rite_sites(g):
    marks=g.chapter_flags
    return [(data[2],*data[3]) for power,data in RITES.items() if "rite_"+power in marks and "master_"+power not in marks]
def accept_rites(g):
    newly=[]
    for power,d in RITES.items():
        if power in g.abilities and "rite_"+power not in g.chapter_flags:
            g.chapter_flags.add("rite_"+power);newly.append(d[0])
    pending=[d[4] for p,d in RITES.items() if "rite_"+p in g.chapter_flags and "master_"+p not in g.chapter_flags]
    g.tell("依頼を受領："+ "・".join(newly)+"。港に現れた設備でE。" if newly else g.conversation("rite_hints",*pending) if pending else "今の力の依頼はすべて完了。",7)
