"""地上の連作「鍋底の五本線」。既存の章フラグで各話と選択を記録する。"""
WITNESSES = ("荷秤のハル", "鋳掛屋イサ", "種番のルカ", "鐘突きのネネ", "粉挽きのソウ")
CITIES = ("霞港","赤銅市","翠森市","白鐘市","夜玻璃市")
ACCOUNTS = (
    "ハル：王の麦は袋ごと港へ来た。出ていったのは空袋と、湯気の立つ五つの鍋さ。",
    "イサ：鍋底の五本線はわしの仕事だ。背の違う子でも、一杯の量を間違えんように。",
    "ルカ：母の種麦だけが残った。食べずにすんだ春、畑一面に初めて穂が立った。",
    "ネネ：配給の鐘を鳴らしたのは私。名を呼ぶと来られない子がいたから、一度だけ鳴らした。",
    "ソウ：最後の粉を挽いたのはミラの母さんだ。代金の欄に、小さく『次の冬へ』とある。",
)
EPILOGUES = (
    "ハル：鍋は重い。だから空の帰り舟には、次の町の麦を積むんだ。",
    "イサ：新しい柄は左手でも握れるぞ。見習いが先に気づいてくれた。",
    "ルカ：あの春の種から採れた麦だよ。今日は私が誰かの一杯を作る。",
    "ネネ：昼の鐘は一度だけ。あとは匂いで分かる、だってさ。",
    "ソウ：勘定が合ったよ。昔の借りを返しに、粉を持ってくる人がいるんだ。",
)
COOK = (("水差し",235,335),("麦の臼",400,310),("薪の炉",565,335))
def slips(flags):
    return sum(f"hearth_slip{i}" in flags for i in range(5))

def goal(flags):
    if "hearth_end" in flags:
        return "終話　街道に台所が巡る。五街の証人を訪ねよう。" if "hearth_cart" in flags else "終話　きさらぎ町の宿に常設の台所ができた。"
    if flags.intersection(("hearth_cart","hearth_inn")):
        return "きさらぎ町のミラに、王都で決めたことを伝える。"
    if slips(flags)==5:
        return "王城前広場で炊事長ユノに五人の話を届ける。"
    if "hearth_meal" in flags:
        missing="・".join(CITIES[i] for i in range(5) if f"hearth_slip{i}" not in flags)
        return "五街の料理の証人を訪ねる　"+missing
    if "hearth_spoon" in flags:
        return "町の宿で鍋を仕込む。水を張り、麦を挽いて、最後に火を入れる。"
    if "hearth_start" in flags:
        return "きさらぎ町のトウマに、鍋の車輪について聞く。"
    return "きさらぎ町のミラに話しかける。"

def village(game,name):
    f=game.chapter_flags
    if name=="ミラ":
        if "hearth_start" not in f:
            f.add("hearth_start")
            game.tell("ミラ：母さんの帳面に『麦五袋、盗難』。でも荷車には鍋の丸い跡。トウマに聞いて。",7)
        elif f.intersection(("hearth_cart","hearth_inn")) and "hearth_end" not in f:
            f.add("hearth_end")
            game.tell("ミラ：鍋の車輪、今度は私が押すよ。最初の一杯はトウマにね。" if "hearth_cart" in f else "ミラ：宿の戸は朝から開けておくよ。一人で食べるのが嫌な日は、おいで。",7)
        else:
            return False
    elif name=="トウマ" and "hearth_start" in f and "hearth_spoon" not in f:
        f.add("hearth_spoon")
        game.tell("トウマ：車輪の下にあった柄杓だ。宿で水を張ってから麦を挽け。火は最後だぞ。",7)
    else:
        return False
    return True

def cook(game,site):
    f=game.chapter_flags
    index=next(i for i,(name,*_) in enumerate(COOK) if name==site)
    step=int("hearth_water" in f)+int("hearth_grain" in f)
    if index!=step:
        f.difference_update(("hearth_water","hearth_grain"))
        game.tell("鍋をすすいで仕切り直そう。水、挽きたての麦、最後に火だ。")
    else:
        f.add(("hearth_water","hearth_grain","hearth_meal")[step])
        if step==2:
            game.potions+=1
            game.tell("粥をよそうと柄杓の五つの刻印が読めた。五街の職人印だ。宿主が旅の薬をくれた。",7)
        else:
            game.tell(("柄杓の一本目まで水を張った。","挽いた麦を水に溶いた。あとは炉に薪を。")[step])

def city(game,name):
    f=game.chapter_flags
    if name in WITNESSES:
        i=WITNESSES.index(name)
        if "hearth_meal" not in f:
            game.tell("きさらぎ町の宿の粥なら覚えてる。あの柄杓を見たら、きっと分かるよ。")
        elif "hearth_end" in f:
            if "hearth_cart" in f and f"hearth_food{i}" not in f:
                f.add(f"hearth_food{i}")
                game.potions+=1
                game.tell(EPILOGUES[i]+"　旅の薬を一つ受け取った。",7)
            else:
                game.tell(EPILOGUES[i],6)
        else:
            f.add(f"hearth_slip{i}")
            game.tell(ACCOUNTS[i]+f"（{slips(f)}/5）",7)
    elif name=="炊事長ユノ":
        if f.intersection(("hearth_cart","hearth_inn")):
            game.tell(goal(f))
        elif slips(f)<5:
            game.tell("ユノ：麦は盗難扱いのまま。誰の食卓に届いたのか、五街に証人がいるよ。",6)
        else:
            f.add("hearth_charter")
            game.tell("ユノ：帳面を『炊き出し』に直したよ。次の冬はどこで炊こう？ 隣の荷車か宿帳を選んで。",7)
    elif name in ("炊事の荷車","きさらぎの宿帳"):
        cart=name=="炊事の荷車"
        if "hearth_charter" not in f or f.intersection(("hearth_cart","hearth_inn")):
            game.tell(goal(f))
        else:
            preview="hearth_try_cart" if cart else "hearth_try_inn"
            if preview in f:
                f.add("hearth_cart" if cart else "hearth_inn")
                game.tell("五街を巡る炊事便が出発した。ミラへ知らせよう。" if cart else "町の宿に食卓と無料の寝床を設けた。ミラへ知らせよう。",6)
            else:
                f.difference_update(("hearth_try_cart","hearth_try_inn"))
                f.add(preview)
                game.tell(("五街を巡り、各地で旅の薬が一つもらえる。" if cart else "町の宿で何度でも無料で休める。")+"ここでもう一度Eで決める。",6)
