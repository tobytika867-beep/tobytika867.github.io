from functools import lru_cache
from pathlib import Path
import math
import pygame

@lru_cache(maxsize=10)
def backdrop(index):
    source=pygame.image.load(str(Path(__file__).parent/"assets"/"tide"/f"scene{index}.png")).convert()
    return pygame.transform.scale(source,(800,600))

# Clockwise from east, matching the eight movement directions.
VIEWS=((1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1))

def heading(dx,dy):
    return round(math.atan2(dy,dx)*4/math.pi)%8

@lru_cache(maxsize=192)
def armor(index,view,stride):
    """One reusable armor cel, including the rear cloak and helmet profile."""
    s=pygame.Surface((48,54),pygame.SRCALPHA)
    d=pygame.draw
    dx,dy=VIEWS[view]
    # Draw rightward profiles once; flip the completed body for the leftward view.
    side=abs(dx)
    metal=((97,139,146),(171,137,102),(124,118,153),(169,97,92),(119,153,131))[index%5]
    ink=(38,34,41);shine=tuple(min(245,c+65) for c in metal);dark=tuple(c//2 for c in metal)
    d.ellipse(s,(19,22,26,120),(5,46,39,6))
    bob=int(stride!=0)
    for sign in (-1,1):
        x=22+sign*(4 if side else 7)+sign*stride*2*side
        y=31+sign*stride*2
        d.rect(s,ink,(x,y,7,17));d.rect(s,metal,(x+1,y+4,5,8));d.rect(s,(63,51,46),(x-1+side,y+14,9,4))
    sy=16-bob
    d.polygon(s,ink,[(13,sy),(29,sy-2),(38,sy+22),(24,sy+27),(9,sy+20)])
    for k in range(4):
        y=sy+4+k*4
        d.polygon(s,metal,[(14,y),(23+side*3,y+2),(33,y-1),(31,y+3),(23,y+5),(16,y+3)])
        d.line(s,shine,(15,y),(23+side*2,y+2))
    if dy<0 or side:
        hem=32 if dy<0 else 20
        d.polygon(s,dark,[(14,sy),(hem,sy),(hem+3,sy+23),(20,sy+27),(9,sy+23)])
        d.lines(s,metal,False,[(14,sy+2),(17,sy+15),(14,sy+22)],1)
    for x in (10,29 if not side else 25):
        d.ellipse(s,dark,(x,sy,10,9));d.arc(s,shine,(x,sy,10,8),0,math.pi,2)
        d.rect(s,metal,(x+2,sy+8,6,10))
    hx=24+side*2;hy=10-bob
    d.polygon(s,metal,[(hx-9,hy-3),(hx-2,hy-7),(hx+7,hy-4),(hx+9,hy+3),(hx+3,hy+10),(hx-7,hy+6)])
    d.line(s,shine,(hx-7,hy-3),(hx,hy-6),2)
    if dy==0:
        d.polygon(s,dark,[(hx-7,hy+1),(hx,hy-2),(hx+8,hy-1),(hx+10,hy+4),(hx+5,hy+7),(hx-5,hy+6)])
        d.line(s,ink,(hx+2,hy),(hx+9,hy+1),3)
        d.line(s,(255,185,94),(hx+5,hy),(hx+8,hy+1))
    elif dy>0:
        d.line(s,ink,(hx-6+side*7,hy+1),(hx+8,hy+1),3)
        d.line(s,(255,186,96),(hx-3+side*7,hy+1),(hx+6,hy+1),1)
    else:
        d.lines(s,dark,False,[(hx-7,hy+2),(hx,hy+6),(hx+7,hy+2)],2)
        if side:d.line(s,(247,169,85),(hx+7,hy+1),(hx+8,hy+1))
    if index>=3:d.lines(s,shine,False,[(hx-8,hy-2),(hx-10,hy-8),(hx-3,hy-5),(hx,hy-10),(hx+4,hy-5),(hx+8,hy-8),(hx+7,hy-2)],2)
    if dx<0:s=pygame.transform.flip(s,True,False)
    return pygame.transform.scale(s,(72,81))

def draw_boss_sword(surface,rect,view,h):
    dx,dy=VIEWS[view]
    side=dx or (1 if dy>0 else -1)
    x,y=rect.midbottom
    hand_x=x+side*16;hand_y=y-33
    angle=-.92 if side>0 else math.pi+.92
    planted=False
    if h:
        waiting=h["delay"]>0
        age=h.get("release_age",0)
        if h["kind"]=="melee":
            aim=math.atan2(dy,dx)
            # Finish the backswing just before contact and follow through on release.
            travel=1-min(1,h["delay"]/.32) if waiting else min(1,age/.12)
            angle=aim+side*((-1.05-.65*travel) if waiting else (-.48+1.48*travel))
            if not waiting:
                d=pygame.draw
                points=[(hand_x+round(33*math.cos(angle-side*i*.10)),hand_y+round(33*math.sin(angle-side*i*.10))) for i in range(6)]
                d.lines(surface,(234,201,145),False,points,2)
        else:
            # Raise the hilt, turn the blade point down, then sink it into the floor.
            angle=math.pi/2
            descent=max(0,1-min(1,h["delay"]/.23)) if waiting else 1
            hand_y=y-55+round(27*descent)
            hand_x=x+side*20
            planted=not waiting
    ux,uy=math.cos(angle),math.sin(angle)
    def point(length,width=0):
        return round(hand_x+length*ux-width*uy),round(hand_y+length*uy+width*ux)
    length=25 if planted else 32
    d=pygame.draw
    if planted:
        d.ellipse(surface,(113,198,215),(hand_x-10,y-5,21,5),1)
        for sign in (-1,1):d.lines(surface,(211,191,145),False,[(hand_x,y-3),(hand_x+sign*5,y-1),(hand_x+sign*10,y-3)])
    d.line(surface,(89,64,49),point(-8),point(2),4)
    blade=[point(3,-3),point(length-4,-2),point(length),point(length-4,2),point(3,3)]
    d.polygon(surface,(134,159,174),blade)
    d.line(surface,(229,235,218),point(3,-2),point(length),2)
    d.line(surface,(213,165,88),point(1,-6),point(1,6),3)
    d.circle(surface,(111,104,100),point(-3),3)

@lru_cache(maxsize=1)
def wave_frames():
    atlas=pygame.image.load(str(Path(__file__).parent/"assets"/"tide"/"waves.png")).convert()
    return [pygame.transform.scale(atlas.subsurface((0,95*i,400,95)),(800,190)) for i in range(24)]

@lru_cache(maxsize=12)
def glow(level):
    layer=pygame.Surface((76,76),pygame.SRCALPHA)
    for radius in range(36,3,-2):
        alpha=round((1-radius/38)**2*(24+4*level))
        pygame.draw.circle(layer,(255,173,69,alpha),(38,38),radius)
    return layer

def ambient(surface,harbor,ms):
    if harbor:
        surface.blit(wave_frames()[ms//110%24],(0,0))
    for index,(x,y) in enumerate(((122,182),(678,182),(112,452),(688,452))):
        phase=ms*.0033+index*1.8
        level=round(5+3*math.sin(phase)+2*math.sin(phase*2))
        surface.blit(glow(level),(x-38,y-38))
        pygame.draw.rect(surface,(255,183+3*level,82+4*level),(x-4,y-6,10,12))

def fixture(s,name,x,y):
    d=pygame.draw
    d.ellipse(s,(43,42,43),(x-18,y-5,39,10))
    if name=="宿の火":
        tick=pygame.time.get_ticks()//75
        phase=math.tau*(tick%24)/24
        s.blit(glow(round(6+4*math.sin(phase))),(x-38,y-45))
        for i,a in enumerate((-8,1,7)):
            h=round(16+4*math.sin(phase*2+i)+3*math.sin(phase+i*2))
            lean=round(3*math.sin(phase+i))
            d.polygon(s,(221,106+10*i,43),[(x+a-5,y),(x+a+lean,y-h),(x+a+6,y)])
            d.polygon(s,(255,189,78),[(x+a-3,y),(x+a+lean//2,y-h//2),(x+a+3,y)])
        d.line(s,(88,58,43),(x-12,y),(x+12,y+3),4)
    elif any(w in name for w in ("門","へ","舟","行き","回廊","調査船")):
        d.rect(s,(79,63,49),(x-3,y-24,6,25))
        d.polygon(s,(145,111,69),[(x-17,y-23),(x+12,y-24),(x+20,y-19),(x+12,y-14),(x-17,y-14)])
        d.line(s,(207,176,119),(x-15,y-22),(x+12,y-22))
    elif any(w in name for w in ("日誌","証言","票","切符","原本","産着","前掛け","記録")):
        d.polygon(s,(81,59,44),[(x-18,y-17),(x+14,y-20),(x+20,y-7),(x-13,y-3)])
        d.polygon(s,(211,193,151),[(x-14,y-17),(x+8,y-19),(x+14,y-9),(x-8,y-7)])
        for j in range(3):d.line(s,(119,102,83),(x-9+j,y-15+2*j),(x+6+j,y-16+2*j))
    else:
        d.rect(s,(58,48,46),(x-15,y-16,31,17))
        d.polygon(s,(151,113,75),[(x-15,y-16),(x-10,y-22),(x+12,y-22),(x+17,y-16)])
        for a in (-9,8):
            d.rect(s,(166,143,101),(x+a,y-20,3,19));d.circle(s,(221,205,156),(x+a+1,y-10),1)

def current_attack(game,enemy):
    if enemy.stun>0 or enemy.hp<=0:return None
    attacks=[h for h in game.hostile_attacks if h.get("attacker") is enemy and not h.get("arena_seal")]
    if not attacks:return None
    # A released projectile continues independently of the caster.
    live=[h for h in attacks if h["delay"]<=0 and h.get("release_age",0)<.18]
    pending=[h for h in attacks if h["delay"]>0]
    return min(live,key=lambda a:a.get("release_age",0)) if live else min(pending,key=lambda a:a["delay"]) if pending else None

def attack_pose(game,enemy,sprite,rect):
    h=current_attack(game,enemy)
    if not h:return None
    winding=h["delay"]>0
    t=1-min(1,h["delay"]/max(.01,h["windup"])) if winding else min(1,h.get("release_age",0)/.18)
    facing=1 if game.player.centerx>=enemy.x+12 else -1
    thrust=-t if winding else 1-t
    angle=round(-facing*thrust*(24 if enemy.kind=="bat" else 13))
    body=pygame.transform.rotate(sprite,angle)
    frame=pygame.Surface((body.get_width()+44,body.get_height()+36),pygame.SRCALPHA)
    base=frame.get_rect(midbottom=rect.midbottom)
    anchor=(frame.get_width()//2+round(8*thrust*facing),frame.get_height()-2)
    bodyrect=body.get_rect(midbottom=anchor)
    frame.blit(body,bodyrect)
    hand=(anchor[0]+facing*6,bodyrect.centery+3)
    if enemy.kind=="bat":
        for side in (-1,1):
            tip=(hand[0]+side*18,hand[1]+round(thrust*12))
            pygame.draw.lines(frame,(210,135,131),False,[hand,tip,(tip[0]-side*4,tip[1]+5)],2)
    else:
        arc=-1.25-.68*t if winding else -.15+.72*t
        if h["kind"] in ("tidal_disk","pull","quake","root_burst"):
            arc=-1.5-.3*t if winding else .9-.3*t
        elif h["kind"]=="orb":
            arc=-.65-.4*t if winding else -.05
        length=27 if enemy.kind=="boss" else 19
        tip=(hand[0]+round(facing*length*math.cos(arc)),hand[1]+round(length*math.sin(arc)))
        pygame.draw.line(frame,(73,56,54),hand,tip,5)
        pygame.draw.line(frame,(246,199,110) if winding else (246,248,218),hand,tip,2)
        if winding and h["delay"]<=.25:pygame.draw.circle(frame,(255,246,180),tip,3)
    return frame,base
