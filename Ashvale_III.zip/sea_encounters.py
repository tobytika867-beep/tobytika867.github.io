"""章ごとの譜面。技の形、時間差、幕の進行は章の記憶に結びつく。"""
import math

# Technique, opening/mid/late scores, witness's new memory, aftermath.
CHAPTERS=(
("雨量徴収","rain gate / ledger","井戸の縁に乾いた蛙の卵が残っていた。徴税官は雨粒を一つずつ袋に戻した。","底を打つ一滴の音に、港の赤ん坊が笑った。"),
("消印の折返し","post echo / cross","ロクは配達順を逆に書いた。先に帰った足跡の上なら迷わないという。","戻った封筒は一通だけ温かかった。ロクはそれを胸の内側へ入れた。"),
("六客の炉","oven ring / embers","六枚目の皿だけ縁が欠けている。妹はいつもそこへ親指をかけた。","イネは欠けた皿を洗い、乾くまで膝に載せていた。"),
("終電の分岐","rail cross / post","ハルは線路に耳を当てた。上りの音に紛れて下りの車輪が鳴る。","ホームに雪が落ちた。今度は足跡が二方向に延びた。"),
("脈の取り立て","pulse pull / ring","ユラの手首には脈が二つある。一つは顔を知らない子のものだった。","病室でその子が咳をした。ユラの指から二つ目の脈が消えた。"),
("割印","stamp echo / gate","サイは朱肉を親指で拭う。偽物にだけ、母の手の震えがない。","本物と偽物の紙を重ねると、その震えが海峡の形になった。"),
("春脈の穿孔","drill rain / quake","ネムは鉱石を耳に当てた。中で弟がまだ覚えていない歌を歌っていた。","坑口に土の匂いが戻った。兄弟は歌の最後の一行を一緒に考えた。"),
("ゆりかごの氷","cradle gate / pulse","乳母は子の寝息で船の傾きを測る。一人が泣くと右舷が沈んだ。","氷が割れた朝、初めて船そのものが赤子を揺らした。"),
("溶票の採決","ballot rain / stamp","トリは器に残った蜜も量った。溶けた票の重さは消えていなかった。","反対票の持ち主が初めて、砂糖なしの茶を飲んだ。"),
("返し縫い","seam post / cross","アコの指ぬきには二列の穴。息子の袖は何度も短く縫い直された。","作業場に新しい背比べの傷がついた。日付を書くのは息子に任せた。"),
("遅れる証言","silence ledger / echo","リセが両手で示したのは、声より先に届く否定の身振りだった。","閉廷の槌が落ちてから、やっと傍聴席のすすり泣きが聞こえた。"),
("月の視差","moon echo / pull","六分儀を左目でのぞくと月が二つ。右目なら水に映る方だけが揺れた。","偽の月を伏せると、その裏に百の窓明かりが見えた。"),
("海底の食卓","table pull / oven","水底の食卓に塩がこぼれていた。ミオが指で引いた筋を誰かがなぞる。","向こう側の窓が開いた。冷めた料理が初めて同じ湯気を上げた。"),
("裏写しの島","mirror post / moon","ナギは絵の右端を折った。写しにしかない折り目を旅人に見せた。","二人が描いた島だけ、帳簿の写しには見つからなかった。"),
("消灯間隔","beacon silence / rail","エノは灯を三度遮る。それが昔、船乗りが帰宅を知らせた合図だった。","沖の一隻が三度返した。エノはしばらく鍵を回せなかった。"),
("白旗の水道","fleet gate / fan","ケイは白旗を低く掲げた。渡りたくない人には旗の影もかけなかった。","最後の客は乗らなかった。渡守は何も言わずに櫂を上げた。"),
("錨鎖の食卓","anchor pull / seam","独房から皿が押し戻された。母は縁に指で『もう一人分』と書いた。","ヨナは自分の椅子を運び入れ、母と向かい合って食べた。"),
("逆転輪列","gears ring / drill","ガロの歯車は一枚だけ逆に擦れていた。何年も母が手で支えた跡だった。","機関が静まると、母の指の節がぽきりと鳴った。"),
("歩城の根","roots drill / rail","庭師が土に種を置く。城の通った跡だけ、逆向きに芽が出た。","墓への小径に芽が出た。城はその一本を避けて足を置いた。"),
("履けない靴","steps post / silence","墓守は王女の靴の底を見せた。踵に一粒の砂もついていなかった。","フウは墓前の石を磨く手を止めた。今日ついた足跡を残すために。"),
("傍聴の足音","audience cross / pulse","セナは演壇を下りた。父と同じ高さで話すには一段だけ高すぎた。","開いた扉の前で、王は自分で二脚の椅子を片づけた。"),
("止まる引網","net gate / anchor","網を引く手が一斉に止まる。切れかけた糸を一人の子が結び直した。","誰の命令もないまま、網の端から順に舟が動き出した。"),
("余白の帳尻","ledger stamp / ballot","台帳の空欄に一筋、乾いた涙の跡がある。ミオはそこへ線を引かなかった。","署名しなかった家にも、翌朝は同じように郵便が届いた。"),
("消え星の測位","stars silence / moon","ナギが空の暗い隙間を指さす。そこには絵日記でだけ光る星があった。","船尾の航跡が手描きの星座と同じ形に折れた。"),
("一日余る輪","leap gears / echo","母が暦を裂く手を止めた。余った一枚の裏に、旅人たちの名が透けた。","母は紙を白いまま畳んだ。ポケットには明日が一日ぶん入った。"),
("千年の息継ぎ","whale pull / stars","白鯨が息を吸うたび港の鐘が一つ若返る。ミオは最初の雨瓶を海に返した。","小さな瓶が割れ、鯨が息を吐いた。誰からも借りていない雨が降った。"),
)

def cast(g,e,shape,delay,phase,seed):
    x,y=g.player.center;bx,by=e.x+12,e.y+12
    def hit(kind,xx,yy,extra=0,r=29):
        g.add_boss_hazard(kind,max(40,min(760,xx)),max(70,min(535,yy)),delay+extra,r,.46,105)
    def circle(kind,cx,cy,n,radius,step=0,gap=-1):
        for j in range(n):
            if j!=gap:
                a=math.tau*j/n+seed*.38
                hit(kind,cx+radius*math.cos(a),cy+radius*math.sin(a),j*step,22)
    if shape=="rain":
        for j in range(5):hit("meteor",x-104+j*52,y+(-1)**j*38,.11*j)
    elif shape=="gate":
        for j in range(7):
            if j!=(seed%7):hit("down",83+106*j,y,0,18)
    elif shape=="post":g.aimed_fan(bx,by,x,y,delay)
    elif shape=="echo":g.aimed_fan(800-bx,by,x,y,delay+.35)
    elif shape=="cross":
        hit("down",x,y,0,16);hit("across",x,y,.49,18)
    elif shape=="oven":circle("fire_pillar",x,y,6,65,.09,seed%6)
    elif shape=="ring":circle("quake",400,300,10,125,.035)
    elif shape=="embers":
        for j in range(5):hit("fire_pillar",x+(j-2)*42,y,j*.16,23)
    elif shape=="rail":
        for j in range(4):hit("across",x,115+j*110,.21*j,20)
    elif shape=="pulse":
        for j in range(3):hit("quake",x,y,.66*j,36+12*j)
    elif shape=="pull":g.add_boss_hazard("pull",bx,by,delay,230,.75,112)
    elif shape=="stamp":
        for dx,dy in ((-47,-47),(47,-47),(-47,47),(47,47)):hit("meteor",x+dx,y+dy)
        hit("quake",x,y,.58,37)
    elif shape=="drill":
        for j in range(6):hit("root_burst",bx+(x-bx)*j/5,by+(y-by)*j/5,.13*j)
    elif shape=="quake":hit("quake",x,y,0,62)
    elif shape=="cradle":
        for j in range(5):hit("wind_blast",x+74*math.sin(j*1.3),y-68+34*j,.18*j,33)
    elif shape=="ballot":
        for j in range(5):hit("down",125+135*j,y,.18*(j%2),14)
        hit("meteor",x,y,.93)
    elif shape=="seam":
        for j in range(7):hit("fire_pillar",x-120+40*j,y+(-1)**j*25,.13*j,23)
    elif shape=="silence":
        hit("meteor",x,y,.88,48);hit("across",x,y,1.25,13)
    elif shape=="moon":
        circle("meteor",400,300,8,105,.13,seed%8);hit("quake",800-x,600-y,.8,52)
    elif shape=="table":
        for j in range(6):hit("root_burst",305+95*(j%3),237+110*(j//3),.17*j,35)
    elif shape=="mirror":
        g.aimed_fan(bx,by,x,y,delay);g.aimed_fan(800-bx,600-by,x,y,delay+.61)
    elif shape=="beacon":
        for j in range(3):hit("down",x+(-1)**j*j*60,y,.38*j,24)
    elif shape=="fleet":
        for j in range(3):g.aimed_fan(130+270*j,90,x,y,delay+.29*j)
    elif shape=="fan":g.aimed_fan(bx,by,x+45,y,delay);g.aimed_fan(bx,by,x-45,y,delay+.4)
    elif shape=="anchor":
        hit("down",x,y,0,14);hit("quake",x,y,.6,60);hit("across",x,y,.94,16)
    elif shape=="gears":
        circle("fire_pillar",300,270,6,64,.07);circle("root_burst",500,325,6,64,.09)
    elif shape=="roots":
        for j in range(6):
            for side in (-1,1):hit("root_burst",x+side*(128-19*j),y-62+j*22,.17*j,20)
    elif shape=="steps":
        for j in range(7):hit("quake",x+(j-3)*32,y+(-1)**j*18,.22*j,20)
    elif shape=="audience":
        for j in range(4):g.aimed_fan(85+210*j,490,x,y,delay+.26*j)
    elif shape=="net":
        for j in range(4):hit("down",150+j*160,y,0,13)
        for j in range(3):hit("across",x,160+j*130,.48,12)
    elif shape=="ledger":
        for j in range(5):
            if j!=seed%5:hit("across",x,101+j*100,.12*j,19)
    elif shape=="stars":
        for j in (0,2,4,1,3):
            a=j*math.tau/5
            hit("meteor",x+93*math.cos(a),y+93*math.sin(a),(j*3%5)*.16,27)
    elif shape=="leap":
        for j in (0,1,3,4):hit("quake",x+(j-2)*51,y,j*.30,32)
    elif shape=="whale":
        g.add_boss_hazard("tidal_disk",x,y,max(g.shukuchi_cooldown+.7,2.15),316,.20)
    else:raise ValueError(shape)

def chapter_attack(g,e,chapter):
    title,score,_,_=CHAPTERS[chapter]
    a,b,_,c=score.split()
    phase=int(e.hp<=e.max_hp*.67)+int(e.hp<=e.max_hp*.33)
    # Close range invites the signature, distance draws out the counter-pattern.
    count=e.special_count;near=math.dist(g.player.center,(e.x+12,e.y+12))<155
    cycle=(a,c,b) if near or phase==0 else (a,b,c,b)
    shape=cycle[count%len(cycle)]
    cast(g,e,shape,.85,phase,chapter+count)
    if phase and shape!=a and count%2==0:cast(g,e,a,1.62,phase,chapter+count+1)
    if phase==2 and shape==a and a!="whale":cast(g,e,c,1.8,phase,chapter+count)
    g.tell(title+"！",1.3)
    e.special_count+=1;e.special_timer=max(2.75,4.25-.37*phase)
