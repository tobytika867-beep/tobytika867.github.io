"""地上編のあとに現れる境界遺跡と、灰の渡し場の物語。"""
import ash_wastes as wastes
import math
import pygame

AREAS = {"rift_ruins":"境界遺跡・六灯の回廊", "rift_quay":"魔界・灰の渡し場",
         "rift_tower":"魔界・逆さの灯台", "rift_registry":"魔界・塩の検札所",
         "rift_lock":"魔界・七番水門"}
OLD_AREAS=tuple(AREAS)
AREAS.update(wastes.NAMES)
HARBOR_RUMORS = (
    "空舟の舳先に、うちと同じ結び方の綱があった。海の向こうにも港がある。",
    "拾った冠を溶かしたら、内側に船の名が出た。あれはもと、霧鐘の青銅だ。",
    "灰をかぶった種が潮に乗ってきた。鉢に植えたら、ちゃんと芽が出たよ。",
    "沖で一打、間を置いて二打。あれは戦の合図じゃない。舟が道を失った合図だ。",
    "晴れた夜だけ川面に塔が映る。岸を見回しても、そんな塔は一本もないのに。",
)
# Object positions mark the feet of the artwork and the interaction point.
SITES = {
    "rift_ruins": (("石碑",215,290),("魔界の扉",400,148),("西街道へ",400,527)),
    "rift_quay": (("渡し守ナギ",265,335),("沈んだ渡し舟",540,300),("灯台への石段",400,123),("地上の遺跡へ",400,525)),
    "rift_tower": (("上の火皿",260,177),("下の霧鐘",540,177),("渡し場へ",400,525)),
}
LEDGERS=("魚の札","葦の札","星の札")
OUTCOMES={"salt_names":"名札を掲げた","salt_pass":"通行印を返した"}

def chapter_sites(game):
    area=game.interior
    if area in wastes.NAMES:return wastes.sites(game)
    if area=="rift_registry":
        witness="帆縫いのセト" if "rift_light" in game.chapter_flags else "潜り手のヨナ"
        return ((witness,206,310),("検札日誌",545,322),("七番水門へ",400,142),("渡し舟で戻る",400,516))
    if area=="rift_lock":
        routes=()
        if "salt_home" in game.chapter_flags:
            routes=tuple((d[0]+"へ",95+148*i,103) for i,d in enumerate(wastes.REGIONS) if i==0 or wastes.flag(i-1,"win") in game.chapter_flags)
            if wastes.flag(4,"win") in game.chapter_flags:routes+=(("灰冠宮への道",685,357),)
        return routes+tuple((name,210+190*i,230) for i,name in enumerate(LEDGERS))+(("名札の掲示台",245,381),("夜渡りの印箱",555,381),("検札所へ",400,510))
    if area=="rift_quay" and "rift_ferry" in game.chapter_flags:
        return SITES[area]+(("対岸行きの舟",184,230),)
    return SITES[area]

def objective(flags):
    if "salt_home" in flags:
        return wastes.goal(flags)
    if flags.intersection(OUTCOMES):
        return "渡し場に戻ってナギに七隻目のことを伝えよう。"
    if "salt_open" in flags:
        return "水門の掲示台か印箱を選び、七隻目の通し方を決めよう。"
    if {"salt_log","salt_witness"}<=flags:
        return "七番水門の三枚の札を、舟が通った順に押そう。"
    if "salt_cross" in flags:
        return "検札所で生き証人と日誌の両方を調べよう。"

    if "rift_ferry" in flags:
        return "灰の渡し場に航路が戻った。王城の国王に知らせよう。" if "rift_report" not in flags else "灰の渡し場の西桟橋から対岸行きの舟に乗ろう。"
    if "rift_light" in flags or "rift_bell" in flags:
        return "渡し場に戻り、ナギに合図が届いたか聞こう。"
    if "rift_wick" in flags:
        return "北の灯台へ。番兵を倒し、火皿か霧鐘で船に合図しよう。"
    if "rift_task" in flags:
        return "渡し場の東、沈んだ舟から合図に使えるものを探そう。"
    if "rift_crossed" in flags:
        return "灰の渡し場で渡し守ナギに話しかけよう。"
    return "王城から西へ三地区。旧街道の北側に境界遺跡が現れた。"

def interact(game, site):
    flags=game.chapter_flags
    def travel(area,pos,line):
        game.royal_travel(area,pos)
        game.tell(line,6)
    if game.interior in wastes.NAMES or site=="灰冠宮への道" or site in {d[0]+"へ" for d in wastes.REGIONS}:
        wastes.interact(game,site);return
    light="rift_light" in flags
    if site=="対岸行きの舟":
        flags.add("salt_cross")
        travel("rift_registry",(400,457),"第二話　名簿にない舟　｜　六隻の帰港印の下に、小さな濡れた手形がある。")
    elif site=="渡し舟で戻る":
        travel("rift_quay",(218,232),"ナギが舫い綱を受け取った。")
    elif site in ("帆縫いのセト","潜り手のヨナ"):
        flags.add("salt_witness")
        if "salt_home" in flags:
            game.tell("新しい掲示板は低くした。子どもも自分の名に手が届く。" if "salt_names" in flags else "昨夜は三人渡した。名前？　聞かずに毛布を三枚出したよ。",7)
        elif light:
            game.tell("セト：灯に帆が透けた。魚の帆のあとに星が来た。間に一隻いたよ。",7)
        else:
            game.tell("ヨナ：鐘が鳴ると水底まで鎖が震えた。星の舟と魚の舟は続けて通ったよ。",7)
    elif site=="検札日誌":
        flags.add("salt_log")
        game.tell("日誌『晴天便。葦は最後ではない』。余白に『七隻目、子らを乗せる。名は伏す』。" if light else
                  "日誌『霧便。先頭は葦。星が魚を曳航』。余白に『七隻目、子らを乗せる。名は伏す』。",7)
    elif site=="七番水門へ":
        if {"salt_log","salt_witness"}<=flags:
            travel("rift_lock",(400,456),"朽ちた検札機に三枚の札。昔の通過順を再現すれば、水門が開く。")
        else:
            game.tell("水門の通過記録が欠けている。検札日誌と、当時を知る人を探そう。")
    elif site=="検札所へ":
        travel("rift_registry",(400,203),"塩の検札所に戻った。")
    elif site in LEDGERS:
        if "salt_open" in flags:
            game.tell("水門は開いている。係留柱に子どもの背丈の傷が七本ある。")
        else:
            order=(0,1,2) if light else (1,2,0)
            step=int("salt_first" in flags)+int("salt_second" in flags)
            if site!=LEDGERS[order[step]]:
                flags.difference_update(("salt_first","salt_second"))
                game.tell("鎖が巻き戻り、札がすべて外れた。証言と日誌をもう一度思い出そう。")
            else:
                flags.add(("salt_first","salt_second","salt_open")[step])
                game.tell(("最初の浮きが上がった。","二つ目の鎖が緩んだ。","水門が開いた。船底から小さな靴と、名前を消した乗船札が見つかった。")[step],6)
    elif site in ("名札の掲示台","夜渡りの印箱"):
        if "salt_open" not in flags:
            game.tell("先に水門の検札機を動かそう。")
        elif flags.intersection(OUTCOMES):
            game.tell("最初の朝便がもうすぐここを通る。")
        else:
            named=site=="名札の掲示台"
            choice="salt_preview_names" if named else "salt_preview_pass"
            if choice not in flags:
                flags.difference_update(("salt_preview_names","salt_preview_pass"))
                flags.add(choice)
                game.tell(("掲示すれば家族が名を探せる。" if named else "印を返せば匿名で渡れる。")+"ここでもう一度Eで決定。",6)
                return
            flags.difference_update(("salt_preview_names","salt_preview_pass"))
            flags.add("salt_names" if named else "salt_pass")
            game.tell("七枚の名札を掲げた。対岸から家族が名を呼ぶ声が返ってきた。" if named else "夜渡りの印を舟に戻した。名前を明かせない人も、今夜から渡れる。",7)
    elif site=="西街道へ":
        travel("capital",(-2400,15),"境界遺跡の前に戻った。")
    elif site=="魔界の扉":
        flags.add("rift_crossed")
        travel("rift_quay",(400,468),"魔界編　灰の渡し場　｜　岸に立つ少女が、空の舟を数えている。")
    elif site=="地上の遺跡へ":
        travel("rift_ruins",(400,206),"六つの灯が地上への道を照らしている。")
    elif site=="石碑":
        game.tell(game.conversation("rift_stone","石碑『霧の日は鐘。晴れた夜は灯。帰る者を選ぶな』",
                                    "石碑の裏には魚の落書き。霞港の子が描く魚と同じ形だ。"),6)
    elif site=="渡し守ナギ":
        if "ash_victory" in flags:
            flags.add("ash_dawn")
            game.tell("ナギ：数えてみて。あの日は六つだった帆が、今日は七つ。おかえり。　― 灰の朝・完 ―",10)
        elif flags.intersection(OUTCOMES):
            flags.add("salt_home")
            game.tell("ナギ：母さんの字だ。この小さい『ギ』、私にも名札を書いてくれてた。" if "salt_names" in flags else "ナギ：七隻目の船頭は母さんだった。今夜の便は、私に漕がせて。",7)
        elif "rift_ferry" in flags:
            game.tell("ナギ：七隻目だけ帰港印がない。西の桟橋から対岸の検札所へ行こう。",6)
        elif flags.intersection(("rift_light","rift_bell")):
            flags.add("rift_ferry")
            game.revival_feathers+=1
            game.tell(("帆の列が灯を追って帰った。" if "rift_light" in flags else "霧の中から、鐘に応えて小舟が一隻ずつ帰った。")+" ナギが不死鳥の羽を手渡した。",7)
        elif "rift_task" not in flags:
            flags.add("rift_task")
            game.tell("ナギ：魔王が奪ったのは舟じゃない。帰港の合図だよ。東の難破船を調べて。",7)
        else:
            game.tell(objective(flags),6)
    elif site=="沈んだ渡し舟":
        if "rift_task" in flags:
            flags.add("rift_wick")
            game.tell("舳先から真鍮の浮きを拾った。芯に油を含ませれば灯に、鎖で吊れば鐘になる。",7)
        else:
            game.tell("舳先に真鍮の浮きが結ばれている。持ち主が近くにいそうだ。")
    elif site=="灯台への石段":
        if "rift_wick" in flags:
            travel("rift_tower",(400,474),"逆さの灯台。砕けた冠から番兵が起き上がる。" if not flags.intersection(("rift_light","rift_bell")) else "灯台に渡し舟の合図が響いている。")
        else:
            game.tell("石段の先は灯台だ。舟の合図を取り戻す手掛かりが先にいる。")
    elif site=="渡し場へ":
        travel("rift_quay",(400,177),"灰の渡し場へ戻った。")
    elif any(e.hp>0 for e in game.enemies):
        game.tell("番兵が鎖を押さえている。倒せば合図を送れる。")
    elif flags.intersection(("rift_light","rift_bell")):
        game.tell("渡し場へ合図が届いている。")
    elif site in ("上の火皿","下の霧鐘"):
        light=site=="上の火皿"
        flags.add("rift_light" if light else "rift_bell")
        game.tell("浮きに火を灯した。沖に六つの帆が浮かぶ。ナギのもとへ。" if light else "浮きを鳴らした。霧の向こうから、櫂を打つ音が返る。ナギのもとへ。",7)
    game.last_clue=objective(flags)

def arch(screen,x,y,tick,scale=1):
    def rect(color,dx,dy,w,h):
        pygame.draw.rect(screen,color,(x+dx*scale,y+dy*scale,w*scale,h*scale))
    rect((44,31,64),-18,-34,36,34)
    for side in (-1,1):
        for row in range(4):
            rect((129-row*8,119-row*8,135-row*8),side*20-5,-8-row*8,10,7)
    rect((179,160,140),-24,-39,48,7)
    for i in range(6):
        rect((112,190,204),-15+i*6,-37,2,3)
    for i in range(5):
        rect((138,99,179),-12+i*5,-5-int((tick*.018+6*i)%24),2,4)

def draw(game,screen,font):
    area=game.interior
    if area in wastes.NAMES:
        wastes.draw(game,screen,font);return
    quay=area=="rift_quay"
    tower=area=="rift_tower"
    screen.fill((39,32,54) if tower else (38,58,65) if quay else (56,58,65))
    for y in range(52,596,30):
        for x in range(-30+(y//30%2)*26,800,64):
            pygame.draw.line(screen,(66,66,77),(x,y),(x+31,y),1)
    tick=pygame.time.get_ticks()
    if tower:
        for x in (260,540):
            for y in range(51,139,11):
                pygame.draw.ellipse(screen,(117,109,123),(x-3,y,7,15),2)
        for i in range(5):
            pygame.draw.ellipse(screen,(73+i*4,63+i*4,82+i*4),(180+i*18,128+i*10,440-i*36,226-i*20),2)
        if "rift_light" in game.chapter_flags:
            pygame.draw.polygon(screen,(255,182,94),[(248,134),(261,105),(272,134)])
        if "rift_bell" in game.chapter_flags:
            pygame.draw.circle(screen,(198,178,134),(540,146),17+int(tick/80)%9,2)
    elif area=="rift_registry":
        for y in (90,132):
            pygame.draw.rect(screen,(99,72,57),(65,y,670,12))
            for x in range(82,725,26):
                pygame.draw.rect(screen,(166,145,109),(x,y-20,15,20))
        pygame.draw.rect(screen,(117,85,61),(476,282,137,38))
        pygame.draw.rect(screen,(215,196,135),(525,278,46,9))
    elif area=="rift_lock":
        for y in (100,130):
            pygame.draw.rect(screen,(45,75,86),(45,y,710,20))
            for x in range(50,755,24):
                pygame.draw.line(screen,(105,144,147),(x,y+9),(x+12,y+9),2)
        for i in range(7):
            x=325+25*i
            lift=32 if "salt_open" in game.chapter_flags else 0
            pygame.draw.rect(screen,(140,109,77),(x,83-lift,18,64))
    elif not quay:
        for x in (125,675):
            for y in (165,288,408):
                pygame.draw.rect(screen,(102,104,111),(x-12,y-46,24,45))
                pygame.draw.rect(screen,(147,143,135),(x-17,y-48,34,7))
                pygame.draw.line(screen,(69,70,83),(x-4,y-39),(x+4,y-23),3)
        for i in range(6):
            pygame.draw.circle(screen,(205,181,128),(300+40*i,226),4)
    if quay:
        for x in (0,658):
            pygame.draw.rect(screen,(30,57,76),(x,40,142,560))
            for i in range(25):
                xx=x+(i*29+tick//100)%105
                pygame.draw.line(screen,(74,114,127),(xx,55+i*22),(xx+22,55+i*22),2)
        if "rift_ferry" in game.chapter_flags:
            for y in (160,285,412):
                pygame.draw.polygon(screen,(161,113,79),[(45,y),(106,y),(90,y+13),(58,y+13)])
                pygame.draw.polygon(screen,(218,196,148),[(76,y-35),(76,y-2),(53,y-2)])
    for site,x,y in chapter_sites(game):
        if site=="魔界の扉":
            arch(screen,x,y,tick,2)
        elif site=="渡し守ナギ":
            game.draw_npc(dict(name="ナギ",x=x,y=y,coat=(80,140,149),hair=(65,52,70),skin=(191,158,144)))
            continue
        elif site in ("帆縫いのセト","潜り手のヨナ"):
            game.draw_npc(dict(name=site,x=x,y=y,coat=(171,103,78) if "セト" in site else (69,128,157),hair=(85,71,64),skin=(206,169,132)))
            continue
        elif site in LEDGERS or site in ("名札の掲示台","夜渡りの印箱","検札日誌"):
            pygame.draw.rect(screen,(118,84,59),(x-20,y-30,40,30))
            pygame.draw.rect(screen,(219,199,144),(x-14,y-25,28,17))
            pygame.draw.line(screen,(104,84,68),(x-8,y-17),(x+7,y-17),2)
        elif site in ("対岸行きの舟","渡し舟で戻る","沈んだ渡し舟"):
            pygame.draw.polygon(screen,(123,83,62),[(x-43,y-19),(x+37,y-8),(x+17,y+4),(x-28,y)])
            pygame.draw.line(screen,(219,172,85),(x+12,y-25),(x+17,y-15),5)
        elif site in ("石碑","上の火皿","下の霧鐘"):
            pygame.draw.rect(screen,(107,98,112),(x-19,y-44,38,45),border_radius=5)
            color=(255,171,82) if site=="上の火皿" else (133,198,207)
            pygame.draw.circle(screen,color,(x,y-31),8,3)
            pygame.draw.line(screen,color,(x-9,y-12),(x+9,y-12),2)
        else:
            for i in range(4):
                pygame.draw.rect(screen,(95+i*10,91+i*9,103+i*8),(x-31+i,y-11+i*4,62-i*2,3))
        game.center_text(site,x,y+19,font,(219,201,168))
    near=nearest(game)
    if near:
        game.center_text("E　"+near,400,477,font,(255,212,116))

def nearest(game):
    site,x,y=min(chapter_sites(game),key=lambda p:math.dist(game.player.center,p[1:]))
    return site if math.dist(game.player.center,(x,y))<=63 else None
