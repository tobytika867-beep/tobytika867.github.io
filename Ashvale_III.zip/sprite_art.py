"""Small shaded pixel figures, assembled on transparent canvases."""
import pygame


def shade(rgb, amount):
    return tuple(max(0, min(255, c + amount)) for c in rgb)


def citizen(coat, hair, skin, role, stride=0, face=0):
    palette = dict(o=(38,34,40), h=hair, H=shade(hair,28), f=skin, s=shade(skin,-45),
                   c=coat, C=shade(coat,34), d=shade(coat,-38), g=(218,177,99),
                   b=(107,74,51), B=(150,106,68), t=(64,59,63), l=(98,89,85),
                   w=(217,208,177), a=(130,148,154), A=(198,211,203))
    rows = [
        '       ooooo      ','     ooHHhhhoo    ','    oHHHHhhhhho   ',
        '    oHhhHhhhhhho  ','    ohffhhffhhho  ','    osffofofsso   ',
        '     osfffffso    ','      osssfso     ','     oodwwdoo     ',
        '    oCCcwgcddoo   ','   oCCccbgccdddo  ','   oCcccbcccdodo  ',
        '   osfocbcccdofo  ','   ofsocbcccdofo  ','    ooobggbbdoo   ',
        '     oCccdcddo    ','     occddcddo    ','     otllootto    ',
        '     otllootto    ','     oBbo oBbo    ','    obbbo obbbo   ',
        '    ooooo ooooo   ']
    im=pygame.Surface((18,24),pygame.SRCALPHA)
    for y,row in enumerate(rows):
        for x,c in enumerate(row):
            if c!=' ': im.set_at((x,y+1),palette[c])
    if role=='guard':
        pygame.draw.polygon(im,palette['a'],[(4,5),(5,2),(9,1),(13,3),(14,6),(11,5),(5,6)])
        pygame.draw.line(im,palette['A'],(6,3),(10,2))
        pygame.draw.line(im,palette['a'],(5,12),(12,12),2)
    elif role=='king':
        pygame.draw.polygon(im,palette['g'],[(4,1),(7,3),(9,0),(11,3),(14,1),(13,5),(5,5)])
        pygame.draw.rect(im,(161,45,62),(8,3,2,2))
        pygame.draw.line(im,palette['w'],(5,10),(12,10),2)
    elif role=='elder':
        pygame.draw.polygon(im,palette['w'],[(6,8),(9,9),(12,8),(11,11),(8,12)])
    elif role=='traveler':
        pygame.draw.polygon(im,(178,135,75),[(2,6),(5,4),(7,1),(11,1),(13,4),(16,6)])
        pygame.draw.line(im,(95,63,48),(5,4),(13,4))
    if stride:
        moving=pygame.Surface((22,28),pygame.SRCALPHA)
        lean=face if abs(stride)==2 else 0
        moving.blit(im,(2+lean,1),pygame.Rect(0,0,18,17))
        for left,offset in ((0,stride),(9,-stride)):
            moving.blit(im,(left+2+offset,18-int(offset>0)),pygame.Rect(left,17,9,7))
        if face<0:
            moving=pygame.transform.flip(moving,True,False) if not lean else moving
        return pygame.transform.scale(moving,(39,49))
    return pygame.transform.scale(im,(32,42))


def monster_detail(sprite,kind,color,boss_id):
    d=pygame.draw
    if kind=='bat':
        for flip in (False,True):
            def pts(*pairs): return [(23-x if flip else x,y) for x,y in pairs]
            d.polygon(sprite,shade(color,-43),pts((1,8),(6,9),(10,14),(9,16),(6,13),(3,15)))
            d.lines(sprite,shade(color,45),False,pts((1,7),(6,8),(10,13)))
            d.line(sprite,shade(color,15),*pts((6,9),(5,13)))
        d.polygon(sprite,(73,49,64),[(9,8),(11,10),(13,10),(15,8),(14,15),(12,18),(9,15)])
        for x in (10,13): sprite.set_at((x,12),(255,208,112))
    elif kind=='stalfos':
        d.polygon(sprite,(177,169,147),[(6,4),(9,2),(15,2),(17,5),(16,9),(14,10),(10,10),(7,8)])
        d.line(sprite,(249,230,190),(8,4),(13,3),2)
        for x in (8,13): d.rect(sprite,(54,43,48),(x,6,3,2))
        d.polygon(sprite,(79,77,82),[(5,10),(10,10),(13,15),(11,18),(5,15)])
        for y in (12,14,16): d.line(sprite,(213,195,156),(9,y),(14,y-1))
        d.line(sprite,(161,146,124),(7,16),(5,21),2)
        d.line(sprite,(207,195,164),(15,17),(17,21),2)
    elif kind=='boss':
        dark,light=shade(color,-54),shade(color,48)
        if boss_id==5:
            d.polygon(sprite,dark,[(3,9),(7,7),(12,14),(17,7),(20,9),(23,22),(17,20),(14,23),(7,21),(1,23)])
            for x in (5,17):
                d.polygon(sprite,light,[(x-2,10),(x,7),(x+3,10),(x+1,12)])
            d.polygon(sprite,(75,62,72),[(7,6),(10,4),(15,5),(17,8),(15,13),(12,15),(8,12)])
            d.lines(sprite,(224,177,96),False,[(7,7),(6,2),(10,5),(12,1),(14,5),(18,2),(16,7)])
            for x in (9,13): d.line(sprite,(255,207,105),(x,9),(x+1,9))
            d.polygon(sprite,(220,125,72),[(12,14),(14,16),(12,19),(10,16)])
            for x in (5,16):d.line(sprite,light,(x+1,14),(x,20))
        else:
            for x in (5,15):
                d.polygon(sprite,dark,[(x,13),(x+4,14),(x+3,20),(x,21)])
                d.line(sprite,light,(x,13),(x+3,14))
            for y in (15,17,19):
                d.line(sprite,light,(10,y),(13,y-1))
