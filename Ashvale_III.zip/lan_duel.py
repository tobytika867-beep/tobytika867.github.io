"""Two-player local-network duel. Only the host advances combat."""
import terms
from stamp_notice import RejectedInput, show as show_stamp
import errno
import ipaddress
import math
import select
import socket
import struct
from time import monotonic

PORT = 41826
QUERY = b"AshvaleIII/Duel/1?"
ROOM = b"AshvaleIII/Duel/1!"
HELLO = b"ASHD001!"
INPUT = struct.Struct("!bbBB")
# x, y, facing, health, swing, guard, stun, walking frame
PLAYER = struct.Struct("!HHBBBBBB")
FACES = ("right","down_right","down","down_left","left","up_left","up","up_right")


class Fighter:
    def __init__(self, x, face):
        self.x, self.y, self.face, self.hp = x, 316, face, 6
        self.swing = self.guard = self.stun = self.cool = self.guard_cd = self.walk = 0.
        self.struck = False
        self.moving = False

    def step(self, dt, direction, actions):
        for attr in ("swing","guard","stun","cool","guard_cd"):
            setattr(self, attr, max(0., getattr(self, attr)-dt))
        self.moving = False
        if self.stun:
            return
        dx, dy = direction
        length = math.hypot(dx,dy)
        if length:
            self.face = round(math.atan2(dy,dx)*4/math.pi)%8
            self.x = min(750,max(50,self.x+dx/length*175*dt))
            self.y = min(505,max(125,self.y+dy/length*175*dt))
            self.walk += dt
            self.moving = True
        if actions & 2 and not self.guard_cd:
            self.guard, self.guard_cd = .25, .8
        if actions & 1 and not self.cool:
            self.swing, self.cool, self.struck = .34, .52, False

    def connects(self, other):
        if self.struck or self.stun or not .06 < self.swing <= .18:
            return False
        dx, dy = other.x-self.x, other.y-self.y
        angle = self.face*math.pi/4
        return math.hypot(dx,dy)<=69 and dx*math.cos(angle)+dy*math.sin(angle)>=-4

    def packet(self):
        return PLAYER.pack(round(self.x),round(self.y),self.face,self.hp,
                           round(self.swing*100),round(self.guard*100),round(self.stun*100),
                           (0,1,2,1)[int(self.walk/.12)%4] if self.moving else 1)


class Match:
    def __init__(self):
        self.players = [Fighter(250,0),Fighter(550,4)]
        self.done = False

    def advance(self, dt, dirs, actions):
        if self.done:
            return
        for p,d,a in zip(self.players,dirs,actions):
            p.step(dt,d,a)
        hits = [p.connects(self.players[1-i]) for i,p in enumerate(self.players)]
        for i,hit in enumerate(hits):
            if hit:
                p,other = self.players[i],self.players[1-i]
                p.struck = True
                if other.guard:
                    other.guard = other.guard_cd = 0
                    p.stun = .55
                else:
                    other.hp -= 1
        self.done = any(p.hp==0 for p in self.players)

    def packet(self):
        return b"".join(p.packet() for p in self.players)


class Room:
    notice_packet = bytes([255]) * (PLAYER.size * 2)
    read_size = 4096
    port, query, advert, hello = PORT, QUERY, ROOM, HELLO
    def __init__(self):
        self.mode = "menu"
        self.sockets = []
        self.error = self.address = ""
        self.peer = None
        self.discovery = None
        self.rooms = {}
        self.is_host = False
        self.stamps_enabled = terms.read().get("stamps",False)
        self.actions = self.remote_actions = 0
        self.remote_dir = (0,0)
        self.tx = bytearray()
        self.rx = bytearray()
        self.match = Match()
        self.snapshot = self.match.packet()
        self.ready = False
        self.clock = self.query_time = 0
        self.local_ips = ""

    def sock(self, kind):
        s = socket.socket(socket.AF_INET,kind)
        self.sockets.append(s)
        s.setblocking(False)
        return s

    def reject_input(self):
        try:
            self.peer.settimeout(.25)
            self.peer.sendall(bytes(self.tx) + self.notice_packet)
            self.tx.clear()
        finally:
            raise ConnectionError("invalid input")

    def close(self):
        for s in self.sockets:
            s.close()
        self.sockets.clear()

    def host(self):
        self.is_host = True
        self.listener = self.sock(socket.SOCK_STREAM)
        self.listener.bind(("",self.port))
        self.listener.listen(1)
        try:
            self.discovery = self.sock(socket.SOCK_DGRAM)
            self.discovery.bind(("",self.port))
        except OSError:
            self.discovery = None
        ips = socket.gethostbyname_ex(socket.gethostname())[2]
        self.local_ips = " / ".join(ip for ip in ips if not ip.startswith("127."))
        self.mode = "waiting"

    def search(self):
        self.discovery = self.sock(socket.SOCK_DGRAM)
        self.discovery.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)
        self.discovery.bind(("",0))
        self.mode = "search"

    def join(self, ip):
        ip = str(ipaddress.IPv4Address(ip))
        self.peer = self.sock(socket.SOCK_STREAM)
        result = self.peer.connect_ex((ip,self.port))
        if result not in (0,errno.EINPROGRESS,errno.EWOULDBLOCK,errno.EALREADY,10035):
            raise ConnectionError
        self.mode = "connecting"
        self.deadline = monotonic()+6

    def handshake(self):
        self.peer.setblocking(False)
        self.peer.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
        self.tx.extend(self.hello)
        self.last_rx = monotonic()
        self.mode = "playing"

    def poll_connection(self):
        now = monotonic()
        if self.mode in ("waiting","search") and self.discovery:
            if self.mode=="search" and now>=self.query_time:
                self.query_time = now+1
                try:
                    self.discovery.sendto(self.query,("255.255.255.255",self.port))
                except OSError:
                    pass
            for _ in range(12):
                try:
                    data, addr = self.discovery.recvfrom(80)
                except BlockingIOError:
                    break
                if self.is_host and data==self.query:
                    self.discovery.sendto(self.advert,addr)
                elif not self.is_host and data==self.advert:
                    self.rooms[addr[0]]=now
            self.rooms = {ip:t for ip,t in self.rooms.items() if now-t<4}
        if self.mode=="waiting":
            try:
                self.peer,_ = self.listener.accept()
            except BlockingIOError:
                return
            self.sockets.append(self.peer)
            self.listener.close()
            self.handshake()
        if self.mode=="connecting":
            _,w,e = select.select([], [self.peer], [self.peer], 0)
            if now>self.deadline or e:
                raise ConnectionError
            if not w:
                return
            if self.peer.getsockopt(socket.SOL_SOCKET,socket.SO_ERROR):
                raise ConnectionError
            self.handshake()
        if self.mode!="playing":
            return
        try:
            data = self.peer.recv(self.read_size)
            if not data:
                raise ConnectionError
            self.rx.extend(data)
            self.last_rx = now
        except BlockingIOError:
            pass
        if now-self.last_rx>6:
            raise ConnectionError
        if not self.ready and len(self.rx)>=len(self.hello):
            if self.rx[:len(self.hello)]!=self.hello:
                raise ConnectionError
            del self.rx[:len(self.hello)]
            self.ready = True
    def update(self, dt, direction):
        self.poll_connection()
        if self.mode != "playing":
            return
        size = INPUT.size if self.is_host else PLAYER.size*2
        while self.ready and len(self.rx)>=size:
            packet = bytes(self.rx[:size])
            del self.rx[:size]
            if self.is_host:
                x,y,a,reserved = INPUT.unpack(packet)
                if max(abs(x),abs(y))>1 or a>3 or reserved:
                    self.reject_input()
                self.remote_dir = (x,y)
                self.remote_actions |= a
            else:
                if packet == self.notice_packet:
                    raise RejectedInput
                for off in (0,PLAYER.size):
                    x,y,face,hp,sw,gd,st,frame=PLAYER.unpack_from(packet,off)
                    if x>800 or y>600 or face>7 or hp>6 or frame>2:
                        raise ConnectionError
                self.snapshot = packet
        self.clock += dt
        if self.ready and self.is_host:
            self.match.advance(dt,(direction,self.remote_dir),(self.actions,self.remote_actions))
            self.actions = self.remote_actions = 0
            self.snapshot = self.match.packet()
        if self.ready and self.clock>=1/30 and not self.tx:
            self.clock = 0
            if self.is_host:
                self.tx.extend(self.snapshot)
            else:
                self.tx.extend(INPUT.pack(*direction,self.actions,0))
                self.actions = 0
        if self.tx:
            try:
                sent = self.peer.send(self.tx)
                del self.tx[:sent]
            except BlockingIOError:
                pass


def run(screen, font, sprites):
    import pygame as pg
    room = Room()
    clock = pg.time.Clock()
    chosen = 0
    def label(text, x, y, color=(237,230,209)):
        surf = font.render(text,True,color)
        screen.blit(surf,surf.get_rect(center=(x,y)))
    try:
        while True:
            dt = min(.05,clock.tick(60)/1000)
            try:
                for event in pg.event.get():
                    if event.type==pg.QUIT:
                        return False
                    if event.type!=pg.KEYDOWN:
                        continue
                    k = event.key
                    if k==pg.K_ESCAPE:
                        return True
                    if room.mode in ("menu","search") and k==pg.K_F2:
                        room.stamps_enabled = not room.stamps_enabled
                        continue
                    if room.mode=="menu":
                        if k==pg.K_h:
                            room.host()
                        elif k==pg.K_j:
                            room.search()
                    elif room.mode=="search":
                        rooms = sorted(room.rooms)
                        if k==pg.K_BACKSPACE:
                            room.address = room.address[:-1]
                        elif k in (pg.K_UP,pg.K_DOWN) and rooms:
                            chosen = (chosen+(1 if k==pg.K_DOWN else -1))%len(rooms)
                        elif k in (pg.K_RETURN,pg.K_KP_ENTER):
                            ip = room.address or (rooms[chosen%len(rooms)] if rooms else "")
                            if ip:
                                try:
                                    room.join(ip)
                                except ValueError:
                                    room.error = "IPv4の数字とピリオドを確認してください"
                        elif event.unicode and event.unicode in "0123456789." and len(room.address)<15:
                            room.address += event.unicode
                    elif room.mode=="playing" and room.ready and not getattr(event,"repeat",False):
                        if k==pg.K_j:
                            room.actions |= 1
                        if k==pg.K_p:
                            room.actions |= 2
                keys = pg.key.get_pressed()
                direction = (int(keys[pg.K_d])-int(keys[pg.K_a]),int(keys[pg.K_s])-int(keys[pg.K_w]))
                room.update(dt,direction)
            except RejectedInput:
                room.close()
                if room.stamps_enabled:
                    show_stamp()
                return True
            except OSError:
                room.close()
                room.mode = "error"
            screen.fill((24,35,45))
            if room.mode=="playing" and room.ready:
                pg.draw.rect(screen,(72,87,78),(25,95,750,440),border_radius=12)
                pg.draw.rect(screen,(162,151,118),(25,95,750,440),4,border_radius=12)
                pg.draw.circle(screen,(89,99,84),(400,315),92,2)
                players = [PLAYER.unpack_from(room.snapshot,off) for off in (0,PLAYER.size)]
                for i,(x,y,face,hp,swing,guard,stun,frame) in enumerate(players):
                    color = ((102,206,249),(255,166,111))[i]
                    pg.draw.ellipse(screen,(46,60,54),(x-15,y-4,30,10))
                    sprite = sprites[FACES[face]][frame]
                    screen.blit(sprite,sprite.get_rect(midbottom=(x,y)))
                    angle = face*math.pi/4
                    if swing:
                        angle += (34-swing)/34*1.8-.9
                    hand = (x+round(9*math.cos(angle)),y-13+round(7*math.sin(angle)))
                    tip = (hand[0]+round((45 if swing else 16)*math.cos(angle)),hand[1]+round((45 if swing else 16)*math.sin(angle)))
                    pg.draw.line(screen,(255,227,153) if swing else (202,210,210),hand,tip,4)
                    if guard:
                        pg.draw.circle(screen,(142,223,255),(x,y-18),24,3)
                    label("気絶" if stun else f"{i+1}P",x,y-54,color)
                    label(f"{i+1}P  体力 {hp}/6",210+i*380,44,color)
                label("WASD 移動　J 剣　P ジャストガード　Esc 退室",400,568)
                if min(p[3] for p in players)==0:
                    title = "引き分け" if players[0][3]==players[1][3] else ("1P 勝利" if players[0][3] else "2P 勝利")
                    label(title+"　 Escで退室",400,258)
                else:
                    label("あなたは "+("1P" if room.is_host else "2P"),400,77)
            else:
                label("白暦の海　通信闘技場",400,104,(249,211,133))
                if room.mode=="menu":
                    label("H　部屋を作る",400,236)
                    label("J　同じWi-Fiの部屋を探す",400,292)
                elif room.mode=="waiting":
                    label("参加者を待っています",400,216)
                    label("ホストのIPv4　"+(room.local_ips or "ipconfig で確認"),400,298)
                elif room.mode=="search":
                    rooms=sorted(room.rooms)
                    label("部屋を選択してEnter　 ↑↓で切替",400,196)
                    label(rooms[chosen%len(rooms)] if rooms else "近くの部屋を検索中…",400,255)
                    label("直接参加する場合はホストのIPv4を入力",400,336)
                    label(room.address+"▏",400,381)
                    if room.error:
                        label(room.error,400,435)
                elif room.mode=="error":
                    label("通信が終了しました。Escでホームへ",400,244)
                    label("再接続は同じWi-Fi・部屋のIPv4を確認してください",400,300)
                else:
                    label("接続しています…",400,260)
                if room.mode in ("menu","search"):
                    label("F2　別窓の警告スタンプ演出　"+("オン" if room.stamps_enabled else "オフ"),400,494)
                label("Esc　ホームに戻る",400,546)
            pg.display.flip()
    finally:
        room.close()
