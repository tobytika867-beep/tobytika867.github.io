"""七番水門の向こう。五地方の街道と灰冠宮。"""
from functools import lru_cache
import math
import random
import pygame

# Region, ground, stone, light, witness, testimony, two landmarks, required powers, guardian, resolution
REGIONS = (
    ("窯灰盆地",(64,44,43),(108,70,58),(247,146,80),"窯焚きのロク","大窯にはまだ夜勤の連中がいる。排煙筒を開けてから坑口を支えてくれ。","塞がれた排煙筒","崩れた坑口","wind","earth","煤喰いの炉竜","夜勤明けの七人が、自分の足で灰の朝を歩いた。"),
    ("骨潮干潟",(42,53,58),(71,91,91),(107,214,204),"潮読みのサラ","潮が逆流して舟が骨杭に刺さった。杭を焼き、漂着した船頭を助けて。","折れた骨杭","船頭の小舟","flame","heal","骨潮の船喰い","舟は子どもを乗せて戻った。空いた一席には船頭の櫂が置かれた。"),
    ("硝子森",(51,44,65),(99,79,113),(195,163,239),"苗守りのイオ","森は生きてる。硝子の根に水を戻せば、芽が風の通り道を教える。","白化した根","胞子の梢","heal","wind","硝晶の梟","風の向く方へ、透明だった森に一筋の緑が走った。"),
    ("裂鐘高原",(57,55,49),(99,91,74),(233,199,108),"鐘鋳のミナ","あの鐘は避難の合図だった。倒れた鐘架を立て、切れた導線に一度だけ雷を。","倒れた鐘架","断線した避雷針","earth","lightning","雷骸の鐘守","三打、休んで一打。地下壕から同じ節が返ってきた。"),
    ("無明運河",(37,41,58),(70,75,104),(119,174,231),"写字生のリル","大魔王は救難の声を集めて王冠を鳴らす。記録機を起こし、凍った送声管を解いて。","眠る記録機","凍った送声管","lightning","flame","夜を綴じる獣","声の行き先が変わった。初めて王冠から、大魔王自身の声だけが聞こえた。"),
)
POWERS=dict(wind="嵐(N)",earth="大地(M)",flame="焔(B)",heal="回復(Y)",lightning="雷(G)")
SIZE=7
CAMP=(0,6)
WITNESS=(1,1)
FIRST=(5,5)
SECOND=(0,0)
KEEP=(6,0)
MEMORY=(4,2)
THRONE="ash_throne"
FINAL="灰冠の大魔王ヴァルド"
def key(r,x,y):
    return f"waste_{r}_{x}_{y}"
CELLS={key(r,x,y):(r,x,y) for r in range(5) for x in range(SIZE) for y in range(SIZE)}
NAMES={area:f"{REGIONS[r][0]}・{x+1}列{y+1}区" for area,(r,x,y) in CELLS.items()}
NAMES[THRONE]="灰冠宮・無声の玉座"
DIRS=(("北へ",0,-1,400,95),("南へ",0,1,400,534),("西へ",-1,0,65,320),("東へ",1,0,735,320))
def flag(r,step):return f"waste_{r}_{step}"

@lru_cache(maxsize=5)
def roads(r):
    rng=random.Random(8005+r)
    graph={(x,y):set() for x in range(SIZE) for y in range(SIZE)}
    seen={CAMP}
    stack=[CAMP]
    while stack:
        x,y=stack[-1]
        choices=[(x+dx,y+dy) for _,dx,dy,*_ in DIRS if (x+dx,y+dy) in graph and (x+dx,y+dy) not in seen]
        if not choices:
            stack.pop()
            continue
        dest=rng.choice(choices)
        graph[x,y].add(dest); graph[dest].add((x,y))
        seen.add(dest); stack.append(dest)
    for x,y in graph:
        for dx,dy in ((1,0),(0,1)):
            dest=x+dx,y+dy
            if dest in graph and rng.random()<.23:
                graph[x,y].add(dest);graph[dest].add((x,y))
    return graph

def target(r,flags):
    d=REGIONS[r]
    for tag,pos,name in (("witness",WITNESS,d[4]),("first",FIRST,d[6]),("second",SECOND,d[7]),("win",KEEP,d[10])):
        if flag(r,tag) not in flags:return pos,name
    return CAMP,"水門への道標"

def goal(flags):
    if "ash_victory" in flags:return "大魔王を討伐した。灰の渡し場でナギと朝を迎えよう。" if "ash_dawn" not in flags else "魔界に朝が戻った。残った土地と旅の記録を探そう。"
    for r,d in enumerate(REGIONS):
        if flag(r,"win") not in flags:
            pos,name=target(r,flags)
            return f"七番水門から{d[0]}へ。{pos[0]+1}列{pos[1]+1}区の{name}を探そう。"
    return "五地方から声が帰った。七番水門の灰冠宮への道から玉座へ。"

def sites(g):
    if g.interior==THRONE:return (("水門へ帰る",400,520),)
    r,x,y=CELLS[g.interior];d=REGIONS[r]
    points=[(name,px,py) for name,dx,dy,px,py in DIRS if (x+dx,y+dy) in roads(r)[x,y]]
    landmark={CAMP:"野営火",WITNESS:d[4],FIRST:d[6],SECOND:d[7],KEEP:"王冠の鎖",MEMORY:"遺された手紙"}.get((x,y))
    if landmark:points.append((landmark,400,258))
    if (x,y)==CAMP or ((x,y)==KEEP and flag(r,"win") in g.chapter_flags):points.append(("水門へ帰る",245,400))
    return tuple(points)

def power(g,power):
    if g.interior not in CELLS:return False
    r,x,y=CELLS[g.interior];d=REGIONS[r]
    pos,name=target(r,g.chapter_flags)
    if pos not in (FIRST,SECOND) or pos!=(x,y) or math.dist(g.player.center,(400,258))>68:return False
    first=pos==FIRST
    if power!=d[8 if first else 9]:return False
    g.chapter_flags.add(flag(r,"first" if first else "second"))
    g.burst_effect("heal",400,258,d[3],22)
    g.last_clue=goal(g.chapter_flags)
    g.tell(name+"が動き出した。"+g.last_clue,7)
    return True

def travel(g,area,pos):
    g.hostile_attacks.clear()
    g.royal_travel(area,pos)
    g.invulnerable=max(g.invulnerable,1)
    if area in CELLS:g.chapter_flags.add("seen_"+area)
    g.last_clue=goal(g.chapter_flags)

def interact(g,site):
    f=g.chapter_flags
    if site=="灰冠宮への道":
        travel(g,THRONE,(400,455))
        g.tell("ヴァルド：声を返せば、私が守った国は灰になる。お前はその朝を見届けられるか。",7)
        return
    for r,d in enumerate(REGIONS):
        if site==d[0]+"へ":
            travel(g,key(r,*CAMP),(400,350))
            g.tell(d[0]+"。野営火の先には強い魔物がいる。Pで街道図を開ける。",5)
            return
    if site=="水門へ帰る":
        travel(g,"rift_lock",(400,440));return
    r,x,y=CELLS[g.interior];d=REGIONS[r]
    for name,dx,dy,_,_ in DIRS:
        if name==site:
            travel(g,key(r,x+dx,y+dy),(400-285*dx,320-168*dy));return
    if site=="野営火":
        g.hp=g.max_hp
        g.tell("火を囲んで休んだ。"+goal(f),6)
    elif site==d[4]:
        f.add(flag(r,"witness"));g.tell(d[4]+"："+d[5],8)
    elif site=="遺された手紙":
        fresh=flag(r,"letter") not in f
        f.add(flag(r,"letter"))
        g.revival_feathers+=int(fresh)
        line=("灰の上にもパンの焼ける匂いは残る。","七隻目は沈んじゃいない。帰る岸がなかっただけだ。","明日生まれる子に、緑という色の名を残したい。","鐘を割るな。戦が終われば時を告げる。","陛下にも、名前を呼んでくれる人がいた。")[r]
        g.tell("手紙『"+line+"』"+("　包みから不死鳥の羽を得た。" if fresh else ""),7)
    elif site=="王冠の鎖":
        if flag(r,"win") in f:g.tell(d[11],7)
        elif flag(r,"second") not in f:g.tell(goal(f),6)
        elif any(e.hp>0 for e in g.enemies):g.tell("鎖の主を倒せば街道が解放される。")
        else:
            g.enemies.append(g.waste_guardian(r))
            g.capture_boss();g.tell(d[10]+"が鎖から姿を現した！")
    else:
        pos,name=target(r,f)
        g.tell(name+"に「"+POWERS[d[8 if pos==FIRST else 9]]+"」の力を使おう。" if pos in (FIRST,SECOND) and site==name else goal(f),6)
    g.last_clue=goal(f)

@lru_cache(maxsize=48)
def background(area):
    throne=area==THRONE
    r,x,y=CELLS.get(area,(4,3,3));d=REGIONS[r]
    rng=random.Random(700*r+31*x+y)
    s=pygame.Surface((800,600));s.fill(d[1])
    for _ in range(210):
        a,b=rng.randrange(800),rng.randrange(40,600)
        pygame.draw.line(s,d[2],(a,b),(a+rng.randrange(2,11),b))
    for _ in range(24):
        a,b=rng.randrange(800),rng.randrange(65,595)
        pygame.draw.lines(s,tuple(c//2 for c in d[1]),False,((a,b),(a+7,b-5),(a+11,b-4),(a+21,b-13)),2)
    for a in (140,655):
        for b in (165,433):
            h=rng.randrange(23,63)
            if r in (0,3) or throne:
                pygame.draw.polygon(s,d[2],((a-16,b),(a-14,b-h),(a-2,b-h+9),(a+8,b-h+2),(a+16,b)))
                pygame.draw.line(s,d[3],(a,b-h+12),(a+5,b-10),2)
            elif r==2:
                pygame.draw.polygon(s,d[2],((a-14,b),(a-24,b-h+12),(a-5,b-20),(a+5,b-h),(a+12,b)))
            else:
                pygame.draw.ellipse(s,d[2],(a-43,b-10,86,19))
                pygame.draw.arc(s,d[3],(a-27,b-7,54,10),0,3,1)
    if not throne:
        # Old traffic has worn paths only in directions that actually connect.
        base=tuple(min(255,c+10) for c in d[1])
        for _,dx,dy,px,py in DIRS:
            if (x+dx,y+dy) in roads(r)[x,y]:
                pygame.draw.line(s,base,(400,320),(400+450*dx,320+340*dy),39)
        for i in range(9):
            a=32+(x*19+i*91)%717
            b=57+(y*7+i*3)%40
            if r==0:
                pygame.draw.polygon(s,(43,36,41),((a-14,b+14),(a-7,b-13),(a+4,b-10),(a+12,b+14)))
                pygame.draw.line(s,d[3],(a-3,b-7),(a+3,b+4),2)
            elif r==1:
                pygame.draw.arc(s,d[2],(a-16,b,32,22),0,3.1,3)
            elif r==2:
                pygame.draw.polygon(s,d[2],((a-7,b+15),(a-11,b-6),(a,b-21),(a+6,b-4),(a+3,b+15)))
                pygame.draw.line(s,d[3],(a,b-18),(a-4,b+4))
            elif r==3:
                pygame.draw.lines(s,d[2],False,((a-10,b+17),(a-9,b-17),(a+8,b-13),(a+7,b+17)),3)
                pygame.draw.line(s,d[3],(a,b-14),(a,b+2))
            else:
                pygame.draw.rect(s,d[2],(a,b-6,8,27))
                pygame.draw.line(s,(85,60,78),(a+8,b-3),(a+79,b+9),2)
    if throne:
        for i in range(6):
            pygame.draw.circle(s,d[2],(400,280),60+24*i,2)
        pygame.draw.polygon(s,(111,64,82),((335,170),(320,90),(365,127),(400,71),(435,127),(480,90),(465,170)))
    return s

def draw(g,s,font):
    s.blit(background(g.interior),(0,0))
    if g.interior==THRONE and "ash_victory" in g.chapter_flags:
        g.center_text("大魔王討伐　灰の空に夜明けが差す",400,190,font,(252,213,151))
    tick=pygame.time.get_ticks()//60
    for i in range(22):
        x=(i*97+tick*(1+i%2))%800
        y=62+(i*79+tick//2)%510
        pygame.draw.line(s,(140,126,134),(x,y),(x+2,y-1))
    for name,x,y in sites(g):
        if name.startswith(("北","南","東","西")) or name=="水門へ帰る":
            pygame.draw.rect(s,(133,105,76),(x-18,y-13,36,10))
            pygame.draw.rect(s,(97,77,62),(x-3,y-3,6,9))
        elif g.interior in CELLS and name==REGIONS[CELLS[g.interior][0]][4]:
            g.draw_npc(dict(name=name,x=x,y=y,coat=(121,101,123),hair=(75,62,64),skin=(201,162,141)));continue
        else:
            color=(253,174,87) if name=="野営火" else (181,161,184)
            pygame.draw.polygon(s,color,((x-13,y),(x-5,y-19),(x+2,y-12),(x+7,y-27),(x+13,y)))
        g.center_text(name,x,y+17,font,(226,210,178))

def map_view(g,s,font):
    r,x,y=CELLS[g.interior];goalpos,name=target(r,g.chapter_flags)
    g.center_text(REGIONS[r][0]+"　街道図",400,82,font,(255,219,144))
    for (a,b),neighbors in roads(r).items():
        center=(238+54*a,137+52*b)
        for c,e in neighbors:
            pygame.draw.line(s,(112,97,109),center,(238+54*c,137+52*e),3)
    for a,b in roads(r):
        seen="seen_"+key(r,a,b) in g.chapter_flags
        color=(242,193,94) if (a,b)==goalpos else (144,174,173) if seen else (76,71,88)
        pygame.draw.rect(s,color,(226+54*a,125+52*b,24,24))
        if (a,b)==(x,y):pygame.draw.circle(s,(160,248,246),(238+54*a,137+52*b),6)
    g.center_text(f"累計プレイ {int(g.town_time)//3600}時間{int(g.town_time)//60%60:02}分",400,552,font,(180,174,181))
    g.center_text("水色＝現在地　金＝"+name+"　灰＝未踏　 /で閉じる",400,509,font,(229,218,193))
