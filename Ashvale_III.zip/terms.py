"""Local first-run agreement and optional event preferences."""
import json
import os
import sys
from pathlib import Path
from tempfile import NamedTemporaryFile

PATH = (Path(sys.executable if getattr(sys,"frozen",False) else __file__).resolve().parent / "ashvale_preferences.json")
VERSION = 1
PAGES = (
("遊ぶ前に", "この規約は『星図の旅人 III　白暦の海』の一人用の冒険、同じネットワークでの対戦、本編への協力参加に共通する遊び方の約束です。初めて起動した方は、各ページを読んでから最後の画面で決定してください。\n通信中に規定外の操作値を受けた場合の写真スタンプ演出があります。初期設定はオンです。表示場所、内容、閉じ方、切り替え方法は最終ページにまとめています。"),
("冒険とセーブ", "一人用の冒険では、このパソコンで名前を決め、探索、会話、装備、能力の取得を進めます。進行はゲームのセーブファイルに保存されます。新しい冒険で既存の記録を上書きするときには、画面に表示される案内を確認してください。\n別のフォルダーで新版を起動した場合は、以前のフォルダーの記録を使うか、新たに遊ぶかを自分で決めてください。家族や友達の記録を使う場合は、先に持ち主に確認してください。"),
("通信する相手と部屋", "通信機能は同じWi-Fiなど、互いの端末が接続できるネットワークで利用します。部屋を作る人がホスト、そこへ接続する人が参加者です。部屋の自動検索やIPv4アドレスの入力で参加するときは、遊ぶ約束をした相手の部屋を選んでください。\n対戦の募集と、本編の仲間の募集は入口が違います。部屋名や待機画面を確認し、知らない相手に参加されたときは募集を終了できます。"),
("協力プレイと進行", "本編の協力ではホストが自分の冒険を開き、参加者はもう一人の旅人として同じ場面に加わります。扉を通る、会話を進める、イベントを選ぶなどの判断はホストが担当します。大事な選択の前には、一緒に遊ぶ相手とも相談してください。\nホストの画面には会話や冒険の情報が表示され、そのゲーム画面を参加者も見ます。撃破や進行はホストの記録に反映されます。協力を終えるときは相手に知らせると、途中で部屋が閉じた理由が伝わります。"),
("対戦時の約束", "闘技場では移動、剣、ガードを使って対戦します。勝敗やダメージを決める計算はホスト側で行います。相手の操作を妨げる目的で通信を繰り返したり、対戦相手に伝えずにゲームの判定を書き換えたりする使い方は控えてください。\n練習方法や独自のルールを決めるときは、対戦前に両者で確認してください。上手な回避、長い直線移動、きれいに決まった連続ガードはいずれも普通のプレイで起こります。"),
("入力の観察と通信の扱い", "本編の操作記録では、ガードが命中より何秒早かったか、似た移動が続いたかなどを振り返れます。観察結果を人に見せるときは、技の種類、試行回数、通信の状態も一緒に確かめてください。一度の成功やタイミングの偏りだけで相手を非難しないでください。\n正規の通信入力で表現できる値には範囲があります。これを外れた値が届くとホストはその接続を終了します。表示される警告は受信したデータについての通知です。意図的な改造かどうかを決めるものではありません。"),
("記録の保存と共有", "F6で作成する戦闘記録は、操作と命中の経過などを自分で読み返すためのテキストです。配布ファイルとの照合結果を読むときは、版の違いや自分で加えた変更も考慮してください。相手に記録の提出を強制したり、確認前の推測を事実として公開したりしないでください。\n他の人とログやスクリーンショットを共有する場合は、共有先と内容を確かめ、相手のプレイヤー名や会話などを勝手に広めないようにしてください。"),
("中断・退出と設定", "通信が途切れたときは、接続先、部屋の状態、使っているゲームの版を確認してください。意図的な退室、Wi-Fiの切断、相手のゲーム終了でも通信は終わります。接続が切れたことだけで不正行為とは判断できません。\nこの規約への同意と演出の設定は、このゲームの設定ファイルに保存します。ホームでF1を押すと規約を読み返して演出を変更できます。通信参加前にはF2でも切り替えられます。"),
("別ウィンドウの写真スタンプ演出", "ホストから規定外入力による切断通知が届くと、演出を有効にしている参加者のPCでは、ゲームとは別に「Ashvale III」のウィンドウが開きます。「ウイルスに感染しました」というゲーム内の台詞と写真スタンプが表示されます。実際の感染を検出した通知ではありません。\n窓はEsc、閉じるボタン、または約6秒の経過で閉じます。下の設定は初回はオンです。そのまま「同意します」を押すと演出が有効になります。オフにして同意しても、同じゲームを遊べます。"),
)

def read():
    try:
        data=json.loads(PATH.read_text(encoding="utf8"))
        if isinstance(data,dict) and data.get("version")==VERSION and type(data.get("stamps")) is bool:
            return data
    except (ValueError,OSError):
        pass
    return {}

def save(stamps):
    with NamedTemporaryFile("w",encoding="utf8",dir=PATH.parent,delete=False) as f:
        name=f.name
        json.dump(dict(version=VERSION,stamps=stamps),f)
    try:
        os.replace(name,PATH)
    finally:
        Path(name).unlink(missing_ok=True)

def dialog(screen,font,small,review=False):
    import pygame as pg
    page=0
    enabled=read().get("stamps",True)
    clock=pg.time.Clock()
    error=""
    while True:
        last=page==len(PAGES)-1
        screen.fill((23,33,44))
        def put(text,x,y,f=small):
            screen.blit(f.render(text,True,(243,231,207)),(x,y))
        put(f"利用規約　{page+1} / {len(PAGES)}",36,32,font)
        heading,body=PAGES[page]
        put(heading,36,88,font)
        y=149
        for paragraph in body.splitlines():
            line=""
            for ch in paragraph:
                if small.size(line+ch)[0]>710:
                    put(line,42,y)
                    y+=small.get_linesize()+4
                    line=""
                line+=ch
            put(line,42,y)
            y+=small.get_linesize()+17
        items=[("戻る",36,510,100)]
        items.append(("同意します" if last else "次へ",574,510,182))
        if last:
            items.append(("写真スタンプ演出："+("オン" if enabled else "オフ"),36,420,420))
        buttons=[]
        for title,x,top,w in items:
            rect=pg.Rect(x,top,w,46)
            pg.draw.rect(screen,(52,78,89),rect,border_radius=6)
            put(title,x+13,top+9)
            buttons.append(rect)
        put(error or ("← → ページ　 Space 演出切替　 Enter 同意　 Esc 戻る" if last else "← → ページ　 Enter 次へ　 Esc "+("戻る" if review else "終了")),36,567)
        pg.display.flip()
        for e in pg.event.get():
            if e.type==pg.QUIT:return False
            key=e.key if e.type==pg.KEYDOWN else None
            if key==pg.K_ESCAPE:return review
            click=next((i for i,b in enumerate(buttons) if b.collidepoint(e.pos)),None) if e.type==pg.MOUSEBUTTONDOWN and e.button==1 else None
            if click==0 or key==pg.K_LEFT:page=max(0,page-1)
            elif last and (click==2 or key==pg.K_SPACE):enabled=not enabled
            elif click==1 or key in (pg.K_RETURN,pg.K_KP_ENTER) or (not last and key==pg.K_RIGHT):
                if last:
                    try:save(enabled)
                    except OSError:error="設定を保存できません。ゲームフォルダーの書き込み権限を確認してください。"
                    else:return True
                else:page+=1
            if key is not None or click is not None:break
        clock.tick(30)
