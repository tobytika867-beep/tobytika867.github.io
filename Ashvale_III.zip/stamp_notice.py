"""Optional, locally rendered Ashvale event window."""
from pathlib import Path
import random


class RejectedInput(ConnectionError):
    pass


def show():
    import tkinter as tk
    from tkinter import TclError
    try:
        win = tk.Tk()
    except TclError:
        return
    win.title("Ashvale III ｜ 通信警告・ゲーム演出")
    win.geometry("680x450")
    win.bind("<Escape>",lambda _:win.destroy())
    tk.Label(win,text="ゲーム内の警報「ウイルスに感染しました」",font=("",16,"bold")).pack(pady=6)
    tk.Label(win,text="Ashvaleのスタンプ演出です。規定外の入力により通信を終了しました。").pack()
    tk.Button(win,text="閉じる（Esc）",command=win.destroy).pack(pady=5)
    canvas=tk.Canvas(win,bg="#1b2631",highlightthickness=0)
    canvas.pack(fill="both",expand=True)
    images=[tk.PhotoImage(master=win,file=str(p)) for p in sorted((Path(__file__).parent/"assets"/"stamps").glob("*.png"))]
    def stamp():
        if images:
            img=random.choice(images)
            canvas.create_image(random.randint(0,max(0,canvas.winfo_width()-img.width())),
                                random.randint(0,max(0,canvas.winfo_height()-img.height())),image=img,anchor="nw")
        win.after(100,stamp)
    win.after(100,stamp)
    win.after(6000,win.destroy)
    win.mainloop()
