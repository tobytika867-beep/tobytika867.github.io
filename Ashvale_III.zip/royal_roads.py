"""Royal highways in district coordinates. Bits indicate gates on each edge."""
NORTH, EAST, SOUTH, WEST = 1, 2, 4, 8

def highways(realms):
    roads = {}
    routes = []
    inns = set()
    for _, x, y, *_ in realms:
        # Approach the port from the west, clear of the southern bay.
        bend = x - (4 if x > 0 else -4)
        points = [(0,0), (bend,0), (bend,y), (x,y)]
        routes.append(points)
        for (sx,sy),(ex,ey) in zip(points,points[1:]):
            dx,dy = (ex>sx)-(ex<sx),(ey>sy)-(ey<sy)
            forward, back = {(1,0):(EAST,WEST),(-1,0):(WEST,EAST),
                             (0,1):(SOUTH,NORTH),(0,-1):(NORTH,SOUTH)}[dx,dy]
            while (sx,sy)!=(ex,ey):
                roads[sx,sy] = roads.get((sx,sy),0) | forward
                sx,sy = sx+dx,sy+dy
                roads[sx,sy] = roads.get((sx,sy),0) | back
        inns.add((bend,y//2))
    return roads,routes,inns

def country_tile(x,y,roads):
    return f"country_{roads.get((x,y),0)}_{(x*73856093 ^ y*19349663)%7}"
