"""残潮港の短弓。矢は地形と最初に当たった魔物で止まる。"""
from dataclasses import dataclass
import math
import pygame

@dataclass
class Arrow:
    x: float
    y: float
    ux: float
    uy: float
    damage: int
    fire: bool
    remaining: float = 365

def loose(game):
    dx,dy=game.direction
    length=math.hypot(dx,dy) or 1
    ux,uy=dx/length,dy/length
    x,y=game.player.center
    game.arrows.append(Arrow(x,y,ux,uy,1+game.weapon_level//2+int(game.flame_timer>0),game.flame_timer>0))

def advance(game,dt):
    if not game.arrows:return
    targets=[(enemy,game.enemy_pose(enemy)[1]) for enemy in game.enemies if enemy.hp>0]
    for a in game.arrows[:]:
        distance=min(560*dt,a.remaining)
        steps=max(1,math.ceil(distance/3))
        for _ in range(steps):
            a.x+=a.ux*distance/steps
            a.y+=a.uy*distance/steps
            x,y=round(a.x),round(a.y)
            if game.blocked(pygame.Rect(x-1,y-1,3,3)):
                game.arrows.remove(a);break
            hit=next((enemy for enemy,rect in targets if enemy.hp>0 and rect.collidepoint(x,y)),None)
            if hit:
                game.damage_enemy(hit,a.damage,a.ux,a.uy,"flame" if a.fire else None)
                game.arrows.remove(a);break
        else:
            a.remaining-=distance
            if a.remaining<=0:game.arrows.remove(a)

def draw_arrows(game,screen):
    for a in game.arrows:
        x,y=game.to_screen_point(a.x,a.y)
        def point(along,side):
            return round(x+along*a.ux-side*a.uy),round(y+along*a.uy+side*a.ux)
        pygame.draw.line(screen,(202,157,98),point(-17,0),point(-2,0),2)
        pygame.draw.polygon(screen,(255,154,58) if a.fire else (225,229,217),[point(0,0),point(-6,3),point(-6,-3)])
        pygame.draw.lines(screen,(151,206,205),False,[point(-18,3),point(-13,0),point(-18,-3)],2)

def draw_bow(surface,x,y,vx,vy,timer):
    def p(along,side):
        return round(x+along*vx-side*vy),round(y+along*vy+side*vx)
    pygame.draw.lines(surface,(104,67,40),False,[p(-6,-12),p(1,-8),p(4,0),p(1,8),p(-6,12)],3)
    pygame.draw.lines(surface,(209,178,127),False,[p(-6,-12),p(2,-6),p(4,0)],1)
    pygame.draw.lines(surface,(226,220,183),False,[p(-6,-12),p(-6-min(4,timer*12),0),p(-6,12)],1)
