"""Check this distribution's gameplay code on demand."""
import hashlib
import json
from pathlib import Path


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(262144), b""):
            checksum.update(block)
    return checksum.hexdigest()


def make_manifest(folder, built=False):
    paths = [folder / "AshvaleIII.exe"] if built else sorted(folder.glob("*.py"))
    entries = {p.name: digest(p) for p in paths}
    (folder / "fair_files.json").write_text(json.dumps(entries, indent=2), encoding="utf8")


def inspect(folder, built=False):
    try:
        entries = json.loads((folder / "fair_files.json").read_text(encoding="utf8"))
        if not isinstance(entries, dict) or not entries:
            raise ValueError
        if built and set(entries) != {"AshvaleIII.exe"}:
            raise ValueError
        if not built and "legend_of_ashvale.py" not in entries:
            raise ValueError
        notes = []
        for name, expected in entries.items():
            if Path(name).name != name or (not built and not name.endswith(".py")):
                raise ValueError
            if not (folder / name).is_file():
                notes.append("欠落 " + name)
            elif digest(folder / name) != expected:
                notes.append("内容に差 " + name)
        if not built:
            notes.extend("追加 " + p.name for p in sorted(folder.glob("*.py")) if p.name not in entries)
        return notes or ["配布時の基準と一致"]
    except (ValueError, OSError, TypeError):
        return ["照合できませんでした"]


if __name__ == "__main__":
    import sys
    make_manifest(Path(sys.argv[1]), built=len(sys.argv) > 2 and sys.argv[2] == "--exe")
