@echo off
cd /d "%~dp0"
python -m pip show pygame >nul 2>&1
if errorlevel 1 (
  echo pygame is not installed. Installing it now...
  python -m pip install pygame
  if errorlevel 1 (
    echo Could not install pygame. Please install Python and try again.
    pause
    exit /b 1
  )
)
python legend_of_ashvale.py
if errorlevel 1 pause
