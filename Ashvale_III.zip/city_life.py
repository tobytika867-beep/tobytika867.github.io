"""Royal daily routines, road rescue and journal destinations."""
import math
import hearth_story as hearth
from east_wards import JOBS

TRACKS=("追跡なし","急使の救援","鍋底の五本線",*JOBS)
PEOPLE={"パン屋の客","見習い職人","鍛冶職人","急使の報告","立ち往生の御者"}
CART="巡回炊事便"
PROPS={"パンの屋台","星灯の宿前","工房の書き置き","車輪の跡","壊れた橋",CART}
EXTRAS=PEOPLE|PROPS
def period(game):
    return ("朝","昼","夕")[int(game.town_time//90)%3]

def destination(g,realms):
    f=g.chapter_flags
    name=g.tracking
    if name=="急使の救援":
        for flag,cell,line in (("rescue_call",(3,0),"東門街の急使に聞く"),("rescue_note",(3,0),"ギルド内の急使の報告を聞く"),("rescue_track",(4,0),"東街道で車輪の跡を調べる"),("rescue_driver",(5,0),"御者の事情を聞く"),("rescue_bridge",(5,0),"壊れた橋に足場を組む"),("rescue_home",(3,0),"ギルドで帰着を報告する")):
            if flag not in f:return "royal",cell,line
        return "",None,"救援完了"
    if name=="鍋底の五本線":
        if "hearth_end" in f:return "",None,"物語完了"
        if "hearth_meal" not in f or f.intersection(("hearth_cart","hearth_inn")):
            return "over",(7,5),hearth.goal(f)
        for i,r in enumerate(realms):
            if f"hearth_slip{i}" not in f:return "royal",tuple(r[1:3]),r[0]+"の"+hearth.WITNESSES[i]
        return "royal",(0,0),"王城前広場で次の冬の台所を決める"
    if name in JOBS:
        job,task,_=JOBS[name]
        if job+"_paid" in f:return "",None,"報酬受取済み"
        if job+"_taken" not in f:return "royal",(3,0),"ギルドの掲示板で受注"
        if job+"_ready" in f or job=="supply" and g.potions>=2:return "royal",(3,0),"ギルドの掲示板で報告"
        if job=="supply":return "over",(7,5),"きさらぎ町の道具屋で薬を用意"
        return "royal",tuple(realms[0][1:3]) if job=="letter" else (4,0),task
    return "",None,""

def features(g,cx,cy,realms):
    rows=[]
    def add(name,cell,x,y):
        if abs(cx-cell[0])<=1 and abs(cy-cell[1])<=1:
            rows.append((name,cell[0]*800+round(x),cell[1]*560+round(y)))
    t=g.town_time%270
    # Residents share the unobstructed east-west promenade. Stops are connected by walks.
    add("パンの屋台",(2,0),-205,-9)
    add("工房の書き置き",(2,0),0,-9)
    add("星灯の宿前",(2,0),203,-9)
    for i,name in enumerate(("パン屋の客","見習い職人","鍛冶職人")):
        stops=(-170+19*i,-18+18*i,152+18*i)
        phase=int(t//90)
        progress=min(1,max(0,(t%90-75)/15))
        x=stops[phase]+(stops[(phase+1)%3]-stops[phase])*progress
        add(name,(2,0),x,16+i*5)
    f=g.chapter_flags
    if "rescue_note" in f:add("車輪の跡",(4,0),104,8)
    if "rescue_track" in f:
        add("壊れた橋",(5,0),85,-2)
        add("立ち往生の御者",(5,0),-44,14)
    if "hearth_cart" in f:
        r=realms[int(g.town_time//90)%5]
        add(CART,r[1:3],0,64+8*math.sin(t*.05))
    return rows

def interact(g,site):
    f=g.chapter_flags
    if site=="急使":
        f.add("rescue_call")
        line="急使：霞港の荷車が帰らない。東門街のギルドまで報告を届ける！" if "rescue_home" not in f else "急使：御者から礼状だ。次の便も定刻だって！"
    elif site=="急使の報告":
        if "rescue_home" in f:line="急使：あの車輪の跡は、次の荷車の道しるべになったよ。"
        elif "rescue_bridge" in f:
            g.rupees+=24
            f.add("rescue_home")
            line="御者の帰着印が届いた。救援の報酬◆24を受け取った！"
        else:
            f.update(("rescue_call","rescue_note"))
            line="急使：東門の先、東西4の道標の東に、片輪だけ深い跡があった。"
    elif site=="車輪の跡":
        f.add("rescue_track")
        line="東へ続く溝に青い幌の切れ端。隣の地区まで跡を追おう。"
    elif site=="立ち往生の御者":
        f.add("rescue_driver")
        line="御者：積み荷は港の薬草だ。東側の橋に荷台の板を渡してくれ。" if "rescue_bridge" not in f else "御者：薬草は無事だ！ ギルドに帰着印を届けるよ。"
    elif site=="壊れた橋":
        if "rescue_driver" not in f:line="板が一枚足りない。近くの御者に話を聞こう。"
        else:
            f.add("rescue_bridge")
            line="荷台の板を渡し、荷車を向こう岸まで押した。ギルドへ報告しよう。"
    elif site==CART:
        g.hp=g.max_hp
        line="ミラ：熱いから、柄杓の柄を持って。炊きたての粥で全回復した。"
    elif site=="工房の書き置き":
        line="職人の書き置き『朝はパンの屋台、昼は工房、夕方は東の宿で食事』"
    elif site in ("星灯の宿前","パンの屋台"):
        line="宿主：夕食の席を三つ空けてあるよ。" if site=="星灯の宿前" else "パン屋：朝一番に焼く丸パンには、港の塩をひとつまみ。"
    else:
        line={"朝":"焼きたての列に間に合った。今日は胡桃入りだ。","昼":"工房の昼番だ。東門の馬車の車軸を直しているよ。","夕":"炉を落としたよ。宿の夕飯は何だろう。"}[period(g)]
    g.tell(line,6)
