"""Five city commissions and their landmarks."""
from functools import lru_cache
import math
import pygame
from city_maps import SITES

# Power, petitioner, site, witness, instructions, transformed landmark, boss clue.
COMMISSIONS = (
    ("wind", "港守", "霧の桟橋", "遭難船の船員", "桟橋の霧を嵐（N）で払う", "帰港船", "二度目の鐘で渦から離れろ。"),
    ("flame", "炉番", "消えた炉", "鋳物師", "炉に向かい焔（B）をまとった剣で斬る", "赤銅の大炉", "炉床の火は外から内へ走る。"),
    ("heal", "森医", "枯れた苗床", "薬草師", "苗床に回復（Y）の力を注ぐ", "薬草園", "荊の輪には東側に切れ目がある。"),
    ("lightning", "鐘守", "沈黙の鐘楼", "鐘職人", "鐘楼に雷（G）を落とす", "時告げの鐘", "三つの鐘を避けたら王冠を狙え。"),
    ("earth", "石工", "崩れた水路", "水門守", "水路を大地（M）の壁で支える", "月映しの水路", "落星の列を横に抜けろ。"),
)
UPGRADES = ("嵐の範囲と気絶時間が増加", "焔が12秒持続・火傷が5回継続",
            "回復量が3から5に増加", "落雷の範囲と威力が増加", "土壁の射程と圧壊ダメージが増加")
LANDMARK_COLORS = ((100,172,187),(202,105,65),(106,164,98),(196,164,87),(144,123,177))

def local_features(add, realm, x, y):
    if realm:
        _, giver, site, witness, *_ = COMMISSIONS[realm-1]
        for (px,py),kind,w,h in zip(SITES[realm],(giver,site,witness,"旧街道の道標"),(20,52,20,24),(30,32,30,32)):
            add(kind,px-400-w//2,py-280-h,w,h,realm)
    if (x,y)==(-1,0):
        add("廃宿の宝箱",-32,66,64,40)
    if (x,y)==(-2,0):
        add("崩れ橋",-30,85,60,26)

@lru_cache(maxsize=2)
def fog_bank(layer):
    # Soft edges and irregular bands on the same coarse grid as the water.
    width,height=144,50
    cloud=pygame.Surface((width,height),pygame.SRCALPHA)
    for row in range(height):
        for col in range(width):
            u=(col-width/2)/(width/2)
            v=(row-height/2)/(height/2)
            drift=.14*math.sin(u*7+layer*3)+.07*math.cos(u*13)
            edge=max(0,1-u*u-(v-drift)**2)
            bands=.64+.22*math.sin(v*12+u*4+layer)+.14*math.cos(u*9-v*5)
            opacity=round(143*edge**.8*bands)
            cloud.set_at((col,row),(197+layer*20,216+layer*10,220+layer*10,opacity))
    return pygame.transform.scale(cloud,(576,200))


def decorate(game, surface, kind, rect, index, make_npc, ground, font):
    if index and index<=5:
        _, giver, site, witness, _, restored, _=COMMISSIONS[index-1]
        stage=game.quest_steps[index-1]
        if kind in (giver,witness):
            if kind!=witness or stage>=2:
                game.draw_npc(make_npc(kind,*ground,index))
            return True
        if kind==site:
            x,y=rect.center
            color=LANDMARK_COLORS[index-1]
            active=stage>=2
            pygame.draw.ellipse(surface,(52,73,67),rect.inflate(14,4))
            if index==1:
                pygame.draw.polygon(surface,(107,75,54),[(x-31,y),(x+31,y),(x+20,y+12),(x-17,y+12)])
                pygame.draw.line(surface,(202,189,151),(x,y),(x,y-39),3)
                pygame.draw.polygon(surface,(233,217,164),[(x+2,y-37),(x+22,y-14),(x+2,y-13)])
                if not active:
                    seconds=pygame.time.get_ticks()*.001
                    for layer in range(2):
                        cloud=fog_bank(layer)
                        cx=x-32+round(23*math.sin(seconds*.29+layer*2.7))
                        cy=y-8+round(7*math.sin(seconds*.37+layer*2))
                        surface.blit(cloud,cloud.get_rect(center=(cx,cy)))
            elif index==2:
                pygame.draw.rect(surface,(80,71,66),rect.inflate(-4,8))
                pygame.draw.polygon(surface,color if active else (50,44,45),[(x-12,y+9),(x-5,y-6),(x,y-15),(x+12,y+9)])
            elif index==3:
                for j in range(5):
                    stem=x-18+j*9
                    pygame.draw.line(surface,color if active else (124,100,71),(stem,y+8),(stem+3,y-5-j%3*3),3)
                    if active: pygame.draw.circle(surface,(237,196,123),(stem+3,y-7-j%3*3),4)
            elif index==4:
                pygame.draw.rect(surface,(97,75,55),rect.inflate(-4,15),4)
                pygame.draw.polygon(surface,color,[(x-6,y-10),(x+6,y-10),(x+13,y+8),(x-13,y+8)])
            else:
                pygame.draw.rect(surface,(80,148,175) if active else (96,82,78),rect)
                for j in range(3): pygame.draw.rect(surface,(162,154,138),(x-23+17*j,y-6,12,12))
            label=restored if index in game.lords else ("復旧済" if active else site)
            game.center_text(restored if active and index==1 else label,x,y+29,font,(247,221,148))
            return True
    if kind in ("廃宿の宝箱","崩れ橋","旧街道の道標"):
        x,y=rect.center
        if kind=="廃宿の宝箱":
            pygame.draw.polygon(surface,(77,70,65),[(x-42,y-6),(x-15,y-36),(x+20,y-17),(x+40,y-4)])
            pygame.draw.rect(surface,(148,100,55),rect.inflate(-17,-10))
            pygame.draw.rect(surface,(220,182,92),rect.inflate(-17,-10),3)
        elif kind=="崩れ橋":
            pygame.draw.rect(surface,(71,125,146),rect.inflate(40,12))
            for j in range(5):
                if j!=2 or game.bridge_fixed:
                    pygame.draw.rect(surface,(156,120,79),(rect.left+j*12,y-14,10,28))
        else:
            pygame.draw.line(surface,(102,77,60),(x,y+13),(x,y-16),4)
            pygame.draw.polygon(surface,(184,143,83),[(x-15,y-16),(x+9,y-16),(x+17,y-11),(x+9,y-6),(x-15,y-6)])
        game.center_text(kind,x,rect.bottom+12,font,(241,218,167))
        return True
    return False
