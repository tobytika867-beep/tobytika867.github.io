"""Ashvale: a small, original top-down action RPG with 300 explorable screens.

Requires pygame: python -m pip install pygame
Run: python legend_of_ashvale.py
"""
from functools import lru_cache
from copy import deepcopy
from sprite_art import citizen, monster_detail
from keep_trials import CAPTAINS, ELEMENTS, SEAL_NAMES, RULES, starting_board, linked_tiles
import city_life as life
import townsfolk
import east_wards as east
import hearth_story as hearth
import ash_wastes as wastes
import rift_chapter as rift
import tide_bow as bow
from sea_prologue import Prologue, CAPTIONS
import meridian as tide
rift.AREAS.update(tide.NAMES)
from realm_tales import TALES, VILLAGE_LINES
from royal_roads import highways, country_tile
from city_maps import BUILDINGS, PORT_WITNESS
from royal_chronicle import COMMISSIONS, UPGRADES, LANDMARK_COLORS, local_features, decorate
import math
from time import monotonic
import random
import sys
import json
import os
from tempfile import NamedTemporaryFile
from pathlib import Path
from dataclasses import dataclass, asdict

import pygame

pygame.init()

WIDTH, HEIGHT = 800, 600
HUD_H = 40
TILE = 40
COLS, ROWS = WIDTH // TILE, (HEIGHT - HUD_H) // TILE
PLAY_H = HEIGHT - HUD_H
WORLD_W, WORLD_H = 15 * WIDTH, 10 * PLAY_H
AUTOSAVE_INTERVAL = 30.0
FPS = 60
SLIME_WINDUP = .18
SLIME_AIR_TIME = .40
if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
    RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", APP_DIR))
else:
    APP_DIR = Path(__file__).resolve().parent
    RESOURCE_DIR = APP_DIR
SAVE_PATH = APP_DIR / "ashvale_iii_save.json"

INK = (20, 24, 30)
WHITE = (242, 238, 218)
GOLD = (246, 205, 87)
GREEN = (72, 133, 77)
DEEP_GREEN = (38, 91, 62)
SAND = (188, 158, 97)
STONE = (105, 110, 119)
WATER = (49, 119, 176)
RED = (191, 65, 60)
BLUE = (72, 136, 215)
PURPLE = (145, 81, 174)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("星図の旅人 III　白暦の海")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont("meiryo", 19, bold=True)
SMALL = pygame.font.SysFont("meiryo", 14, bold=True)
BIG = pygame.font.SysFont("meiryo", 32, bold=True)


def load_hero_sprites():
    """Load eight directions and three walk frames from the bundled sprite sheet."""
    path = RESOURCE_DIR / "assets" / "hero_directions.png"
    sheet = pygame.image.load(str(path)).convert_alpha()
    cell_w, cell_h = sheet.get_width() // 8, sheet.get_height() // 3
    directions = ("down", "down_right", "right", "up_right", "up", "up_left", "left", "down_left")
    sprites = {}
    for col, name in enumerate(directions):
        sprites[name] = []
        for row in range(3):
            cell = sheet.subsurface((col * cell_w, row * cell_h, cell_w, cell_h))
            bounds = cell.get_bounding_rect(min_alpha=96)
            sprite = cell.subsurface(bounds).copy()
            # Keep a chunky pixel look while fitting the character into a map tile.
            sprite = pygame.transform.scale(sprite, (18, 24))
            scale = min(30 / sprite.get_width(), 40 / sprite.get_height())
            size = (max(1, round(sprite.get_width() * scale)), max(1, round(sprite.get_height() * scale)))
            sprites[name].append(pygame.transform.scale(sprite, size))
    return sprites


HERO_SPRITES = load_hero_sprites()


@lru_cache(maxsize=24)
def running_sprite(facing, frame):
    original=HERO_SPRITES[facing][frame]
    dx=int("right" in facing)-int("left" in facing)
    dy=int("down" in facing)-int("up" in facing)
    height=original.get_height()
    surface=pygame.Surface((original.get_width()+18,height+8),pygame.SRCALPHA)
    for row in range(height):
        torso=(1-row/(height-1))**1.3
        surface.blit(original,(9+round(dx*8*torso),8+row+round((4+dy*3)*torso)),
                     (0,row,original.get_width(),1))
    return surface


@dataclass
class Enemy:
    x: float
    y: float
    kind: str
    hp: int
    speed: float
    color: tuple
    hurt: float = 0.0
    attack_cooldown: float = 0.0
    boss_id: int = -1
    max_hp: int = 0
    move_cooldown: float = 0.0
    special_timer: float = 2.0
    special_count: int = 0
    burn_ticks: int = 0
    burn_delay: float = 0
    exposed: float = 0
    weakness_flash: float = 0
    stun: float = 0
    hop_left: float = 0
    hop_vx: float = 0
    hop_vy: float = 0
    hop_target: str = ""
    captain: int = -1
    slime_count: int = 1
    facing_octant: int = 2
    stride_distance: float = 0.0
    walking_boss: bool = False
    def __post_init__(self):
        if self.max_hp <= 0:
            self.max_hp = self.hp


BOSSES = [
    {"name": "樹根の巨獣", "hp": 12, "color": (103, 164, 89), "power": "heal"},
    {"name": "熔炉の巨兵", "hp": 14, "color": (219, 108, 55), "power": "lightning"},
    {"name": "深潮の主", "hp": 16, "color": (66, 151, 168), "power": "flame"},
    {"name": "星喰いの翼竜", "hp": 18, "color": (127, 103, 191), "power": "wind"},
    {"name": "嵐鐘の守護者", "hp": 20, "color": (155, 126, 177), "power": "earth"},
    {"name": "奈落の魔王", "hp": 72, "color": (137, 51, 59), "power": None},
]
POWER_NAMES = {"heal": "回復", "lightning": "雷", "flame": "焔", "wind": "嵐", "earth": "大地"}
POWER_KEYS = {"heal": pygame.K_y, "lightning": pygame.K_g, "flame": pygame.K_b,
              "wind": pygame.K_n, "earth": pygame.K_m}
POWER_LABELS = {"heal": "Y", "lightning": "G", "flame": "B", "wind": "N", "earth": "M"}
KEY_ATTACK, KEY_BOMB, KEY_POTION = pygame.K_j, pygame.K_k, pygame.K_l
KEY_DASH, KEY_SHUKUCHI, KEY_WARP, KEY_MAP = pygame.K_u, pygame.K_i, pygame.K_o, pygame.K_SLASH
KEY_INTERACT, KEY_BAG = pygame.K_h, pygame.K_SEMICOLON
KEY_SWORD, KEY_SPEAR, KEY_SHIELD = pygame.K_r, pygame.K_t, pygame.K_COMMA
POWER_COOLDOWNS = {"heal": 5.0, "lightning": 4.0, "flame": 10.0, "wind": 5.0, "earth": 8.0}


NPC_SPRITE_CACHE = {}
ENEMY_SPRITE_CACHE = {}


@lru_cache(maxsize=64)
def sprite_mask(sprite):
    return pygame.mask.from_surface(sprite,160)


def build_enemy_sprite(kind, color, boss_id=0):
    """Draw enemy sprites on a small canvas for a consistent pixel-art look."""
    sprite = pygame.Surface((24, 24), pygame.SRCALPHA)
    if kind != "slime":
        pygame.draw.ellipse(sprite, (25, 29, 30, 130), (3, 19, 18, 4))
    if kind == "slime":
        pygame.draw.polygon(sprite, color, [(3, 18), (4, 12), (7, 8), (12, 6), (17, 8), (20, 13), (21, 18), (18, 20), (6, 20)])
        pygame.draw.rect(sprite, (153, 210, 142), (7, 10, 3, 2))
        pygame.draw.rect(sprite, INK, (8, 14, 2, 3))
        pygame.draw.rect(sprite, INK, (15, 14, 2, 3))
    elif kind == "bat":
        pygame.draw.polygon(sprite, color, [(11, 11), (6, 7), (1, 8), (4, 15), (1, 18), (9, 16), (12, 20), (15, 16), (23, 18), (20, 14), (23, 8), (17, 7), (13, 11)])
        pygame.draw.rect(sprite, (245, 205, 121), (9, 11, 2, 2))
        pygame.draw.rect(sprite, (245, 205, 121), (14, 11, 2, 2))
    elif kind == "stalfos":
        pygame.draw.rect(sprite, (61, 57, 52), (5, 18, 5, 4))
        pygame.draw.rect(sprite, (61, 57, 52), (14, 18, 5, 4))
        pygame.draw.rect(sprite, color, (6, 6, 12, 10))
        pygame.draw.rect(sprite, (222, 212, 184), (7, 3, 10, 8))
        pygame.draw.rect(sprite, (112, 60, 45), (9, 6, 2, 2))
        pygame.draw.rect(sprite, (112, 60, 45), (14, 6, 2, 2))
        pygame.draw.rect(sprite, (222, 212, 184), (10, 13, 4, 7))
        pygame.draw.line(sprite, (222, 212, 184), (5, 12), (2, 17), 2)
        pygame.draw.line(sprite, (222, 212, 184), (18, 12), (21, 17), 2)
    elif kind == "boss":
        if boss_id == 0:
            pygame.draw.polygon(sprite, color, [(2, 18), (3, 10), (7, 7), (9, 3), (12, 8),
                                                (15, 3), (17, 8), (21, 11), (22, 19), (18, 22), (5, 22)])
            pygame.draw.line(sprite, (190, 217, 131), (8, 8), (4, 2), 3)
            pygame.draw.line(sprite, (190, 217, 131), (16, 8), (20, 2), 3)
        elif boss_id == 1:
            pygame.draw.rect(sprite, color, (4, 5, 16, 17), border_radius=3)
            pygame.draw.polygon(sprite, (255, 186, 83), [(5, 7), (2, 1), (10, 5)])
            pygame.draw.polygon(sprite, (255, 186, 83), [(19, 7), (22, 1), (14, 5)])
            pygame.draw.rect(sprite, (255, 208, 95), (7, 10, 3, 3))
            pygame.draw.rect(sprite, (255, 208, 95), (14, 10, 3, 3))
            pygame.draw.line(sprite, (112, 53, 43), (7, 18), (17, 18), 2)
        elif boss_id == 2:
            pygame.draw.polygon(sprite, color, [(2, 17), (5, 8), (9, 11), (12, 3), (15, 11),
                                                (20, 7), (22, 18), (18, 22), (6, 22)])
            pygame.draw.polygon(sprite, (143, 220, 220), [(8, 10), (12, 5), (15, 12), (11, 10)])
            pygame.draw.rect(sprite, WHITE, (7, 13, 3, 2))
            pygame.draw.rect(sprite, WHITE, (15, 13, 3, 2))
        elif boss_id == 3:
            pygame.draw.polygon(sprite, color, [(8, 8), (2, 3), (1, 15), (8, 13),
                                                (12, 20), (16, 13), (23, 15), (22, 3), (16, 8)])
            pygame.draw.polygon(sprite, (194, 172, 234), [(3, 5), (8, 9), (5, 12)])
            pygame.draw.polygon(sprite, (194, 172, 234), [(21, 5), (16, 9), (19, 12)])
            pygame.draw.rect(sprite, GOLD, (8, 10, 3, 3))
            pygame.draw.rect(sprite, GOLD, (14, 10, 3, 3))
        elif boss_id == 4:
            pygame.draw.rect(sprite, color, (4, 5, 16, 17), border_radius=2)
            pygame.draw.polygon(sprite, (194, 180, 148), [(4, 7), (8, 1), (11, 7)])
            pygame.draw.polygon(sprite, (194, 180, 148), [(13, 7), (17, 1), (20, 7)])
            pygame.draw.rect(sprite, GOLD, (7, 10, 3, 3))
            pygame.draw.rect(sprite, GOLD, (14, 10, 3, 3))
            pygame.draw.line(sprite, (213, 197, 159), (6, 17), (18, 17), 2)
        else:
            pygame.draw.polygon(sprite, color, [(3, 21), (4, 8), (8, 5), (12, 8), (16, 5),
                                                (20, 8), (21, 21), (16, 23), (8, 23)])
            pygame.draw.polygon(sprite, (80, 33, 42), [(4, 8), (1, 1), (10, 6), (12, 10)])
            pygame.draw.polygon(sprite, (80, 33, 42), [(20, 8), (23, 1), (14, 6), (12, 10)])
            pygame.draw.polygon(sprite, (246, 111, 56), [(6, 15), (9, 12), (12, 16), (15, 12), (18, 15), (16, 19), (8, 19)])
            pygame.draw.rect(sprite, (255, 218, 109), (7, 10, 3, 3))
            pygame.draw.rect(sprite, (255, 218, 109), (14, 10, 3, 3))
    else:
        pygame.draw.polygon(sprite, color, [(3, 18), (4, 9), (8, 6), (9, 2), (12, 5), (15, 2), (16, 7), (20, 10), (21, 18), (18, 21), (6, 21)])
        pygame.draw.rect(sprite, GOLD, (7, 10, 3, 3))
        pygame.draw.rect(sprite, GOLD, (14, 10, 3, 3))
        pygame.draw.rect(sprite, (37, 32, 40), (7, 14, 10, 4))
    if kind != "slime":
        monster_detail(sprite,kind,color,boss_id)
    return sprite


CASTLE = {"forecourt": "魔王城前・黒曜の大階段", "great_hall": "魔王城・衛兵の広間", "throne": "王の間"}
CASTLE_DOOR = pygame.Rect(348, 65, 104, 62)


def demon_phase(enemy):
    return 1 + int(enemy.hp * 3 <= enemy.max_hp * 2) + int(enemy.hp * 3 <= enemy.max_hp)


REALMS = [
    ("霞港", 40, -64, "霧潮の魔王", (102,174,194)),
    ("赤銅市", 77, 12, "熔鉄の魔王", (201,99,68)),
    ("翠森市", 32, 77, "荊冠の魔王", (98,154,97)),
    ("白鐘市", -57, 57, "鳴雷の魔王", (186,156,82)),
    ("夜玻璃市", -77, -32, "月蝕の魔王", (141,112,190)),
]

def royal_npc(name, x, y, index):
    coats = ((98,116,157),(156,97,81),(112,139,107),(149,112,152))
    return dict(name=name,x=x,y=y,coat=coats[index%4],hair=(78,61,49),skin=(216,176,139))

ROYAL_FORGE_PRICES = (8, 8, 8, 24, 40)
CITY_INDEX = {(0, 0): 0, **{r[1:3]: i for i, r in enumerate(REALMS, 1)}}

CIVIC_HALLS = ("港務所","鋳造会館","森の集会所","鐘楼会館","水門管理所")
FORT_CELLS = {(r[1],r[2]-2):i for i,r in enumerate(REALMS,1)}
TRAIL_CELLS = {(r[1],r[2]-1):i for i,r in enumerate(REALMS,1)}
port_x,port_y = REALMS[0][1:3]
BAY_CELLS = {(port_x+dx,port_y+dy):f"bay_{dx}_{dy}"
             for dx in range(-2,3) for dy in range(4) if (dx,dy)!=(0,0)}
TERRAIN_INDEX = {**CITY_INDEX, **BAY_CELLS,
                 **{cell:f"fort_{i}" for cell,i in FORT_CELLS.items()},
                 **{cell:f"trail_{i}" for cell,i in TRAIL_CELLS.items()}}

ROYAL_ROADS, ROYAL_ROUTES, ROADSIDE_INNS = highways(REALMS)

# Each ward is loaded separately as the camera crosses the capital.
CROWN_WARDS = {(x,y):f"ward_{x}_{y}" for x in range(-1,2) for y in range(-1,2)}
CROWN_WARDS.update({cell:f"east_{cell[0]}" for cell in east.WARDS})
TERRAIN_INDEX.update(CROWN_WARDS)
TOWN_ART_CELLS = CITY_INDEX.keys() | CROWN_WARDS.keys()
CROWN_PLAZA = (0, 80)
CROWN_SITES = [
    (name, pygame.Rect((left-400)*3, (top-280)*3, w*3, h*3), 0)
    for name,(left,top,w,h) in zip(("王城","鍛冶屋","薬屋","道具屋","民家"), BUILDINGS[0])
]
for name,x,y in (("炊事長ユノ",0,125),("炊事の荷車",-84,80),("きさらぎの宿帳",84,80),("急使",20,65),("市民",-163,85),("帰郷便",-311,160),("駅馬車",240,160)):
    CROWN_SITES.append((name,pygame.Rect(x-10,y-30,20,30),0))

@lru_cache(maxsize=256)
def rendered_text(font, text, color):
    return font.render(text, True, color)

@lru_cache(maxsize=24)
def district_art(index):
    directory = RESOURCE_DIR / "assets" / "cities"
    image = pygame.image.load(str(directory / f"{index}.png")).convert()
    solid = pygame.image.load(str(directory / f"{index}_solid.png")).convert_alpha()
    return image, pygame.mask.from_surface(solid)

@lru_cache(maxsize=32)
def body_mask(size):
    return pygame.mask.Mask(size, fill=True)

def districts_under(rect):
    for gy in range((rect.top+PLAY_H//2)//PLAY_H, (rect.bottom-1+PLAY_H//2)//PLAY_H+1):
        for gx in range((rect.left+WIDTH//2)//WIDTH, (rect.right-1+WIDTH//2)//WIDTH+1):
            index=TERRAIN_INDEX.get((gx,gy))
            if index is None:
                index=country_tile(gx,gy,ROYAL_ROADS)
            yield index,gx*WIDTH-WIDTH//2,gy*PLAY_H-PLAY_H//2

@lru_cache(maxsize=36)
def capital_district(x, y):
    ox, oy = x*WIDTH, y*PLAY_H
    features = []
    def add(name, rx, ry, w, h, index=0):
        features.append((name,pygame.Rect(ox+rx,oy+ry,w,h),index))
    realm = next((i for i,r in enumerate(REALMS,1) if (x,y)==r[1:3]),0)
    if (x,y) in east.WARDS:
        name="星灯カジノ" if x==2 else "冒険者ギルド"
        add(name,-118,-195,236,145)
        add("急使",-65,8,20,25,x)
        return tuple(features)
    if (x,y)==(4,0):
        add("東門の道標",20,-44,18,28)
    if (x,y) in FORT_CELLS:
        add("魔王砦",-127,-161,254,125,FORT_CELLS[(x,y)])
        return tuple(features)
    if (x,y) in TRAIL_CELLS:
        add("峠の道標",49,8,20,28,TRAIL_CELLS[(x,y)])
        return tuple(features)
    if (x,y) in BAY_CELLS:
        return ()
    if (x,y) in CROWN_WARDS:
        # Store each landmark once, in the ward containing its entrance.
        for feature in CROWN_SITES:
            rect = feature[1]
            if ((rect.centerx+400)//800,(rect.bottom+280)//560)==(x,y):
                features.append(feature)
        local_features(add,0,x,y)
        return tuple(features)
    if (x,y) in CITY_INDEX:
        names=(CIVIC_HALLS[realm-1],"鍛冶屋","薬屋","道具屋","民家")
        for title,(left,top,width,height) in zip(names,BUILDINGS[realm]):
            add(title,left-WIDTH//2,top-PLAY_H//2,width,height,realm)
        # The carriage waits on dry land beside the road.
        add("駅馬車",70,14 if realm==1 else 52,22,30,realm)
        add("市民",-105 if realm==5 else -165,12,20,30,0)
        add("急使",-10,-23,20,25,realm)
        add(hearth.WITNESSES[realm-1],50,10 if realm==1 else 40,20,30,realm)
        local_features(add,realm,x,y)
        return tuple(features)
    if (x,y) in ROADSIDE_INNS:
        add("街道宿",54,-64,96,64)
    local_features(add,realm,x,y)
    return tuple(features)


@lru_cache(maxsize=24)
def nearby_capital_features(cx, cy, quest_steps):
    result = []
    for y in range(cy-1,cy+2):
        for x in range(cx-1,cx+2):
            if x*x+y*y <= 10050:
                for kind,rect,index in capital_district(x,y):
                    if 1<=index<=5 and kind==COMMISSIONS[index-1][3] and quest_steps[index-1]<2:
                        continue
                    result.append((kind,rect,index))
    return tuple(result)

PASSABLE_PEOPLE={*life.EXTRAS,"急使",*hearth.WITNESSES,"炊事長ユノ","炊事の荷車","きさらぎの宿帳","市民","駅馬車","帰郷便",*(q[1] for q in COMMISSIONS),*(q[3] for q in COMMISSIONS)}
ROYAL = {"capital","palace", *("keep"+str(i) for i in range(1,6))}

class Soundtrack:
    def __init__(self):
        self.directory = RESOURCE_DIR / "assets" / "audio"
        self.current = None
        self.sounds = {}
        if pygame.mixer.get_init():
            for key in ("attack", "hurt", "shield", "omen", "bell", "parry"):
                self.sounds[key] = pygame.mixer.Sound(str(self.directory / (key + ".wav")))
                self.sounds[key].set_volume(.55)

    def play(self, key):
        if key in self.sounds:
            self.sounds[key].play()

    def update(self, game):
        if not self.sounds:
            return
        if game.home_screen or game.name_editing:
            track = "title"
        elif game.interior and game.interior.startswith("keep"):
            track = "demon"
        elif game.interior in rift.AREAS:
            track="town" if game.interior==tide.PORT else "demon" if game.interior==wastes.THRONE else "field" if game.interior=="rift_quay" else "dungeon"
        elif game.interior in CASTLE:
            track = "demon" if game.interior == "throne" else "dungeon"
        elif game.interior:
            track = "inn" if game.interior == "inn" else "town"
        elif any(e.kind == "boss" and e.boss_id == 5 and e.hp > 0
                 and game.world == (7, 4) for e in game.enemies):
            track = "demon"
        elif game.room and any(e.kind == "boss" and e.hp > 0 for e in game.enemies):
            track = "boss"
        elif game.room:
            track = "dungeon"
        else:
            track = "town" if game.world == (7, 5) else "field"
        if track != self.current:
            pygame.mixer.music.load(str(self.directory / (track + ".ogg")))
            pygame.mixer.music.set_volume(.42)
            pygame.mixer.music.play(-1, fade_ms=350)
            self.current = track


audio = Soundtrack()


import terms
import story_link
import lan_duel
from input_review import InputReview


class Ashvale:
    def __init__(self):
        self.companion = None
        self.input_review = InputReview()
        self.world = (7, 5)
        self.room = None
        self.interior = None
        self.castle_state = {}
        self.interior_return = None
        self.overworld_return = None
        self.visible_chunks = []
        self.roof_cache = {}
        self.terrain_cache = {}
        self.overworld_enemy_state = {}
        self.enemy_drops = {}
        self.collected_items = set()
        self.player = pygame.Rect(0, 0, 24, 26)
        self.direction = (0, 1)
        self.walk_time = 0.0
        self.running = False
        self.walking = False
        self.dash_flash = 0.0
        self.dash_cooldown = 0.0
        self.buffered_powers = {}
        self.blink_followup=0.0
        self.spear_chain=False
        self.shukuchi_cooldown = 0.0
        self.jump_timer = 0.0
        self.jump_cooldown = 0.0
        self.warp_open = False
        self.courier_run=0.0
        self.town_time=0.0
        self.tracking=life.TRACKS[0]
        self.patrols = {}
        self.npc_poses = {}
        self.road_anchors = {}
        self.royal_destinations = []
        self.warp_index = 0
        self.warp_cursor = self.world
        self.home_screen = True
        self.inn_registered = False
        self.rich_effects = True
        self.home_selection = 0
        self.home_help = False
        self.hp, self.max_hp = 6, 6
        self.revival_feathers = 0
        self.rupees, self.keys, self.bombs, self.potions = 0, 0, 3, 2
        self.owned_gear = set()
        self.weapon = "none"
        self.weapon_level = 0
        self.elixirs = self.heavy_bombs = 0
        self.shield_equipped = False
        self.abilities = set()
        self.power_cooldowns = {power: 0.0 for power in POWER_NAMES}
        self.flame_timer = 0.0
        self.magic_walls = []
        self.map_obtained = False
        self.map_open = False
        self.guard_cooldowns = {"槍の門番": 0.0, "剣の門番": 0.0}
        self.door_lock = None
        self.seals = set()
        self.visited = set()
        self.cleared_rooms = set()
        self.message = "5つの地図の欠片と5つの力を集めよう。"
        self.message_timer = 5.0
        self.enemies = []
        self.pickups = []
        self.obstacles = []
        self.attack_timer = 0.0
        self.arrows=[]
        self.attack_weapon = "none"
        self.attack_direction = (0, 1)
        self.effects = []
        self.shield_cooldown = 0.0
        self.invulnerable = 0.0
        self.bomb_list = []
        self.transition_cooldown = 0.0
        self.lords = set()
        self.captains_down = [0]*6
        self.seal_boards = [starting_board(i) for i in range(6)]
        self.seal_open = False
        self.seal_cursor = 4
        self.mayor_met = self.royal_order = False
        self.ending_age = 0.0
        self.ending_open = False
        self.chapter_flags = set()
        self.attack_hits = set()
        self.strike_cache = None
        self.game_won = False
        self.game_over = False
        self.final_boss_started = False
        self.final_boss_defeated = False
        self.talk_counts = {}
        self.player_name = "旅人"
        self.name_editing = False
        self.initial_name_prompt = False
        self.name_buffer = ""
        self.quest_steps=[0]*5
        self.last_clue="きさらぎ町の旅人から地図を受け取ろう。"
        self.pinned=1
        self.road_map=self.bridge_fixed=self.journal_page=False
        self.retry_data=None
        self.saved_progress = None
        self.autosave_elapsed = 0.0
        self.autosave_retry = 0.0
        self.autosave_notice = 0.0
        self.inventory_open = False
        self.hostile_attacks = []
        # Start in the north-central street, clear of the traveler and nearby houses.
        self.interior=tide.PORT
        self.player.center=(400,359)
        self.hp=self.max_hp=5
        self.abilities.update(("heal","wind"))
        self.inn_registered=self.map_obtained=True
        self.rupees=6
        self.message=self.last_clue=tide.goal(self)
        self.load_room()

    def conversation(self, key, *lines):
        turn=self.talk_counts.get(key,0)
        self.talk_counts[key]=(turn+1)%len(lines)
        return lines[turn%len(lines)]

    def journal_goal(self, index):
        if self.interior in tide.NAMES:return tide.goal(self)
        if self.game_won:
            return rift.objective(self.chapter_flags)
        if not self.royal_order:
            if self.final_boss_defeated:
                return "王城の国王に会う" if self.mayor_met else "きさらぎ町へ帰る"
            return "金色の門から魔王城へ" if len(self.seals)==5 else f"五つの欠片を集める（{len(self.seals)}/5）"
        if index==0:
            return "旧街道の道標を使う" if self.bridge_fixed else "王城から西へ二地区、古い橋を探す" if self.road_map else "王城から西へ一地区、廃宿を探す"
        _,giver,_,witness,task,_,_=COMMISSIONS[index-1]
        if index in self.lords:
            return "解放済み"
        stage=self.quest_steps[index-1]
        if stage==1:
            if index==2 and "copper" not in self.chapter_flags:
                return "北門を出て峠の道標でE。炉の耐火石を持ち帰る"
            if index==4:
                return "古い譜面を探せ。「最初と最後は石の屋根の下。風を受ける鐘が間をつなぐ」"
            if index==5 and "sluice" not in self.chapter_flags:
                return "水門管理所で迂回水路を開くか、旧街道の道標で堤を切る"
        if stage==2 and index==3 and "remedy" not in self.chapter_flags:
            return "苗床の薬草を広場の市民に届ける"
        return (giver+"に会う",task,witness+"の話を聞く","街の北へ二地区、峠を越えて砦へ")[self.quest_steps[index-1]]

    def quest_interact(self, kind, index):
        if index==2 and kind=="峠の道標" and self.quest_steps[1]==1:
            self.chapter_flags.add("copper")
            self.last_clue="耐火石を拾った。消えた炉へ運び、焔の剣で火を入れよう。"
        elif index==4 and self.quest_steps[3]==1 and kind in ("鐘楼会館","旧街道の道標","沈黙の鐘楼"):
            if kind=="鐘楼会館":
                self.chapter_flags.add("bell1")
                self.last_clue="古い譜面に『門外へ告げ、広場へ返せ』。二音目は雨ざらしの青銅。"
            elif kind=="旧街道の道標" and "bell1" in self.chapter_flags:
                self.chapter_flags.add("bell2")
                audio.play("bell")
                self.last_clue="小鐘が応えた。「最後の声は、沈黙を名に持つもの」。"
            elif kind=="沈黙の鐘楼" and "bell2" in self.chapter_flags:
                self.quest_steps[3]=3
                audio.play("bell")
                self.last_clue="三つの鐘が共鳴した！ 雷の力が覚醒し、北の砦の鎖が切れた。"
            else:
                self.last_clue=self.journal_goal(4)
        elif index==5 and self.quest_steps[4]==1 and kind in ("水門管理所","旧街道の道標"):
            if "sluice" not in self.chapter_flags:
                self.chapter_flags.update(("sluice","canal" if kind=="水門管理所" else "bank"))
            self.last_clue=("迂回水路を開いた。下流の家へ水が戻る。" if "canal" in self.chapter_flags else "古い堤を切った。干上がった湿地に水が戻る。")+"大地で水路を支えよう。"
        elif kind=="市民" and index==3 and self.quest_steps[2]==2:
            self.chapter_flags.add("remedy")
            self.quest_steps[2]=3
            self.last_clue="患者の呼吸が戻り、手に新芽が開いた。回復の力が覚醒！"
        elif kind=="廃宿の宝箱":
            self.road_map=True
            self.last_clue="廃宿の手描き地図：さらに西へ一地区。地の力で橋を直せる。"
        elif kind=="崩れ橋":
            if self.bridge_fixed:
                if not self.royal_order:
                    self.tell("先に国王に会おう。")
                    return True
                city=self.pinned or 1
                _,gx,gy,_,_=REALMS[city-1]
                self.royal_travel("capital",(gx*WIDTH,gy*PLAY_H+82))
                self.tell("旧街道を抜けて"+REALMS[city-1][0]+"に着いた。")
                return True
            self.last_clue="橋のそばで大地（M）を使おう。" if self.road_map else "東の廃宿に橋の設計図がある。"
        elif kind=="旧街道の道標":
            if self.bridge_fixed:
                self.royal_travel("capital",(-2*WIDTH,152))
                self.tell("修復した橋まで戻った。")
                return True
            self.last_clue="王城西の橋が落ちて、旧街道が閉じている。"
        elif 1<=index<=5 and kind in COMMISSIONS[index-1][1:4]:
            power,giver,site,witness,task,_,clue=COMMISSIONS[index-1]
            stage=self.quest_steps[index-1]
            if not self.royal_order:
                self.tell("王城で国王に話しかけよう。")
                return True
            if kind==giver and stage==0:
                self.quest_steps[index-1]=1
                if power=="flame" and "sword" not in self.owned_gear:
                    self.owned_gear.add("sword")
                    self.weapon="sword"
                self.last_clue=f"{giver}：{self.journal_goal(index)}。"
            elif kind==witness and stage==2 and index==3 and "remedy" not in self.chapter_flags:
                self.last_clue=self.journal_goal(3)
            elif kind==witness and stage==2:
                self.quest_steps[index-1]=3
                self.last_clue=f"{witness}：{clue}"
                self.burst_effect("heal",*self.player.center,GOLD,18)
                self.tell(f"{POWER_NAMES[power]}の力が覚醒！　{UPGRADES[index-1]}",6)
                return True
            elif kind in (giver,witness):
                before,memory,weakness,after=TALES[index-1]
                if index in self.lords:
                    lines=(after,rift.HARBOR_RUMORS[index-1],memory)
                elif stage==3:
                    lines=(weakness,clue,memory)
                else:
                    lines=(self.journal_goal(index),before,memory)
                self.last_clue=self.conversation(f"{index}/{kind}/{stage}/{index in self.lords}",*lines)
            else:
                self.last_clue=clue if stage==3 else self.journal_goal(index)
        else:
            return False
        self.tell(self.last_clue,6)
        return True

    def use_quest_power(self, power, strike=False):
        if self.interior!="capital":
            return False
        for kind,r,i in self.capital_features():
            if math.dist(self.player.center,r.midbottom)>75:
                continue
            if kind=="崩れ橋" and power=="earth" and self.road_map and not self.bridge_fixed:
                self.bridge_fixed=True
                self.last_clue="橋が開通！手帳で街を選び、橋でEを押すと近道へ。"
            elif 1<=i<=5 and kind==COMMISSIONS[i-1][2] and self.quest_steps[i-1]==1 and power==COMMISSIONS[i-1][0]:
                if i==4 or (i==2 and "copper" not in self.chapter_flags) or (i==5 and "sluice" not in self.chapter_flags):
                    self.tell(self.journal_goal(i))
                    return False
                if power=="flame":
                    if not strike:
                        continue
                    vx,vy=r.centerx-self.player.centerx,r.centery-self.player.centery
                    if vx*self.direction[0]+vy*self.direction[1]<0:
                        continue
                if i==5:
                    self.quest_steps[4]=3
                    self.last_clue="流れが変わり、月の影から砦が現れた。大地の力が覚醒！"
                    self.burst_effect("earth",*r.center,LANDMARK_COLORS[4],18)
                    self.tell(self.last_clue,6)
                    return True
                self.quest_steps[i-1]=2
                self.last_clue=PORT_WITNESS if i==1 else self.journal_goal(3) if i==3 else f"{kind}が復旧！広場の北東で{COMMISSIONS[i-1][3]}に会おう。"
                if i==1:
                    audio.play("bell")
            else:
                continue
            self.burst_effect("heal" if power=="heal" else "earth",*r.center,LANDMARK_COLORS[i-1] if i else GOLD,18)
            self.tell(self.last_clue,6)
            return True
        return False

    def capture_boss(self):
        if any(e.hp>0 and e.kind=="boss" for e in self.enemies):
            self.retry_data=deepcopy(self.save_data())

    def retry_boss(self):
        snapshot=self.retry_data
        if not snapshot:
            return
        self.restore_data(deepcopy(snapshot),True)
        self.retry_data=snapshot
        self.effects.clear()
        self.attack_timer=self.jump_timer=self.dash_flash=0
        self.invulnerable=.8
        self.saved_progress = None
        self.tell("扉に戻った。入室時の体力と持ち物で再挑戦！")

    def royal_travel(self, destination, position):
        self.remember_castle()
        self.courier_run=2.4 if destination=="guild" and "rescue_note" not in self.chapter_flags else 0
        self.interior, self.room = destination, None
        self.door_lock = None
        self.bomb_list.clear()
        self.effects.clear()
        self.player.center = position
        self.load_room()
        self.retry_data=None
        self.capture_boss()

    def return_village(self):
        self.world = (7, 5)
        ox, oy = self.chunk_offset(self.world)
        self.royal_travel(None, (ox+400, oy+398))

    def advance_people(self,dt):
        royal=self.interior=="capital"
        if not royal and (self.interior is not None or self.room is not None):
            return
        if royal:
            cx,cy=self.royal_cell(*self.player.center)
            homes=((k,*rect.midbottom) for k,rect,_ in nearby_capital_features(cx,cy,tuple(self.quest_steps))
                   if k in ("急使","市民",*hearth.WITNESSES))
        else:
            homes=((npc["name"],npc["x"]+self.chunk_offset(cell)[0],npc["y"]+self.chunk_offset(cell)[1])
                   for cell in self.visible_chunks for npc in NPCS.get(cell,[]) if npc.get("role")!="guard")
        self.npc_poses.clear()
        for name,x,y in homes:
            if abs(x-self.player.centerx)>650 or abs(y-self.player.centery)>475:
                continue
            key=(royal,name,x,y)
            if key not in self.patrols:
                def clear(px,py):
                    return not self.blocked(pygame.Rect(px-7,py-8,14,10))
                if not clear(x,y):
                    continue
                self.patrols[key]=townsfolk.route(name,x,y,clear)
            patrol=self.patrols[key]
            patrol.tick(dt,self.player.center)
            self.npc_poses[(name,*patrol.position)]=(patrol.pose,patrol.end[0]*(-1 if patrol.returning else 1))
    
    def capital_features(self,moving=True):
        # Only the nine districts touching the camera or player need geometry.
        cx = (self.player.centerx + WIDTH//2)//WIDTH
        cy = (self.player.centery + PLAY_H//2)//PLAY_H
        nearby=nearby_capital_features(cx,cy,tuple(self.quest_steps))
        if moving:
            nearby=tuple((kind,rect.move(p.position[0]-rect.centerx,p.position[1]-rect.bottom),index)
                     if (p:=self.patrols.get((True,kind,*rect.midbottom))) else (kind,rect,index)
                     for kind,rect,index in nearby)
        if moving:
            nearby+=tuple((k,pygame.Rect(x-8,y-20,16,20),0) for k,x,y in life.features(self,cx,cy,REALMS))
        if self.game_won and abs(cx+3)<=1 and abs(cy)<=1:
            return (*nearby,("境界遺跡",pygame.Rect(-2440,-78,80,76),0))
        return nearby

    def crown_offer(self, kind, rect):
        if not any(kind == name and rect == building for name,building,_ in CROWN_SITES):
            return None
        if kind == "鍛冶屋":
            if self.weapon_level >= len(ROYAL_FORGE_PRICES):
                return "王室鍛冶：最高強化＋5", 0
            return f"王室鍛冶：武器を＋{self.weapon_level+1}に強化", ROYAL_FORGE_PRICES[self.weapon_level]
        if kind == "薬屋":
            return "王室の霊薬：体力を全回復", 12
        if kind == "道具屋":
            return "大爆弾：広範囲に6ダメージ", 9
        return None

    def buy_crown_offer(self, kind, offer):
        label,price = offer
        if price == 0:
            self.tell(label)
            return
        if kind == "鍛冶屋" and self.weapon=="none":
            self.tell("王室鍛冶師：強化する剣か槍を装備してくれ。")
            return
        if self.rupees < price:
            self.tell(f"{label}には◆{price}必要。現在は◆{self.rupees}。")
            return
        self.rupees -= price
        if kind == "鍛冶屋":
            self.weapon_level += 1
            self.tell(f"王室鍛冶師が武器を＋{self.weapon_level}に鍛え上げた。")
        elif kind == "薬屋":
            self.elixirs += 1
            self.tell("王室の霊薬を購入。Shift＋Lで体力を全回復。")
        else:
            self.heavy_bombs += 1
            self.tell("大爆弾を購入。Shift＋Kで設置。")

    def capital_interact(self):
        if self.interior == "palace":
            if math.dist(self.player.center,(400,158)) < 80:
                if self.royal_order:
                    if self.game_won:
                        if "rift_ferry" in self.chapter_flags:
                            self.chapter_flags.add("rift_report")
                            self.last_clue=rift.objective(self.chapter_flags)
                            if "salt_home" in self.chapter_flags:
                                self.tell("国王：港の掲示台へ、地上からの手紙も届けよう。" if "salt_names" in self.chapter_flags else "国王：夜渡りの便に名簿は要らぬ。港には温かい食事を用意させよう。",7)
                            else:
                                self.tell("国王：七隻目の帰港印がないそうだ。ナギの舟で対岸を訪ねてくれ。",7)
                        elif "rift_map" in self.chapter_flags:
                            self.royal_travel("capital",(-2400,24))
                            self.tell("国王の馬車が西街道に着いた。目の前の境界遺跡をEで調べよう。",6)
                        else:
                            self.chapter_flags.add("rift_map")
                            self.last_clue=rift.objective(self.chapter_flags)
                            self.tell("国王：西の旧街道に遺跡が現れた。向こうから救難の鐘だ。もう一度話せば馬車を出そう。",7)
                        return
                    freed=len(self.lords-{0})
                    name=next((r[0] for i,r in enumerate(REALMS,1) if i not in self.lords),"五街")
                    self.tell(self.conversation(f"国王/{freed}",f"国王：{name}からの便りを待っている。",f"国王：五街の封印は昔、民が築いた。今、{freed}つが戻った。"),6)
                    return
                self.royal_order = True
                self.last_clue="国王：五街の住民を助け、その力で砦の封印を解いてくれ。"
                self.tell("国王：五つの街を解放せよ。王城前の馬車で次の街へ向かえる。",7)
            else:
                self.tell("赤い絨毯を北へ。玉座の国王に話しかけよう。")
            return
        if self.interior != "capital":
            return
        candidates = [(math.dist(self.player.center, rect.midbottom), kind, rect, index)
                      for kind, rect, index in self.capital_features()]
        if not candidates:
            self.tell("街道は石壁の城門につながっている。Pで現在地と街道を確認。")
            return
        distance, kind, rect, index = min(candidates, key=lambda entry: entry[0])
        if distance > 68:
            self.tell("建物の正面か人のそばで E。王城と五街の位置は P。")
        elif kind=="急使" or kind in life.EXTRAS:
            life.interact(self,kind)
        elif kind in east.VENUES:
            self.royal_travel(east.VENUES[kind],(400,478))
        elif kind=="東門の道標":
            if "survey_taken" in self.chapter_flags and "survey_paid" not in self.chapter_flags:
                self.chapter_flags.add("survey_ready")
                self.tell("道標の方角を記録した。ギルドの測量掲示板へ戻ろう。")
            else:
                self.tell("西へ：冒険者ギルド、星灯カジノ、王城。")
        elif kind==hearth.WITNESSES[0] and "letter_taken" in self.chapter_flags and "letter_ready" not in self.chapter_flags:
            self.chapter_flags.add("letter_ready")
            self.tell("ハル：紹介状、受け取ったよ。ギルドで配達の報酬をもらいな。")
        elif kind in hearth.WITNESSES or kind in ("炊事長ユノ","炊事の荷車","きさらぎの宿帳"):
            hearth.city(self,kind)
        elif kind=="境界遺跡":
            self.royal_travel("rift_ruins",(400,467))
            self.tell("境界遺跡。古い石碑の向こうで、六つの灯が門を照らしている。",6)
        elif self.quest_interact(kind,CITY_INDEX.get((round(rect.centerx/WIDTH),round(rect.centery/PLAY_H)),0) if kind=="市民" else index):
            return
        elif kind in CIVIC_HALLS or kind=="峠の道標":
            self.tell("北へ：峠の魔王砦　　南へ："+REALMS[index-1][0] if kind=="峠の道標" else kind+"：砦は街の外。北へ二地区、峠道の奥だ。",5)
        elif kind == "街道宿":
            self.hp = self.max_hp
            self.tell("街道宿でひと休みした。体力が全回復した。")
        elif kind == "王城":
            self.royal_travel("palace", (400,490))
        elif kind == "帰郷便":
            self.return_village()
        elif kind == "駅馬車":
            if index:
                self.royal_travel("capital",(0,80))
                self.tell("王城前に到着した。")
            elif not self.royal_order:
                self.tell("御者：まず北の王城で国王にお会いください。")
            else:
                target = next((i for i in range(1,6) if i not in self.lords), None)
                if target is None and self.game_won:
                    target=self.pinned or 1
                if target:
                    name, x, y, _, _ = REALMS[target-1]
                    self.royal_travel("capital",(x*WIDTH,y*PLAY_H+80))
                    if target==1:
                        audio.play("bell")
                    self.tell(f"{name}に到着。" if self.game_won else f"{name}に到着。広場の西で{COMMISSIONS[target-1][1]}に話を聞こう。")
        elif kind == "魔王砦":
            if index in self.lords:
                self.tell("砦の封印は解けた。街には平穏が戻っている。")
            elif not self.royal_order:
                self.tell("砦は封鎖されている。王城の国王に会おう。")
            elif self.quest_steps[index-1]<3:
                self.tell(self.journal_goal(index),5)
            else:
                self.royal_travel("keep"+str(index),(400,498))
                self.tell("玉座への道を四天王が守っている。")
        elif kind=="市民":
            cell=(round(rect.centerx/WIDTH),round(rect.centery/PLAY_H))
            city=CITY_INDEX.get(cell,0)
            if city:
                before,memory,weakness,after=TALES[city-1]
                if city==5 and "sluice" in self.chapter_flags:
                    after="湿地に鳥が戻ったよ。堤を開いたおかげだ。" if "bank" in self.chapter_flags else "朝一番に水車で粉をひけた。水路が戻ったんだね。"
                lines=(after,rift.HARBOR_RUMORS[city-1],memory) if city in self.lords else (before,memory,self.journal_goal(city))
            else:
                lines=("広場の石は五つの街から一枚ずつ運んだんだ。","西門を出たら、街道沿いの廃宿を探してみて。")
            self.tell("市民："+self.conversation(f"市民/{city}/{city in self.lords}",*lines),5)
        elif (offer := self.crown_offer(kind, rect)) is not None:
            self.buy_crown_offer(kind,offer)
        elif kind in ("薬屋","道具屋"):
            self.buy_shop_item("potion" if kind=="薬屋" else "bomb")
        elif kind == "鍛冶屋":
            cell=(round(rect.centerx/WIDTH),round(rect.centery/PLAY_H))
            if cell==REALMS[1][1:3] and 2 not in self.lords:
                self.tell("鋳物師：魔王を倒したらこの鍛冶場も営業を再開できる。")
                return
            if self.weapon=="none" or self.weapon_level>=3 or self.rupees<8:
                self.tell("鍛冶屋：強化は8エメラルド。剣か槍を装備してくれ。上限は＋3だ。")
            else:
                self.rupees -= 8
                self.weapon_level += 1
                self.tell(f"武器を＋{self.weapon_level}に強化した。")
        else:
            self.tell(("市民：石畳の大通りは王城前につながっているよ。",
                       "市民：薬屋は薬を、道具屋は爆弾を売っている。",
                       "市民：街の馬車なら王城前までひと息だよ。")[index%3])

    def draw_capital(self):
        screen.fill((86,117,82))
        camx, camy = self.camera_offset()
        for index,ox,oy in districts_under(pygame.Rect(camx,camy,WIDTH,PLAY_H)):
            layer,_=district_art(index)
            screen.blit(layer,self.to_screen_point(ox,oy))
        for kind, rect, index in self.capital_features():
            r = self.to_screen_rect(rect)
            margin = (700,250) if kind==COMMISSIONS[0][2] else (80,80)
            if not r.colliderect(screen.get_rect().inflate(*margin)):
                continue
            if kind in life.EXTRAS:
                x,y=r.midbottom
                if kind in life.PEOPLE:
                    if self.town_time%90>75:
                        self.npc_poses[(kind,*rect.midbottom)]=(1 if int(self.town_time*5)%2 else -1,1)
                    self.draw_npc(royal_npc(kind,*rect.midbottom,len(kind)))
                elif kind=="車輪の跡":
                    for step in range(-4,5):
                        pygame.draw.line(screen,(106,84,65),(x+step*7,y-6),(x+step*7+4,y-5),2)
                        pygame.draw.line(screen,(122,90,70),(x+step*7,y+4),(x+step*7+4,y+5),2)
                elif kind=="壊れた橋":
                    pygame.draw.rect(screen,(68,109,122),(x-31,y-17,62,28))
                    for step in range(-3,4):
                        if step or "rescue_bridge" in self.chapter_flags:
                            pygame.draw.rect(screen,(169,128,80),(x+step*8-3,y-14,7,22))
                else:
                    pygame.draw.rect(screen,(130,85,55),(x-19,y-16,38,17))
                    if kind==life.CART:
                        for wx in (-12,12):pygame.draw.circle(screen,INK,(x+wx,y+2),5)
                        pygame.draw.ellipse(screen,(87,88,78),(x-11,y-22,22,10))
                    else:
                        pygame.draw.polygon(screen,(163,91,72),[(x-24,y-17),(x-13,y-31),(x+13,y-31),(x+24,y-17)])
                if kind not in life.PEOPLE:self.center_text(kind,x,y+17,SMALL,GOLD)
                continue
            if kind in east.VENUES:
                casino=kind=="星灯カジノ"
                self.draw_town_building(r,kind,(181,150,107),(95,60,89))
                roof=(112,52,78) if casino else (56,88,96)
                pygame.draw.polygon(screen,roof,[(r.left-8,r.top+18),(r.left+35,r.top-19),(r.right-35,r.top-19),(r.right+8,r.top+18)])
                for side in (-1,1):
                    tx=r.centerx+side*48
                    pygame.draw.polygon(screen,GOLD if casino else (103,154,130),[(tx-8,r.top+22),(tx+8,r.top+22),(tx+8,r.top+61),(tx,r.top+54),(tx-8,r.top+61)])
                continue
            if kind=="東門の道標":
                pygame.draw.rect(screen,(116,76,48),r)
                self.center_text(kind,r.centerx,r.top-10,SMALL,GOLD)
                continue
            if kind=="境界遺跡":
                rift.arch(screen,r.centerx,r.bottom,pygame.time.get_ticks(),2)
                self.center_text(kind,r.centerx,r.bottom+17,SMALL,GOLD)
                continue
            if kind in hearth.WITNESSES or kind in ("炊事長ユノ","急使"):
                self.draw_npc(royal_npc(kind,*rect.midbottom,index))
                continue
            if kind in ("炊事の荷車","きさらぎの宿帳"):
                x,y=r.midbottom
                pygame.draw.rect(screen,(129,86,54),(x-16,y-17,32,16))
                if kind=="炊事の荷車":
                    for wx in (x-11,x+11):
                        pygame.draw.circle(screen,INK,(wx,y),5)
                    pygame.draw.ellipse(screen,(68,73,69),(x-12,y-22,24,10))
                else:
                    pygame.draw.rect(screen,(223,199,143),(x-11,y-21,22,10))
                self.center_text(kind,x,y+15,SMALL,GOLD)
                continue
            if decorate(self,screen,kind,r,index,royal_npc,rect.midbottom,SMALL):
                continue
            if kind in ("市民","駅馬車","帰郷便"):
                self.draw_npc(royal_npc(kind, *rect.midbottom, index))
                if kind != "市民":
                    pygame.draw.rect(screen,(94,63,45),(r.right+4,r.bottom-25,32,17))
                    for wx in (r.right+10,r.right+30):
                        pygame.draw.circle(screen,INK,(wx,r.bottom-7),6)
            elif kind=="峠の道標":
                pygame.draw.rect(screen,(108,78,51),r)
                self.center_text("↑ 魔王砦",r.centerx,r.top-8,SMALL,GOLD)
            elif kind=="魔王砦" or kind in CIVIC_HALLS:
                self.center_text(kind,r.centerx,r.bottom-43,SMALL,GOLD)
            elif kind in ("王城","薬屋","道具屋","鍛冶屋","民家") and (round(rect.centerx/WIDTH),round(rect.centery/PLAY_H)) in TOWN_ART_CELLS:
                self.center_text(kind,r.centerx,r.bottom-43,SMALL,GOLD)
            else:
                roof = (73,89,120) if kind=="王城" else (99,61,66) if kind=="魔王砦" else (106,75+index%30,64)
                self.draw_town_building(r,kind,(158,139,108),roof)
                pygame.draw.polygon(screen,roof,[(r.left-7,r.top+23),(r.centerx,r.top-13),(r.right+7,r.top+23)])
                if kind in ("王城","魔王砦"):
                    for tx in (r.left,r.right-22):
                        pygame.draw.rect(screen,(96,103,120),(tx,r.top-18,22,52))
                        for offset in (0,14):
                            pygame.draw.rect(screen,(112,120,138),(tx+offset,r.top-24,8,10))
        px,py=self.player.center
        if math.hypot(px/WIDTH,py/PLAY_H)>98:
            bearing=math.atan2(py/PLAY_H,px/WIDTH)
            rim=[self.to_screen_point(WIDTH*100*math.cos(bearing+i*.001),
                                      PLAY_H*100*math.sin(bearing+i*.001))
                 for i in range(-22,23)]
            pygame.draw.lines(screen,(65,70,74),False,rim,16)
            pygame.draw.lines(screen,(153,151,140),False,rim,5)
        nearest = min(self.capital_features(),key=lambda f:math.dist(self.player.center,f[1].midbottom),default=None)
        if nearest is None:
            return
        kind, rect, _ = nearest
        if math.dist(self.player.center,rect.midbottom)<68:
            label = {"街道宿":"宿で休む（全回復）","薬屋":"薬を買う ◆5","道具屋":"爆弾を買う ◆2","鍛冶屋":"武器を強化 ◆8"}.get(kind,kind)
            offer=self.crown_offer(kind,rect)
            if offer is not None:
                label=offer[0]+(f"　◆{offer[1]}" if offer[1] else "")
            self.center_text("E　"+label,400,HEIGHT-96,SMALL,GOLD)

    def draw_royal_map(self):
        screen.fill((29,40,49))
        center = (370,300)
        pygame.draw.circle(screen,(75,104,83),center,220)
        pygame.draw.circle(screen,GOLD,center,220,2)
        self.center_text("王都と五街　｜　王城から外周まで100画面",400,42,FONT,GOLD)
        for route in ROYAL_ROUTES:
            pygame.draw.lines(screen,(177,152,108),False,
                              [(370+round(x*2.2),300+round(y*2.2)) for x,y in route],2)
        for x,y in ROADSIDE_INNS:
            pygame.draw.rect(screen,(233,199,143),(368+round(x*2.2),298+round(y*2.2),5,5))
        for i,(name,x,y,_,_) in enumerate([("王城",0,0,"",None),*REALMS]):
            pos = (370+round(x*2.2),300+round(y*2.2))
            pygame.draw.circle(screen,GOLD if i not in self.lords else GREEN,pos,6)
            self.center_text(name,pos[0],pos[1]-18,SMALL,WHITE)
        gx,gy=REALMS[self.pinned-1][1:3] if self.pinned else (-2 if self.road_map else -1,0)
        if self.pinned and self.quest_steps[self.pinned-1]==3 and self.pinned not in self.lords:
            gy-=2
        region,target,line=life.destination(self,REALMS)
        if region=="royal":
            gx,gy=target
        if line:self.center_text("追跡　"+line,400,455,SMALL,GOLD)
        fx,fy=370+round(gx*2.2),300+round(gy*2.2)
        pygame.draw.line(screen,GOLD,(fx+6,fy),(fx+6,fy-22),2)
        pygame.draw.polygon(screen,(244,130,76),[(fx+6,fy-22),(fx+21,fy-19),(fx+6,fy-13)])
        if self.interior=="capital":
            x,y=self.player.center
        elif self.interior.startswith("keep"):
            _,gx,gy,_,_=REALMS[int(self.interior[-1])-1]
            x,y=gx*WIDTH,(gy-2)*PLAY_H
        else:
            x=y=0
        pygame.draw.circle(screen,(111,225,255),(370+round(x/WIDTH*2.2),300+round(y/PLAY_H*2.2)),4)
        if self.game_won:
            self.center_text("境界遺跡　王城から西へ三地区",400,522,SMALL,GOLD)
        self.center_text("王城から東へ　2地区：星灯カジノ　3地区：冒険者ギルド",400,490,SMALL,GOLD)
        self.center_text("水色は現在地　・　四角は街道宿　・　/で閉じる",400,558,SMALL,WHITE)

    def location_key(self):
        if self.interior is not None:
            return ("interior", self.interior)
        return ("over", *self.world) if self.room is None else ("dun", self.room[0], *self.room[1:])

    def set_spawn(self, edge):
        if edge == "left":
            self.player.topleft = (WIDTH - TILE + 7, HUD_H + (ROWS // 2) * TILE + 7)
        elif edge == "right":
            self.player.topleft = (7, HUD_H + (ROWS // 2) * TILE + 7)
        elif edge == "up":
            self.player.topleft = (COLS // 2 * TILE + 7, HEIGHT - TILE + 7)
        elif edge == "down":
            self.player.topleft = (COLS // 2 * TILE + 7, HUD_H + 7)
        else:
            self.player.topleft = (WIDTH // 2 - 12, HEIGHT // 2 - 5)

    def seed(self):
        return 17011 + self.room[0] * 809 + self.room[1] * 37 + self.room[2]

    def camera_offset(self):
        if self.interior=="capital":
            return self.player.centerx-WIDTH//2,self.player.centery-PLAY_H//2
        if self.room is not None or self.interior is not None:
            return 0, 0
        x = max(0, min(WORLD_W - WIDTH, self.player.centerx - WIDTH // 2))
        y = max(0, min(WORLD_H - PLAY_H, self.player.centery - PLAY_H // 2))
        return round(x), round(y)

    def to_screen_point(self, x, y):
        if self.room is not None or (self.interior is not None and self.interior!="capital"):
            return round(x), round(y)
        cam_x, cam_y = self.camera_offset()
        return round(x - cam_x), round(y - cam_y + HUD_H)

    def to_screen_rect(self, rect):
        x, y = self.to_screen_point(rect.x, rect.y)
        return pygame.Rect(x, y, rect.width, rect.height)

    def chunk_offset(self, cell):
        return cell[0] * WIDTH, cell[1] * PLAY_H - HUD_H

    def nearby_chunks(self, cell):
        return [(x, y) for y in range(max(0, cell[1] - 1), min(10, cell[1] + 2))
                for x in range(max(0, cell[0] - 1), min(15, cell[0] + 2))]

    def chunks_in_view(self):
        if self.room is not None:
            return []
        cam_x, cam_y = self.camera_offset()
        x0, x1 = cam_x // WIDTH, min(14, (cam_x + WIDTH - 1) // WIDTH)
        y0, y1 = cam_y // PLAY_H, min(9, (cam_y + PLAY_H - 1) // PLAY_H)
        return [(x, y) for y in range(y0, y1 + 1) for x in range(x0, x1 + 1)]

    def generate_overworld_obstacles(self, cell):
        ox, oy = self.chunk_offset(cell)
        if cell == (7, 5):
            # The town is a fixed, walled settlement. The only opening is the north gate.
            walls = [pygame.Rect(0, HUD_H, 365, 22),
                     pygame.Rect(435, HUD_H, WIDTH - 435, 22),
                     pygame.Rect(0, HUD_H + 22, 22, PLAY_H - 44),
                     pygame.Rect(WIDTH - 22, HUD_H + 22, 22, PLAY_H - 44),
                     pygame.Rect(0, HEIGHT - 22, WIDTH, 22)]
            result = [("town_wall", rect.move(ox, oy)) for rect in walls]
            for rect, *_ in TOWN_BUILDINGS:
                footprint = rect.inflate(18, 0)
                footprint.y -= 14
                footprint.height += 14
                result.append(("solid", footprint.move(ox, oy)))
            return result
        rng = random.Random(93217 + cell[0] * 401 + cell[1])
        result = []
        for _ in range(12):
            tx = rng.randrange(1, COLS - 1)
            ty = rng.randrange(1, ROWS - 1)
            if abs(tx - COLS // 2) < 2 or abs(ty - ROWS // 2) < 2:
                continue
            kind = "tree" if rng.random() < .65 else "rock"
            local = pygame.Rect(tx * TILE + 3, HUD_H + ty * TILE + 3, TILE - 6, TILE - 6)
            result.append((kind, local.move(ox, oy)))
        return result

    def pickup_key(self, item, cell=None):
        x, y, kind = item
        if self.interior in CASTLE or self.interior in ROYAL or self.interior in rift.AREAS:
            return ("castle", self.interior, kind, round(x), round(y))
        if self.room is not None:
            return ("dun", *self.room, kind, round(x), round(y))
        if cell is None:
            cell = (min(14, max(0, int(x // WIDTH))), min(9, max(0, int(y // PLAY_H))))
        ox, oy = self.chunk_offset(cell)
        return ("over", *cell, kind, round(x - ox), round(y - oy + HUD_H))

    def room_name(self):
        if self.interior in east.ROOMS:
            return east.ROOMS[self.interior]
        if self.interior in rift.AREAS:
            return rift.AREAS[self.interior]
        if self.interior=="capital":
            cx,cy=self.player.center
            district=(round(cx/WIDTH),round(cy/PLAY_H))
            if district in east.WARDS:
                return "環都アルカ・"+east.WARDS[district]
            if district in FORT_CELLS:
                return REALMS[FORT_CELLS[district]-1][0]+"郊外・封印の砦"
            if district in TRAIL_CELLS:
                return REALMS[TRAIL_CELLS[district]-1][0]+"郊外・北の峠"
            if district in BAY_CELLS:
                return "霞港・湾岸"
            name=next((r[0] for r in REALMS if district==r[1:3]),"環都アルカ")
            return f"{name}　東西 {district[0]}　南北 {district[1]}"
        if self.interior=="palace":
            return "環都アルカ・謁見の間"
        if self.interior and self.interior.startswith("keep"):
            return REALMS[int(self.interior[-1])-1][0]+"・封印の砦"
        if self.interior in CASTLE:
            return CASTLE[self.interior]
        if self.interior is not None:
            return f"{INTERIOR_NAMES[self.interior]}の中"
        if self.room is None:
            x, y = self.world
            if (x, y) == (7, 5):
                return f"きさらぎ町  •  地上 {y * 15 + x + 1}/150"
            return f"アシュベイル平原  •  地上 {y * 15 + x + 1}/150"
        d, x, y = self.room
        return f"遠征 {d + 1}：{DUNGEON_NAMES[d]}  •  区画 {y * 6 + x + 1}/30"

    def npcs_for_cell(self, cell):
        ox, oy = self.chunk_offset(cell)
        if cell==(7,5) and self.final_boss_defeated:
            mayor=royal_npc("村長",ox+400,oy+394,3)
            mayor["role"]="mayor"
        else:
            mayor=None
        people=[mayor] if mayor else []
        for npc in NPCS.get(cell,[]):
            x,y=npc["x"]+ox,npc["y"]+oy
            patrol=self.patrols.get((False,npc["name"],x,y))
            if patrol:
                x,y=patrol.position
            people.append(dict(npc,x=x,y=y))
        return people

    def overworld_enemies_for_cell(self, cell):
        """Keep each area's enemies in the world so crossing a boundary doesn't respawn them."""
        if cell not in self.overworld_enemy_state:
            enemies = []
            if cell != (7, 5) and ("over", *cell) not in self.cleared_rooms:
                seed = 90125 + cell[0] * 1009 + cell[1] * 9176
                rng = random.Random(seed)
                ox, oy = self.chunk_offset(cell)
                for _ in range(rng.randint(1, 3)):
                    x = rng.randrange(2, COLS - 2) * TILE + 8
                    y = HUD_H + rng.randrange(2, ROWS - 2) * TILE + 8
                    kind = rng.choice(["slime", "bat", "stalfos"])
                    hp, speed, color = {"slime": (3, 62, GREEN), "bat": (2, 85, RED),
                                        "stalfos": (4, 55, STONE)}[kind]
                    enemies.append(Enemy(x + ox, y + oy, kind, hp, speed, color))
            self.overworld_enemy_state[cell] = enemies
        return self.overworld_enemy_state[cell]

    def load_room(self):
        self.input_review.reset_route()
        self.input_review.pending = False
        self.last_guard=-100.0
        self.guard_ready=0.0
        self.recent_hit=None
        self.blink_followup=0
        self.spear_chain=False
        self.arrows.clear()
        self.attack_timer=0
        self.build_room()
        self.place_room_contents()
        self.recover_arrival()

    def clear_floor(self, x, y, enemy=False):
        # Leave room for both the sprite and a player approaching a pickup.
        bounds = pygame.Rect(0, HUD_H, WIDTH, PLAY_H)
        if self.room is None and self.interior is None:
            cell = (max(0, min(14, int(x // WIDTH))), max(0, min(9, int(y // PLAY_H))))
            bounds.move_ip(*self.chunk_offset(cell))
        check = self.enemy_blocked if enemy else self.blocked
        def fits(px, py):
            body = pygame.Rect(px-4, py-5, 32, 34)
            return bounds.contains(body) and not check(body)
        x, y = round(x), round(y)
        if fits(x, y):
            return x, y
        centers = ((bounds.left + col*TILE+8, bounds.top + row*TILE+8)
                   for row in range(ROWS) for col in range(COLS))
        for px, py in sorted(centers, key=lambda pos: (pos[0]-x)**2 + (pos[1]-y)**2):
            if fits(px, py):
                return px, py
        return x, y

    def place_room_contents(self):
        if self.interior is not None:
            return
        for mob in self.enemies:
            mob.x, mob.y = self.clear_floor(mob.x, mob.y, enemy=True)
        if self.room and self.room[1:] in ((1, 0), (3, 2), (4, 4)):
            if not any(item[2] == "chest" for item in self.pickups):
                self.pickups.append([WIDTH//2 - 10, HUD_H + TILE*4, "chest"])
        visible = []
        for item in self.pickups:
            if self.pickup_key(item) in self.collected_items:
                continue
            item[0], item[1] = self.clear_floor(item[0], item[1])
            if self.pickup_key(item) not in self.collected_items:
                visible.append(item)
        self.pickups = visible

    def build_room(self):
        self.hostile_attacks = []
        if self.interior is not None:
            self.load_interior()
            return
        if self.room is None:
            self.load_overworld_area()
            return
        rng = random.Random(self.seed())
        loc = self.location_key()
        self.visited.add(loc)
        self.obstacles = []
        self.enemies = []
        self.pickups = []
        # A clear central lane connects every screen exit; obstacles fill the margins.
        for _ in range(8):
            tx = rng.randrange(1, COLS - 1)
            ty = rng.randrange(1, ROWS - 1)
            cx, cy = COLS // 2, ROWS // 2
            if abs(tx - cx) < 2 or abs(ty - cy) < 2:
                continue
            kind = "pillar" if rng.random() < .7 else "rock"
            obstacle = pygame.Rect(tx * TILE + 3, HUD_H + ty * TILE + 3, TILE - 6, TILE - 6)
            self.obstacles.append((kind, obstacle))
        if loc not in self.cleared_rooms:
            count = 2 if self.room[1:] != (5, 4) else 1
            for i in range(count):
                x = rng.randrange(1, COLS - 1) * TILE + 8
                y = HUD_H + rng.randrange(1, ROWS - 1) * TILE + 8
                if self.room and self.room[1:] == (5, 4):
                    boss_id = self.room[0]
                    boss = BOSSES[boss_id]
                    self.enemies.append(Enemy(x, y, "boss", boss["hp"], 48 + boss_id * 2,
                                              boss["color"], boss_id=boss_id, max_hp=boss["hp"]))
                else:
                    kind = rng.choice(["slime", "bat", "stalfos"])
                    spec = {"slime": (3, 62, GREEN), "bat": (2, 85, RED), "stalfos": (4, 55, STONE)}[kind]
                    self.enemies.append(Enemy(x, y, kind, *spec))
            if rng.random() < .34:
                self.pickups.append([rng.randrange(2, COLS - 2) * TILE + 8,
                                     HUD_H + rng.randrange(2, ROWS - 2) * TILE + 8,
                                     rng.choice(["rupee", "heart", "bomb", "key"])])
        self.room_specials()
        self.pickups.extend(item.copy() for item in self.enemy_drops.get(loc, [])
                            if self.pickup_key(item) not in self.collected_items)

    def remember_castle(self):
        if self.interior in CASTLE or self.interior in rift.AREAS:
            self.castle_state[self.interior] = {
                "enemies": [asdict(e) for e in self.enemies if e.hp > 0],
                "pickups": [item.copy() for item in self.pickups],
            }

    def change_castle_area(self, destination, returning=False):
        self.remember_castle()
        self.interior = destination
        self.room = self.door_lock = None
        self.effects.clear()
        self.bomb_list.clear()
        if destination is None:
            ox, oy = self.chunk_offset((7, 4))
            self.player.center = (ox+400, oy+348)
        else:
            self.player.center = (400, 165 if returning else 506)
        self.load_room()
        if destination == "throne":
            self.final_boss_started = True
            self.capture_boss()
        self.tell({None:"地図保管庫に戻った。", "forecourt":"大階段を上り、城門へ向かおう。",
                   "great_hall":"奥の扉へ！　衛兵は倒しても、すり抜けてもいい。",
                   "throne":"黒冠の四天王が玉座への道をふさいでいる。"}[destination])

    def arena_index(self):
        if self.interior=="throne":
            return 0
        if self.interior and self.interior.startswith("keep"):
            return int(self.interior[-1])
        return None

    def next_defender(self):
        realm=self.arena_index()
        if realm is None or realm in self.lords or any(e.hp>0 for e in self.enemies):
            return False
        slot=self.captains_down[realm]
        x,y=388,174
        if math.dist(self.player.center,(x+12,y+12))<145:
            x,y=max(((178,222),(598,222),(388,395)),
                    key=lambda pos: math.dist(self.player.center,pos))
        color=REALMS[realm-1][4] if realm else BOSSES[5]["color"]
        if slot<4:
            hp=12+slot*3+realm
            self.enemies.append(Enemy(x,y,"boss",hp,46+slot*4,color,boss_id=slot,
                                      captain=slot,special_timer=1.6))
        elif self.seal_boards[realm]==0:
            hp=84+realm*5
            self.enemies.append(Enemy(x,y,"boss",hp,42+realm,color,boss_id=5,
                                      special_timer=1.8,special_count=realm))
        else:
            return False
        return True

    def seal_waiting(self):
        realm=self.arena_index()
        return (realm is not None and realm not in self.lords and self.captains_down[realm]==4
                and self.seal_boards[realm]!=0)

    def seal_input(self,key):
        realm=self.arena_index()
        x,y=self.seal_cursor%3,self.seal_cursor//3
        if key in (pygame.K_a,pygame.K_LEFT): x=max(0,x-1)
        elif key in (pygame.K_d,pygame.K_RIGHT): x=min(2,x+1)
        elif key in (pygame.K_w,pygame.K_UP): y=max(0,y-1)
        elif key in (pygame.K_s,pygame.K_DOWN): y=min(2,y+1)
        elif key==pygame.K_ESCAPE: self.seal_open=False
        elif key==pygame.K_r: self.seal_boards[realm]=starting_board(realm)
        elif key in (pygame.K_e,KEY_INTERACT,pygame.K_RETURN):
            self.seal_boards[realm]^=linked_tiles(realm,self.seal_cursor)
            audio.play("bell")
            if not self.seal_boards[realm]:
                self.seal_open=False
                self.tell("封印が解けた。玉座の主が立ち上がる！")
        self.seal_cursor=3*y+x

    def draw_seal(self):
        realm=self.arena_index()
        panel=pygame.Rect(125,77,550,430)
        pygame.draw.rect(screen,(26,31,44),panel,border_radius=10)
        pygame.draw.rect(screen,GOLD,panel,2,border_radius=10)
        self.center_text(SEAL_NAMES[realm],400,113,FONT,GOLD)
        self.center_text(RULES[realm]+"が一緒に反転する。九つの灯をすべて消そう。",400,159,SMALL,WHITE)
        for i in range(9):
            x,y=318+(i%3)*60,209+(i//3)*60
            lit=self.seal_boards[realm] & (1<<i)
            tile=pygame.Rect(x,y,46,46)
            pygame.draw.rect(screen,(99,81,55) if lit else (46,54,68),tile,border_radius=5)
            pygame.draw.circle(screen,GOLD if lit else (117,130,149),tile.center,9,0 if lit else 2)
            if self.seal_cursor==i:
                pygame.draw.rect(screen,WHITE,tile.inflate(6,6),3,border_radius=6)
        self.center_text("WASD・矢印で選択　 Eで反転　 Rで初期配置　 Escで閉じる",400,438,SMALL,WHITE)

    def waste_guardian(self,r):
        return Enemy(388,178,"boss",52+10*r,44+r*3,wastes.REGIONS[r][3],boss_id=r)

    def load_interior(self):
        self.enemies = []
        self.pickups = []
        self.obstacles = [("stone",pygame.Rect(*box)) for box in tide.obstacles(self.interior)]
        self.arena_beat=0
        cell=tide.CELLS.get(self.interior)
        self.tide_warning=.36 if cell and cell[1]==tide.chart(cell[0])[1][-1] else 2.8
        if self.interior in rift.AREAS:
            if self.interior=="rift_quay":
                self.obstacles=[("water",pygame.Rect(x,40,142,560)) for x in (0,658)]
            snapshot=self.castle_state.get(self.interior)
            if snapshot is not None:
                self.enemies=[self._enemy_from_data(e) for e in snapshot["enemies"]]
                self.pickups=[item.copy() for item in snapshot["pickups"]]
            elif self.interior in tide.NAMES:
                self.enemies=tide.spawn(self,Enemy)
            elif self.interior==wastes.THRONE and "ash_victory" not in self.chapter_flags:
                self.enemies=[Enemy(388,205,"boss",168,57,(196,92,139),boss_id=5)]
            elif self.interior in wastes.CELLS:
                r,x,y=wastes.CELLS[self.interior]
                if (x,y) not in (wastes.CAMP,wastes.WITNESS,wastes.KEEP):
                    rng=random.Random(r*700+x*31+y)
                    for i,(ex,ey) in enumerate(rng.sample([(185,195),(580,185),(270,383),(515,390),(382,165)],3+r//2)):
                        kind=rng.choice(("bat","slime","stalfos"))
                        self.enemies.append(Enemy(ex,ey,kind,8+2*r+(3 if kind=="stalfos" else 0),
                                                  78+5*r+(19 if kind=="bat" else 0),wastes.REGIONS[r][3]))
            elif self.interior=="rift_tower":
                self.enemies=[Enemy(x,y,"stalfos",8,66,(151,131,172)) for x,y in ((220,260),(400,209),(568,260))]
            return
        if self.interior in ROYAL:
            if self.interior.startswith("keep"):
                self.next_defender()
            return
        # Interior furniture is solid and arranged around a clear path to the exit.
        if self.interior in CASTLE:
            if self.interior == "great_hall":
                for x in (195, 568):
                    for y in (175, 330):
                        self.obstacles.append(("column", pygame.Rect(x, y, 37, 54)))
            snapshot = self.castle_state.get(self.interior)
            if snapshot is not None:
                self.enemies = [self._enemy_from_data(e) for e in snapshot["enemies"]]
                self.pickups = [item.copy() for item in snapshot["pickups"]]
            elif self.interior == "great_hall":
                for row, y in enumerate((145, 245, 355)):
                    for col, x in enumerate((102, 282, 466, 652)):
                        bat = (row + col) % 3 == 0
                        self.enemies.append(Enemy(x, y, "bat" if bat else "stalfos",
                                                  2 if bat else 4, 85 if bat else 55, RED if bat else STONE))
            elif self.interior == "throne" and not self.final_boss_defeated:
                self.next_defender()
            return
        if self.interior == "inn":
            self.obstacles = [("bed", pygame.Rect(120, 145, 145, 74)),
                              ("counter", pygame.Rect(510, 170, 175, 54))]
        elif self.interior.startswith("home"):
            self.obstacles = [("bed", pygame.Rect(125, 150, 150, 75)),
                              ("counter", pygame.Rect(515, 170, 130, 48))]
        elif self.interior == "shop":
            self.obstacles = [("shelf", pygame.Rect(95, 128, 180, 62)),
                              ("shelf", pygame.Rect(525, 128, 180, 62)),
                              ("counter", pygame.Rect(270, 205, 260, 52))]
        elif self.interior == "blacksmith":
            self.obstacles = [("forge", pygame.Rect(505, 155, 150, 112)),
                              ("counter", pygame.Rect(125, 170, 160, 54))]

    def building_door_rect(self, index):
        ox, oy = self.chunk_offset((7, 5))
        rect = TOWN_BUILDINGS[index][0]
        return pygame.Rect(ox + rect.centerx - 18, oy + rect.bottom + 2, 36, 16)

    def enter_interior(self, facility, building_index):
        self.interior_return = (self.world, self.player.copy(), facility, building_index)
        self.interior = facility
        self.player.topleft = (WIDTH // 2 - 12, HEIGHT - 105)
        self.load_room()
        self.tell(f"{INTERIOR_NAMES[facility]}に入った。Eキーで中を調べられる。")

    def leave_interior(self):
        if self.interior_return:
            self.world, self.player, _facility, building_index = self.interior_return
            # Restore the walkable approach position. The door lock handles re-entry.
            self.door_lock = ("building", building_index)
        self.interior = None
        self.interior_return = None
        self.load_room()
        self.tell("町へ出た。")

    def recover_arrival(self):
        if not self.blocked(self.player):
            return
        bounds = pygame.Rect(0, HUD_H, WIDTH, PLAY_H)
        if self.room is None and self.interior is None:
            bounds.move_ip(*self.chunk_offset(self.world))
        if self.interior=="capital":
            gx=(self.player.centerx+WIDTH//2)//WIDTH
            gy=(self.player.centery+PLAY_H//2)//PLAY_H
            if (gx,gy) in BAY_CELLS:
                self.player.center=(port_x*WIDTH,port_y*PLAY_H+35)
                if not self.blocked(self.player):
                    return
                gx,gy=port_x,port_y
            bounds.topleft=(gx*WIDTH-WIDTH//2,gy*PLAY_H-PLAY_H//2)
        origin = self.player.clamp(bounds)
        # Search nearby first, including diagonal gaps. Stay inside this destination.
        for radius in range(0, max(WIDTH, HEIGHT) + 8, 8):
            for offset in range(-radius, radius + 1, 8):
                for dx, dy in ((offset, -radius), (offset, radius), (-radius, offset), (radius, offset)):
                    candidate = origin.move(dx, dy)
                    if bounds.contains(candidate) and not self.blocked(candidate):
                        self.player.topleft = candidate.topleft
                        if self.world == (7, 5) and self.room is None and self.interior is None:
                            for index in range(len(TOWN_BUILDINGS)):
                                if candidate.colliderect(self.building_door_rect(index)):
                                    self.door_lock = ("building", index)
                                    break
                        return

    def handle_touch_interactions(self):
        if self.interior in east.ROOMS:
            if self.player.centery>545 and abs(self.player.centerx-400)<55:
                x,y=east.DOORS[self.interior]
                self.royal_travel("capital",(x,y+36))
            return
        if self.interior in rift.AREAS:
            for item in self.pickups[:]:
                if self.player.colliderect(pygame.Rect(*item[:2],20,20)):
                    self.collect(item)
            return
        if self.interior in ROYAL:
            if self.interior=="capital":
                for kind,rect,i in self.capital_features():
                    if kind in east.VENUES and abs(self.player.centerx-rect.centerx)<24 and 0<=self.player.top-rect.bottom<6:
                        self.royal_travel(east.VENUES[kind],(400,478))
                        break
                    if kind in ("王城","魔王砦") and (kind=="王城" or self.royal_order and i not in self.lords and self.quest_steps[i-1]==3):
                        if abs(self.player.centerx-rect.centerx)<24 and 0<=self.player.top-rect.bottom<6:
                            self.capital_interact()
                            break
            elif self.player.centery>545 and abs(self.player.centerx-400)<55:
                gx,gy=(0,0) if self.interior=="palace" else REALMS[int(self.interior[-1])-1][1:3]
                self.royal_travel("capital",(0, -132) if self.interior=="palace" else (gx*WIDTH,(gy-2)*PLAY_H+4))
            else:
                for item in self.pickups[:]:
                    if self.player.colliderect(pygame.Rect(*item[:2],20,20)):
                        self.collect(item)
            return
        if self.interior=="throne" and self.final_boss_defeated and self.player.centery>530:
            self.return_village()
            return
        if self.interior is None and self.room is None and self.world==(7,5) and self.final_boss_defeated and not self.mayor_met:
            self.mayor_met=True
            self.tell("村長：王都から召状じゃ。町の十字路でわしに話しかけてくれ。",8)

        if self.interior in CASTLE:
            if self.interior == "forecourt" and self.player.colliderect(CASTLE_DOOR):
                self.change_castle_area("great_hall")
            elif self.interior != "throne" and self.player.colliderect(pygame.Rect(348, 550, 104, 35)):
                self.change_castle_area(None if self.interior == "forecourt" else "forecourt", returning=True)
            else:
                for item in self.pickups[:]:
                    if self.player.colliderect(pygame.Rect(item[0], item[1], 20, 20)):
                        self.collect(item)
            return
        if self.interior is not None:
            exit_rect = pygame.Rect(WIDTH // 2 - 38, HEIGHT - 56, 76, 38)
            if self.player.colliderect(exit_rect):
                self.leave_interior()
            return

        # Door locks prevent immediately reopening the same entrance after returning.
        if self.door_lock is not None:
            kind, value = self.door_lock
            if kind == "building" and self.world == (7, 5) and self.room is None:
                still_touching = self.player.colliderect(self.building_door_rect(value))
            elif kind == "entrance" and self.room is None:
                marker = next((item for item in self.pickups
                               if item[2] == f"entrance{value}"), None)
                still_touching = marker is not None and self.player.colliderect(
                    pygame.Rect(round(marker[0] - 8), round(marker[1] - 8), 42, 35))
            else:
                still_touching = False
            if still_touching:
                return
            self.door_lock = None

        for item in list(self.pickups):
            x, y, kind = item
            if kind.startswith("entrance"):
                touched = self.player.colliderect(pygame.Rect(round(x - 8), round(y - 8), 42, 35))
                if touched:
                    self.door_lock = ("entrance", int(kind[-1]))
                    self.collect(item)
                    return
            elif kind == "final_gate":
                continue
            elif kind == "stairs":
                if self.player.colliderect(pygame.Rect(round(x - 7), round(y - 8), 36, 38)):
                    self.collect(item)
                    return
            elif self.player.colliderect(pygame.Rect(round(x), round(y), 20, 20)):
                self.collect(item)

        if self.room is None and self.world == (7, 5):
            for index, (rect, _title, _wall, _roof) in enumerate(TOWN_BUILDINGS):
                if self.player.colliderect(self.building_door_rect(index)):
                    facility = ("inn", "home_north", "shop", "home_south", "blacksmith",
                                "home_east", "home_west", "home_southwest")[index]
                    self.enter_interior(facility, index)
                    return

    def buy_shop_item(self, item):
        if item in ("heart_vessel","revival_feather"):
            vessel=item=="heart_vessel"
            price=24 if vessel else 16
            if vessel and self.max_hp>=12:
                self.tell("命の器の力は満ちている。最大ハートは12個。")
            elif self.rupees<price:
                self.tell(f"エメラルドが足りない。あと◆{price-self.rupees}必要。")
            else:
                self.rupees-=price
                if vessel:
                    self.max_hp+=1
                    self.hp+=1
                    self.tell(f"命の器を手に入れた！ 最大ハートが{self.max_hp}個になった。")
                else:
                    self.revival_feathers+=1
                    self.tell(f"不死鳥の羽を手に入れた！ 残り{self.revival_feathers}枚。")
            return
        if item == "potion":
            if self.rupees < 5:
                self.tell("薬は5エメラルド。お金が足りない。")
            else:
                self.rupees -= 5
                self.potions += 1
                self.tell("薬を買った。Lキーで使える。")
        elif item == "bomb":
            if self.rupees < 2:
                self.tell("爆弾は2エメラルド。お金が足りない。")
            else:
                self.rupees -= 2
                self.bombs += 1
                self.tell("爆弾を買った。")

    def interact_interior(self):
        cx, cy = self.player.center
        # The south doorway is always a usable exit.
        if cy > HEIGHT - 80 and abs(cx - WIDTH // 2) < 72:
            self.leave_interior()
            return
        if self.interior=="inn" and "hearth_inn" in self.chapter_flags and math.dist(self.player.center,(400,397))<70:
            self.tell(self.conversation("宿の相席","旅人：東門の急使が車輪の跡を見たそうだ。ギルドで続きを聞けるよ。","荷運び：王城の西街道にはね、土の下から鐘が鳴る場所があるんだ。","職人：夕方なら星灯街の宿前で仲間に会えるよ。"),6)
            return
        if self.interior=="inn" and "hearth_spoon" in self.chapter_flags and "hearth_meal" not in self.chapter_flags:
            for name,x,y in hearth.COOK:
                if math.dist(self.player.center,(x,y))<53:
                    hearth.cook(self,name)
                    return
        if self.interior == "inn" and pygame.Rect(105, 125, 175, 110).colliderect(self.player.inflate(48, 48)):
            cost = 0 if "hearth_inn" in self.chapter_flags else 3
            if self.rupees < cost:
                self.tell("宿代は3エメラルド。")
            else:
                self.rupees -= cost
                self.hp = self.max_hp
                self.inn_registered = True
                self.tell("体力が全回復した。この宿を復帰地点に登録した。")
        elif self.interior.startswith("home") and pygame.Rect(105, 125, 190, 115).colliderect(self.player.inflate(48, 48)):
            self.hp = min(self.max_hp, self.hp + 2)
            self.tell("ベッドでひと休みした。体力が2回復した。")
        elif self.interior == "shop":
            self.tell("道具屋：命の器は最大体力を増やし、不死鳥の羽は倒れた瞬間に発動するよ。")
        elif self.interior == "blacksmith":
            if not pygame.Rect(480, 135, 205, 160).colliderect(self.player.inflate(48, 48)):
                self.tell("奥の炉の近くでEキーを押すと武器を強化できる。")
            elif self.weapon == "none":
                self.tell("鍛冶屋：まず剣か槍を手に入れてきてくれ。")
            elif self.weapon_level >= 3:
                self.tell("鍛冶屋：武器はこれ以上強化できない。")
            elif self.rupees < 8:
                self.tell("武器強化は8エメラルド。")
            else:
                self.rupees -= 8
                self.weapon_level += 1
                self.tell(f"鍛冶屋で武器を強化した。強化段階 +{self.weapon_level}。")
        else:
            self.tell("下側の出口に触れると町へ戻る。")

    def enemy_blocked(self, rect):
        if self.blocked(rect):
            return True
        if self.room is not None:
            return not pygame.Rect(0, HUD_H, WIDTH, PLAY_H).contains(rect)
        if self.interior is not None:
            return False
        ox, oy = self.chunk_offset((7, 5))
        town_inner = pygame.Rect(ox + 22, oy + HUD_H + 22, WIDTH - 44, PLAY_H - 44)
        return rect.colliderect(town_inner)

    def load_overworld_area(self):
        loc = self.location_key()
        self.visited.add(loc)
        self.visible_chunks = self.nearby_chunks(self.world)
        self.obstacles = [obstacle for cell in self.visible_chunks for obstacle in self.generate_overworld_obstacles(cell)]
        self.enemies = [enemy for cell in self.visible_chunks
                        for enemy in self.overworld_enemies_for_cell(cell) if enemy.hp > 0]
        self.pickups = []
        rng = random.Random(2031 + self.world[0] * 1009 + self.world[1] * 9176)
        if loc not in self.cleared_rooms and self.world != (7, 5) and rng.random() < .34:
            self.pickups.append([rng.randrange(2, COLS - 2) * TILE + 8,
                                 HUD_H + rng.randrange(2, ROWS - 2) * TILE + 8,
                                 rng.choice(["rupee", "heart", "bomb", "key"])])
        # Add entrance, gear, and archive markers in local chunk coordinates.
        self.room_specials()
        ox, oy = self.chunk_offset(self.world)
        transformed = []
        for item in self.pickups:
            item[0] += ox
            item[1] += oy
            if self.pickup_key(item, self.world) not in self.collected_items:
                transformed.append(item)
        self.pickups = transformed
        for cell in self.visible_chunks:
            drop_loc = ("over", *cell)
            self.pickups.extend(item.copy() for item in self.enemy_drops.get(drop_loc, [])
                                if self.pickup_key(item, cell) not in self.collected_items)

    def room_specials(self):
        if self.room is None:
            x, y = self.world
            gear_sites = {(6, 5): "sword", (8, 5): "spear", (7, 6): "shield"}
            if (x, y) in gear_sites and gear_sites[(x, y)] not in self.owned_gear:
                self.pickups.append([WIDTH // 2, HEIGHT // 2 + 5, gear_sites[(x, y)]])
            for i, (sx, sy) in enumerate(DUNGEON_ENTRANCES):
                if (x, y) == (sx, sy) and i not in self.seals:
                    self.pickups.append([WIDTH // 2 - 12, HEIGHT // 2 - 10, f"entrance{i}"])
            if (x, y) == (7, 4) and len(self.seals) == 5 and not self.final_boss_defeated:
                self.pickups.append([WIDTH // 2 - 12, HEIGHT // 2 - 5, "final_gate"])
        else:
            d, x, y = self.room
            if (x, y) == (5, 4) and d not in self.seals and not self.enemies and not any(item[2] == f"seal{d}" for item in self.pickups):
                self.pickups.append([WIDTH // 2 - 10, HEIGHT // 2 - 5, f"seal{d}"])
            # A central staircase on the boss room returns the hero to the surface.
            if (x, y) == (5, 4) and d in self.seals and not any(item[2] == "stairs" for item in self.pickups):
                self.pickups.append([WIDTH // 2 - 10, HEIGHT // 2 + 25, "stairs"])

    def tell(self, text, seconds=3.0):
        self.message, self.message_timer = text, seconds

    @staticmethod
    def _enemy_from_data(raw):
        values = dict(raw)
        values["color"] = tuple(values["color"])
        if values.get("boss_id") == 5 and values.get("max_hp") == 28:
            values["max_hp"] = BOSSES[5]["hp"]
            values["hp"] = math.ceil(values["hp"] * values["max_hp"] / 28)
        # Preserve damage already taken when loading monsters created with the old stats.
        upgrade={"slime":(2,3,62), "bat":(1,2,85), "stalfos":(2,4,55)}.get(values.get("kind"))
        if upgrade and values.get("max_hp",values["hp"])==upgrade[0] and values["hp"]>0:
            old,new,speed=upgrade
            values.update(hp=values["hp"]+new-old,max_hp=new,speed=speed)
        for obsolete in ("seals_broken","duel","duel_left","line_x","line_y","axis_x","axis_y"):
            values.pop(obsolete,None)
        return Enemy(**values)

    def save_data(self):
        interior_return = None
        if self.interior_return:
            home_world, home_player, facility, building_index = self.interior_return
            interior_return = [list(home_world), list(home_player), facility, building_index]
        overworld_return = None
        if self.overworld_return:
            home_world, home_player = self.overworld_return
            overworld_return = [list(home_world), list(home_player)]
        self.remember_castle()
        return {
            "quest_steps": self.quest_steps, "last_clue": self.last_clue, "pinned":self.pinned,
            "road_map":self.road_map,"bridge_fixed":self.bridge_fixed,
            "captains_down": self.captains_down.copy(), "seal_boards": self.seal_boards.copy(),
            "lords": sorted(self.lords), "mayor_met": self.mayor_met, "royal_order": self.royal_order,
            "castle_state": self.castle_state,
            "version": 1, "capital_layout": 2, "talk_counts":self.talk_counts.copy(),
            "player_name": self.player_name,
            "inn_registered": self.inn_registered, "rich_effects": self.rich_effects,
            "world": list(self.world), "room": list(self.room) if self.room is not None else None,
            "interior": self.interior, "interior_return": interior_return,
            "overworld_return": overworld_return, "player": list(self.player),
            "direction": list(self.direction), "hp": self.hp, "max_hp": self.max_hp,
            "rupees": self.rupees, "keys": self.keys, "bombs": self.bombs, "potions": self.potions,
            "revival_feathers": self.revival_feathers, "elixirs": self.elixirs, "heavy_bombs": self.heavy_bombs,
            "owned_gear": sorted(self.owned_gear), "weapon": self.weapon,
            "weapon_level": self.weapon_level, "shield_equipped": self.shield_equipped,
            "shield_cooldown": self.shield_cooldown,
            "abilities": sorted(self.abilities), "power_cooldowns": self.power_cooldowns,
            "flame_timer": self.flame_timer, "map_obtained": self.map_obtained,
            "town_time":self.town_time,"tracking":self.tracking,
            "road_anchors": list(self.road_anchors.values()),
            "seals": sorted(self.seals), "visited": [list(item) for item in self.visited],
            "cleared_rooms": [list(item) for item in self.cleared_rooms],
            "collected_items": [list(item) for item in self.collected_items],
            "enemy_drops": [{"location": list(location), "items": items}
                             for location, items in self.enemy_drops.items()],
            "overworld_enemy_state": [
                {"cell": list(cell), "enemies": [asdict(enemy) for enemy in enemies]}
                for cell, enemies in self.overworld_enemy_state.items()],
            "enemies": [asdict(enemy) for enemy in self.enemies],
            "pickups": self.pickups,
            "magic_walls": [{"rect": list(wall["rect"]), "timer": wall["timer"],
                             "location": list(wall["location"])} for wall in self.magic_walls],
            "bomb_list": self.bomb_list, "final_boss_started": self.final_boss_started,
            "final_boss_defeated": self.final_boss_defeated,
            "ending_open": self.ending_open, "chapter_flags":sorted(self.chapter_flags),
            "game_won": self.game_won, "game_over": self.game_over,
            "door_lock": list(self.door_lock) if self.door_lock else None,
        }
    def progress_marker(self):
        return (self.room, self.interior, tuple(self.quest_steps), frozenset(self.lords),
                tuple(self.captains_down), tuple(self.seal_boards), self.tracking,len(self.road_anchors),
                frozenset(self.seals), frozenset(self.abilities), frozenset(self.owned_gear),
                self.max_hp, self.revival_feathers, self.elixirs, self.heavy_bombs, self.weapon_level, self.map_obtained, self.royal_order, self.mayor_met,
                self.bridge_fixed, self.road_map, self.inn_registered, self.game_won,self.ending_open,frozenset(self.chapter_flags))

    def update_autosave(self, dt):
        self.autosave_notice = max(0, self.autosave_notice - dt)
        if self.home_screen or self.name_editing or self.game_over:
            return
        self.autosave_retry = max(0, self.autosave_retry - dt)
        if not (self.inventory_open or self.map_open or self.warp_open or self.ending_open):
            self.autosave_elapsed += dt
        if self.autosave_retry:
            return
        if self.saved_progress != self.progress_marker() or self.autosave_elapsed >= AUTOSAVE_INTERVAL:
            if self.save_game(silent=True):
                self.autosave_notice = 2.0
            else:
                self.autosave_retry = 5.0
                self.tell("自動セーブに失敗。空き容量と保存先を確認してください。", 5)

    def save_game(self, silent=False):
        temporary = None
        try:
            data = self.save_data()
            data["retry_data"] = self.retry_data
            with NamedTemporaryFile(mode="w", encoding="utf-8", dir=SAVE_PATH.parent,
                                    prefix="ashvale_save_", suffix=".tmp", delete=False) as out:
                temporary = Path(out.name)
                json.dump(data, out, ensure_ascii=False, separators=(",", ":"))
                out.flush()
                os.fsync(out.fileno())
            os.replace(temporary, SAVE_PATH)
            temporary = None
            self.saved_progress = self.progress_marker()
            self.autosave_elapsed = self.autosave_retry = 0.0
            if not silent:
                self.tell("冒険をセーブした。F9キーでロードできる。")
            return True
        except (OSError, TypeError, ValueError) as error:
            if not silent:
                self.tell(f"セーブに失敗した：{error}")
            return False

        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass

    def apply_1018_bonus(self, announce=True):
        """Grant the hidden starter set to the special character name."""
        if self.player_name != "1018":
            return False
        already_complete = (set(POWER_NAMES) <= self.abilities
                           and {"sword", "spear", "shield", "bow"} <= self.owned_gear)
        self.abilities.update(POWER_NAMES)
        self.owned_gear.update(("sword", "spear", "shield", "bow"))
        if self.weapon not in ("sword", "spear", "bow"):
            self.weapon = "sword"
        if announce or not already_complete:
            self.shield_equipped = True
        if announce and not already_complete:
            self.tell("1018の特典！5つの力、剣・槍・弓・盾を手に入れた。槍はTキーで装備できる。", 6)
        return True

    def load_game(self, silent=False):
        try:
            data = json.loads(SAVE_PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            if not silent:
                self.tell(f"ロードに失敗した：{error}")
            return False
        return self.restore_data(data,silent)

    def restore_data(self,data,silent=False):
        try:
            if data.get("version") != 1:
                raise ValueError("このセーブデータの形式には対応していない。")
            self.buffered_powers.clear()
            self.talk_counts=dict(data.get("talk_counts",{}))
            self.inn_registered = bool(data.get("inn_registered", False))
            self.rich_effects = bool(data.get("rich_effects", True))
            self.player_name = data.get("player_name", "旅人")
            self.world = tuple(data.get("world", (7, 5)))
            room = data.get("room")
            self.room = tuple(room) if room is not None else None
            self.castle_state = data.get("castle_state", {})
            self.interior = data.get("interior")
            player = data.get("player", (0, 0, 24, 26))
            self.player = pygame.Rect(*player)
            if self.interior == "capital" and data.get("capital_layout",1) < 2:
                cell = ((self.player.centerx+400)//800,(self.player.centery+280)//560)
                if cell in CROWN_WARDS:
                    self.player.center = CROWN_PLAZA
            self.direction = tuple(data.get("direction", (0, 1)))
            for name in ("hp", "max_hp", "rupees", "keys", "bombs", "potions", "weapon_level", "flame_timer"):
                if name in data:
                    setattr(self, name, data[name])
            self.revival_feathers=data.get("revival_feathers",0)
            self.elixirs=data.get("elixirs",0)
            self.heavy_bombs=data.get("heavy_bombs",0)
            self.owned_gear = set(data.get("owned_gear", []))
            self.weapon = data.get("weapon", "none")
            self.shield_cooldown = float(data.get("shield_cooldown", 0))
            self.shield_equipped = data.get("shield_equipped", False)
            self.abilities = set(data.get("abilities", []))
            self.power_cooldowns = {key: float(value) for key, value in data.get("power_cooldowns", {}).items()}
            for power in POWER_NAMES:
                self.power_cooldowns.setdefault(power, 0.0)
            self.map_obtained = data.get("map_obtained", False)
            self.seals = set(data.get("seals", []))
            self.town_time=float(data.get("town_time",0))
            self.tracking=data.get("tracking",life.TRACKS[0])
            if self.tracking not in life.TRACKS:self.tracking=life.TRACKS[0]
            self.patrols.clear()
            self.npc_poses.clear()
            self.road_anchors={}
            for x,y in data.get("road_anchors",[]):
                self.road_anchors[self.royal_cell(x,y)]=(x,y)
            self.visited = {tuple(item) for item in data.get("visited", [])}
            self.cleared_rooms = {tuple(item) for item in data.get("cleared_rooms", [])}
            self.collected_items = {tuple(item) for item in data.get("collected_items", [])}
            self.enemy_drops = {tuple(entry["location"]): entry["items"]
                                for entry in data.get("enemy_drops", [])}
            self.overworld_enemy_state = {
                tuple(entry["cell"]): [self._enemy_from_data(enemy) for enemy in entry["enemies"]]
                for entry in data.get("overworld_enemy_state", [])}
            self.interior_return = None
            saved_interior = data.get("interior_return")
            if saved_interior:
                self.interior_return = (tuple(saved_interior[0]), pygame.Rect(*saved_interior[1]),
                                        saved_interior[2], saved_interior[3])
            self.overworld_return = None
            saved_return = data.get("overworld_return")
            if saved_return:
                self.overworld_return = (tuple(saved_return[0]), pygame.Rect(*saved_return[1]))
            self.magic_walls = [{"rect": pygame.Rect(*wall["rect"]), "timer": wall["timer"],
                                 "location": tuple(wall["location"])}
                                for wall in data.get("magic_walls", [])]
            self.bomb_list = data.get("bomb_list", [])
            self.final_boss_started = data.get("final_boss_started", False)
            self.final_boss_defeated = data.get("final_boss_defeated", False)
            self.lords=set(data.get("lords",[0] if self.final_boss_defeated else []))
            self.captains_down=list(data.get("captains_down",[0]*6))
            self.seal_boards=list(data.get("seal_boards",[starting_board(i) for i in range(6)]))
            self.seal_open=False
            self.seal_cursor=4
            # Honour an encounter already underway in saves from before the four guardians.
            arena=self.arena_index()
            if arena is not None and "captains_down" not in data and any(
                    e.get("boss_id")==5 and e["hp"]>0 for e in data.get("enemies", [])):
                self.captains_down[arena]=4
                self.seal_boards[arena]=0
            self.mayor_met=data.get("mayor_met",False)
            self.royal_order=data.get("royal_order",False)
            self.quest_steps=list(data.get("quest_steps",[3 if i in self.lords else 0 for i in range(1,6)]))
            self.last_clue=data.get("last_clue","手帳で次の目的を確認しよう。")
            self.pinned=data.get("pinned",1)
            self.bridge_fixed=data.get("bridge_fixed",False)
            self.road_map=data.get("road_map",False)
            if self.quest_steps[0]==2 and "遭難船の船員" in self.last_clue:
                self.last_clue=PORT_WITNESS
            self.retry_data=data.get("retry_data")
            self.journal_page=False
            self.game_won=self.lords==set(range(6))
            self.ending_open=self.game_won and data.get("ending_open",True)
            self.chapter_flags=set(data.get("chapter_flags",[]))
            if "tide_arms" in self.chapter_flags:self.owned_gear.add("bow")
            self.game_over = data.get("game_over", False)
            # Move unfinished final fights from older saves to the new castle route.
            if "castle_state" not in data and self.final_boss_started and not self.final_boss_defeated:
                for cell, mobs in self.overworld_enemy_state.items():
                    self.overworld_enemy_state[cell] = [e for e in mobs if e.boss_id != 5]
                self.final_boss_started = False
            self.load_room()
            fresh_gate = next((item for item in self.pickups if item[2] == "final_gate"), None)
            if self.room is not None or self.interior in ROYAL:
                self.enemies = [self._enemy_from_data(enemy) for enemy in data.get("enemies", [])]
            self.pickups = [list(item) for item in data.get("pickups", self.pickups)]
            self.pickups=[item for item in self.pickups if not (item[2].startswith("entrance") and int(item[2][-1]) in self.seals)]
            if fresh_gate and not any(item[2] == "final_gate" for item in self.pickups):
                self.pickups.append(fresh_gate)
            self.place_room_contents()
            self.map_open = False
            self.warp_open = False
            self.inventory_open = False
            self.name_editing = False
            self.apply_1018_bonus(announce=False)
            saved_lock = data.get("door_lock")
            self.door_lock = tuple(saved_lock) if saved_lock else None
            self.recover_arrival()
            if "retry_data" not in data and self.hp>0 and not self.game_over:
                self.capture_boss()
            self.saved_progress = self.progress_marker()
            self.autosave_elapsed = self.autosave_retry = self.autosave_notice = 0.0
            if not silent:
                self.tell(f"{self.player_name}の冒険をロードした。")
            return True
        except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
            if not silent:
                self.tell(f"ロードに失敗した：{error}")
            return False

    def is_overworld_neighbor(self, x, y):
        return 0 <= x < 15 and 0 <= y < 10

    def transition(self, edge):
        if self.transition_cooldown > 0:
            self.player.clamp_ip(pygame.Rect(0, HUD_H, WIDTH, PLAY_H))
            return
        dx, dy = {"left": (-1, 0), "right": (1, 0), "up": (0, -1), "down": (0, 1)}[edge]
        if self.room is None:
            nx, ny = self.world[0] + dx, self.world[1] + dy
            if self.is_overworld_neighbor(nx, ny):
                self.world = (nx, ny)
                self.set_spawn(edge)
            else:
                return
        else:
            d, x, y = self.room
            nx, ny = x + dx, y + dy
            if not (0 <= nx < 6 and 0 <= ny < 5):
                return
            self.room = (d, nx, ny)
            self.player.clamp_ip(pygame.Rect(0, HUD_H, WIDTH, PLAY_H))
            if dx > 0:
                self.player.left = 4
            elif dx < 0:
                self.player.right = WIDTH - 4
            elif dy > 0:
                self.player.top = HUD_H + 4
            else:
                self.player.bottom = HEIGHT - 4
        self.transition_cooldown = .3
        self.load_room()
        self.retry_data=None
        self.capture_boss()

    def enter_dungeon(self, dungeon):
        if dungeon in self.seals:
            return
        self.overworld_return = (self.world, self.player.copy())
        self.room = (dungeon, 0, 0)
        self.set_spawn("center")
        self.load_room()
        self.tell(f"{DUNGEON_NAMES[dungeon]}に入った。最奥のボスを倒そう！")

    def try_interact(self):
        if self.interior in tide.NAMES:
            tide.act(self);return
        if self.interior=="guild" and math.dist(self.player.center,(400,381+round(self.courier_run*65)))<57:
            self.courier_run=0
            life.interact(self,"急使の報告")
            return
        if self.interior in east.ROOMS:
            site=east.nearby(self)
            if site:
                east.perform(self,site)
            else:
                self.tell("卓か掲示板のそばでE。出口は南。")
            return
        if self.interior in rift.AREAS:
            site=rift.nearest(self)
            if site:
                rift.interact(self,site)
            else:
                self.tell(rift.objective(self.chapter_flags))
            return
        if self.seal_waiting():
            self.seal_open=True
            self.buffered_powers.clear()
            return
        if self.interior in ROYAL:
            self.capital_interact()
            return
        if self.interior in CASTLE:
            if self.interior == "great_hall" and self.player.colliderect(CASTLE_DOOR.inflate(36, 40)):
                self.change_castle_area("throne")
            return
        if self.interior is None and self.room is None and len(self.seals) == 5:
            for x, y, kind in self.pickups:
                if kind == "final_gate" and math.dist(self.player.center, (x+10,y+10)) <= 68:
                    self.change_castle_area("forecourt")
                    return
        cx, cy = self.player.center
        if self.interior is not None:
            self.interact_interior()
            return
        if self.room is None:
            for npc in sorted(self.npcs_for_cell(self.world),key=lambda n:math.hypot(n["x"]-cx,n["y"]-cy)):
                if math.hypot(npc["x"] - cx, npc["y"] - cy) < 55:
                    if npc.get("role")=="mayor":
                        self.mayor_met=True
                        self.royal_travel("capital",(0,75))
                        self.tell("村長：ここが王都じゃ。大通りを北へ進んで、国王にお会いなされ。",7)
                        return
                    if npc.get("role") == "map_traveler":
                        if not self.map_obtained:
                            self.map_obtained = True
                            self.tell("旅人：この地図をあげよう。まだ空白だらけだから、自分の足で道を広げていくんだ。Pキーで開けるよ。", 6)
                        else:
                            self.tell(self.conversation("旅人","旅人：歩いた場所が地図に記録されるよ。","旅人：白紙のところに、次の誰かの帰り道ができるんだ。"),5)
                        return
                    if hearth.village(self,npc["name"]):
                        return
                    self.tell(self.conversation(npc["name"],npc["dialogue"],*VILLAGE_LINES.get(npc["name"],())), 5)
                    return
        if self.room is None and self.world == (7, 5):
            self.tell("ミラ：嵐で5つの地図の欠片が散らばったの。すべて集めて保管庫へ届けて。")
        else:
            self.tell("調べられるものはない。")

    def collect(self, item):
        x, y, kind = item
        if not (kind.startswith("entrance") or kind in ("final_gate", "stairs")):
            self.collected_items.add(self.pickup_key(item))
        if kind == "chest":
            self.rupees += 5
            if self.room[1:]==(1,0):
                self.revival_feathers+=1
                reward="不死鳥の羽1枚"
            elif self.room[1] == 3:
                self.bombs += 2
                reward = "爆弾2個"
            else:
                self.potions += 1
                reward = "薬1個"
            self.tell(f"宝箱を開けた！エメラルド5個と{reward}を手に入れた。")
            self.burst_effect("treasure", x+10, y+10, GOLD, 15)
        elif kind == "rupee":
            self.rupees += 1
            self.tell("エメラルドを手に入れた！")
        elif kind == "heart":
            self.hp = min(self.max_hp, self.hp + 2)
            self.tell("体力が回復した。")
        elif kind == "bomb":
            self.bombs += 1
            self.tell("爆弾を1個手に入れた。")
        elif kind == "key":
            self.keys += 1
            self.tell("小さな鍵を手に入れた。")
        elif kind in ("sword", "spear", "shield"):
            self.owned_gear.add(kind)
            names = {"sword": "鉄の剣", "spear": "旅人の槍", "shield": "木の盾"}
            if kind == "shield":
                self.shield_equipped = True
                self.tell("木の盾を手に入れた！,キーで盾を切り替えられる。武器はそのまま持てる。", 4)
            else:
                self.weapon = kind
                self.tell(f"{names[kind]}を手に入れた！Rキーで剣、Tキーで槍に切り替え。", 4)
        elif kind.startswith("entrance"):
            self.enter_dungeon(int(kind[-1]))
            return
        elif kind.startswith("seal"):
            d = int(kind[-1])
            self.seals.add(d)
            self.tell(f"地図の欠片 {d + 1}/5 を取り戻した！", 4)
            if len(self.seals) == 5:
                self.tell("5つの地図の欠片がそろった！中央の町の北にある地図保管庫へ向かおう。", 5)
        elif kind == "stairs":
            dungeon = self.room[0]
            self.door_lock = ("entrance", dungeon)
            self.room = None
            if self.overworld_return is not None:
                self.world, self.player = self.overworld_return
            else:
                self.world = DUNGEON_ENTRANCES[dungeon]
                self.set_spawn("center")
                self.player.move_ip(*self.chunk_offset(self.world))
            self.load_room()
            return
        self.pickups.remove(item)

    def burst_effect(self, kind, x, y, color, count=6):
        particles = []
        if not self.rich_effects:
            count = max(1, count // 2)
        for _ in range(count):
            angle = random.random() * math.tau
            speed = random.uniform(35, 105) if kind == "death" else random.uniform(50, 125)
            particles.append([float(x), float(y), math.cos(angle) * speed,
                              math.sin(angle) * speed, random.randint(2, 4)])
        self.effects.append({"kind": kind, "x": float(x), "y": float(y), "age": 0.0,
                             "life": .65 if kind in ("explosion", "death", "heal", "blink") else .32,
                             "color": color, "particles": particles})

    def awakened_weakness(self, enemy, power):
        if not power or enemy.boss_id!=5 or not (self.interior or "").startswith("keep"):
            return False
        index=int(self.interior[-1])-1
        return self.quest_steps[index]==3 and COMMISSIONS[index][0]==power

    def damage_enemy(self, enemy, amount, dx, dy, power=None):
        if enemy.hp<=0:
            return
        previous_phase = demon_phase(enemy) if enemy.boss_id == 5 else 0
        if self.awakened_weakness(enemy,power):
            amount += 5 if enemy.exposed>0 else 2
            enemy.weakness_flash=.65
            self.burst_effect("hit",enemy.x+12,enemy.y+8,LANDMARK_COLORS[int(self.interior[-1])-1],10)
        damage=amount+int(enemy.exposed>0)
        enemy.hp -= damage
        enemy.hurt = .28
        pushed = pygame.Rect(round(enemy.x + dx * 10), round(enemy.y + dy * 10), 25, 25)
        if previous_phase and enemy.hp > 0 and demon_phase(enemy) != previous_phase:
            self.hostile_attacks.clear()
            audio.play("omen")
            enemy.special_timer = 1.1
            self.burst_effect("death", enemy.x+12, enemy.y+12, (215, 111, 255), 24)
            self.tell("魔王の影が裂けた……第二形態！" if demon_phase(enemy)==2 else "王冠が燃え上がる！　最終形態！")
        if not previous_phase and not self.enemy_blocked(pushed):
            enemy.x, enemy.y = pushed.x, pushed.y
        color = {"slime": (164, 225, 142), "bat": (255, 128, 118),
                 "stalfos": (225, 218, 195), "boss": enemy.color}.get(enemy.kind, GOLD)
        self.burst_effect("hit", enemy.x + 12, enemy.y + 12, GOLD, 5)
        if enemy.hp <= 0:
            if enemy.kind=="boss":
                self.retry_data=None
            self.burst_effect("death", enemy.x + 12, enemy.y + 12, color, 10)
            drop_count = 5 if enemy.kind == "boss" else random.randint(1, 2)
            if self.room is None and self.interior is None:
                cell = (min(14, max(0, int(enemy.x // WIDTH))),
                        min(9, max(0, int(enemy.y // PLAY_H))))
                location = ("over", *cell)
            else:
                location = self.location_key()
            saved_drops = self.enemy_drops.setdefault(location, [])
            for index in range(drop_count):
                drop = [round(enemy.x + 8 + (index % 3) * 10),
                        round(enemy.y + 8 + (index // 3) * 10), "rupee"]
                drop[0], drop[1] = self.clear_floor(drop[0], drop[1])
                if self.interior not in CASTLE and self.interior not in ROYAL and self.interior not in rift.AREAS:
                    saved_drops.append(drop)
                self.pickups.append(drop.copy())
            if self.interior in tide.NAMES and enemy.kind=="boss":
                self.hostile_attacks.clear();tide.boss_down(self)
            elif self.interior in wastes.NAMES and enemy.kind=="boss":
                self.hostile_attacks.clear()
                if self.interior==wastes.THRONE:
                    self.chapter_flags.add("ash_victory")
                    self.tell("大魔王ヴァルドを倒した！　王冠が砕け、七隻の舟に朝日が差した。ナギのもとへ。",10)
                else:
                    region=wastes.CELLS[self.interior][0]
                    self.chapter_flags.add(wastes.flag(region,"win"))
                    self.revival_feathers+=1
                    self.tell(wastes.REGIONS[region][11]+"　水門から次の道へ。",8)
                self.last_clue=wastes.goal(self.chapter_flags)
            elif enemy.captain>=0:
                realm=self.arena_index()
                self.captains_down[realm]=max(self.captains_down[realm],enemy.captain+1)
                self.hostile_attacks.clear()
                self.hp=min(self.max_hp,self.hp+1)
                self.tell(CAPTAINS[realm][enemy.captain]+"を倒した！　ハートが一つ戻った。")
            elif enemy.kind == "boss" and enemy.boss_id == 5:
                self.final_boss_defeated = True
                lord=int(self.interior[-1]) if self.interior in ROYAL and self.interior.startswith("keep") else 0
                self.lords.add(lord)
                if lord:
                    self.quest_steps[lord-1]=3
                if lord==1:
                    audio.play("bell")
                self.game_won=len(self.lords)==6
                self.ending_open=self.game_won
                self.hostile_attacks.clear()
                self.tell("街を解放した！南の出口から馬車へ。" if lord else "奈落の魔王を倒した！南の帰還口できさらぎ町へ。",7)
            elif enemy.kind == "boss" and 0 <= enemy.boss_id < 5:
                self.cleared_rooms.add(self.location_key())
                self.grant_boss_power(enemy.boss_id)

    def revive_at_inn(self):
        if self.interior in tide.NAMES:
            self.game_over=False
            self.hp=self.max_hp
            self.rupees//=2
            tide.travel(self,tide.PORT)
            self.tell("港の火で目覚めた。所持エメラルドが半分になった。")
            self.save_game(silent=True)
            return
        self.retry_data=None
        self.remember_castle()
        self.world, self.room = (7, 5), None
        outside = self.player.copy()
        outside.midtop = self.building_door_rect(0).midtop
        self.interior_return = (self.world, outside, "inn", 0)
        self.interior, self.overworld_return, self.door_lock = "inn", None, None
        self.player.center = (WIDTH // 2, HEIGHT - 110)
        self.game_over, self.hp = False, self.max_hp
        self.flame_timer = self.jump_timer = self.attack_timer = 0
        self.effects.clear()
        self.bomb_list.clear()
        self.shield_cooldown = 0.0
        self.invulnerable = 1.5
        self.load_room()
        self.tell("宿で目を覚ました。体力が全回復した。")
        self.save_game(silent=True)

    def can_block(self, source):
        if not self.shield_equipped or self.shield_cooldown > 0 or source is None:
            return False
        dx, dy = source[0] - self.player.centerx, source[1] - self.player.centery
        fx, fy = self.direction
        length = math.hypot(dx, dy) * math.hypot(fx, fy)
        return length > 0 and dx*fx + dy*fy >= length * .5

    def perfect_guard(self, attacker, now):
        self.last_guard=-100.0
        self.recent_hit=None
        self.guard_ready=now
        if attacker.hp>0:
            attacker.stun=max(attacker.stun,1.25 if attacker.kind=="boss" else 1.8)
            attacker.hop_left=0
        audio.play("parry")
        self.burst_effect("parry",*self.player.center,(255,223,112),24)
        self.tell("ジャストガード！　今だ、反撃！",1.2)

    def guard_press(self):
        now=monotonic()
        if not self.shield_equipped:
            self.tell("コンマで盾を装備してから P でガード。")
            return
        if now<self.guard_ready:
            self.input_review.record("ガード再使用待ちの入力")
            return
        self.input_review.press()
        hit=self.recent_hit
        if hit and 0<=now-hit[0]<=.250000001:
            _,attacker,hp_delta,feather_delta,old_invuln,hit_invuln,old_shield,hit_shield=hit
            # Undo only timers granted by this hit, retaining elapsed game time.
            if self.invulnerable<=hit_invuln:
                self.invulnerable=max(0,old_invuln-(hit_invuln-self.invulnerable))
            if self.shield_cooldown<=hit_shield:
                self.shield_cooldown=max(0,old_shield-(hit_shield-self.shield_cooldown))
            self.hp=min(self.max_hp,self.hp+hp_delta)
            self.revival_feathers+=feather_delta
            self.game_over=False
            self.input_review.success(now-hit[0])
            self.perfect_guard(attacker,now)
        elif not self.game_over:
            self.last_guard=now
            self.guard_ready=now+.25+.55
            self.burst_effect("guard",*self.player.center,(170,221,240),5)

    def hurt_player(self, message, source=None, damage=1, tidal_impact=False, attacker=None):
        now=monotonic()
        if attacker is not None and self.shield_equipped and 0<=now-self.last_guard<=.250000001:
            self.input_review.record(f"攻撃接触  {attacker.kind}  {message}")
            self.input_review.success(self.last_guard-now)
            self.perfect_guard(attacker,now)
            return
        if self.interior in tide.NAMES:damage+=1
        if not tidal_impact and (self.invulnerable > 0 or self.jump_timer > 0):
            return
        self.input_review.record(f"攻撃接触  {attacker.kind if attacker else chr(8212)}  {message}")
        before_hp,before_feathers=self.hp,self.revival_feathers
        old_invuln,old_shield=self.invulnerable,self.shield_cooldown
        audio.play("attack")
        if self.can_block(source):
            self.shield_cooldown = 2.0
            audio.play("shield")
            self.burst_effect("guard", *self.player.center, (155, 215, 255), 10)
            self.invulnerable = .18
            self.tell("盾が攻撃を防いだ！")
        else:
            self.burst_effect("hit", *self.player.center, (255, 111, 99), 9)
            audio.play("hurt")
            self.hp = max(0,self.hp-damage)
            self.invulnerable = .85
            self.tell(message if damage==1 else f"{message}（♥−{damage}）")
            if self.hp==0 and self.revival_feathers:
                self.revival_feathers-=1
                self.hp=(self.max_hp+1)//2
                self.invulnerable=2.5
                self.burst_effect("heal",*self.player.center,(255,192,82),24)
                self.tell(f"不死鳥の羽が燃え上がった！ その場で復活。残り{self.revival_feathers}枚。",3)
            elif self.hp <= 0:
                self.game_over = True

        self.recent_hit=(now,attacker,before_hp-self.hp,before_feathers-self.revival_feathers,old_invuln,self.invulnerable,old_shield,self.shield_cooldown) if attacker is not None and self.shield_equipped else None

    def add_boss_hazard(self, kind, x, y, delay, radius=24, life=.48, force=0):
        self.hostile_attacks.append({"kind": kind, "x": float(x), "y": float(y),
                                     "delay": delay, "windup":delay,"radius": radius, "life": life,
                                     "force": force, "hit": False})

    def realm_signature(self, enemy, index):
        px,py=self.player.center
        bx,by=enemy.x+12,enemy.y+12
        begin=len(self.hostile_attacks)
        if index==1:
            self.tell("潮呼びの双鐘！　二つ目の鐘で渦の芯が弾ける。")
            self.add_boss_hazard("pull",bx,by,.55,265,1,110)
            self.add_boss_hazard("meteor",bx,by,1.65,65,.4)
        elif index==2:
            self.tell("熔炉の鋳型！　赤い列が両側から閉じてくる。")
            for step in range(3):
                for side in ((-1,1) if step<2 else (0,)):
                    self.add_boss_hazard("down",px+side*(2-step)*74,py,.65+step*.42,18,.38)
        elif index==3:
            self.tell("荊の花環！　東の切れ目から抜けよう。")
            for j in range(1,12):
                angle=math.tau*j/12
                self.add_boss_hazard("root_burst",px+86*math.cos(angle),py+86*math.sin(angle),.8,19,.75)
            self.add_boss_hazard("quake",px,py,1.55,52,.45)
        elif index==4:
            self.tell("三鐘の裁き！　一鐘、二鐘、三鐘の順に落雷。")
            for j,offset in enumerate((-68,68,0)):
                self.add_boss_hazard("down",px+offset,py,.7+.48*j,17,.34)
        else:
            self.tell("月蝕の星列！　影を横切って列の外へ。")
            for j in range(5):
                self.add_boss_hazard("meteor",px,py+(j-2)*48,.6+j*.24,29,.46)
        if index in (1,4):
            for j,hazard in enumerate(self.hostile_attacks[begin:],1):
                hazard["bell"]=j
        if demon_phase(enemy)==3:
            # The echo is aimed at the position at cast time so a moving player can dodge.
            delay=max(h["delay"]+h["life"] for h in self.hostile_attacks[begin:])+.55
            echo=("meteor","fire_pillar","root_burst","down","quake")[index-1]
            self.add_boss_hazard(echo,px,py,delay,19 if echo=="down" else 38,.40)
            self.tell("最後に残響が返る！　最初に立っていた場所を空けよう。")
            enemy.special_timer=delay+.6
        self.hostile_attacks[-1]["open_crown"]=True

    def aimed_fan(self, bx, by, px, py, delay):
        aim=math.atan2(py-by,px-bx)
        for offset in (-.44,0,.44):
            self.add_boss_hazard("orb",bx,by,delay,10,2.4)
            self.hostile_attacks[-1].update(vx=195*math.cos(aim+offset),vy=195*math.sin(aim+offset))

    def captain_attack(self,enemy):
        realm=self.arena_index()
        px,py=self.player.center
        bx,by=enemy.x+12,enemy.y+12
        slot=enemy.captain
        axis="down" if (enemy.special_count+realm)%2 else "across"
        delay=.95
        if slot in (0,3):
            self.add_boss_hazard(axis,px,py,delay,14,.44)
        if slot in (1,3):
            self.aimed_fan(bx,by,px,py,delay)
        if slot==2:
            self.add_boss_hazard("pull",bx,by,delay,185,.72,80)
        for offset in (-54,0,54):
            x,y=(px+offset,py) if axis=="across" else (px,py+offset)
            self.add_boss_hazard(ELEMENTS[realm],x,y,delay,22,.48,95)
        enemy.special_count+=1
        enemy.special_timer=3.15-slot*.13

    def start_boss_attack(self, enemy):
        boss_id = enemy.boss_id
        px, py = self.player.center
        bx, by = enemy.x + 12, enemy.y + 12
        if enemy.captain>=0:
            self.captain_attack(enemy)
            return
        if self.interior in tide.CELLS:
            first=len(self.hostile_attacks)
            tide.attack(self,enemy)
            for hazard in self.hostile_attacks[first:]:hazard["attacker"]=enemy
            return
        first_hazard=len(self.hostile_attacks)
        if boss_id == 0:
            self.tell("樹根の巨獣が地面に根を走らせる！赤い地面から離れろ。")
            for index, offset in enumerate((-48, 0, 48)):
                self.add_boss_hazard("root_burst", px + offset, py + 20, .75 + index * .13, 27)
        elif boss_id == 1:
            self.tell("熔炉の巨兵が火柱を呼ぶ！光る地面から逃げろ。")
            for index, (ox, oy) in enumerate(((0, 0), (0, -55), (55, 0), (0, 55), (-55, 0))):
                self.add_boss_hazard("fire_pillar", px + ox, py + oy, .62 + index * .12, 25)
        elif boss_id == 2:
            self.tell("深潮の主が潮の渦で引き寄せる！")
            self.add_boss_hazard("pull", bx, by, .25, 250, 1.4, 105)
        elif boss_id == 3:
            self.tell("星喰いの翼竜が風の刃を放つ！")
            vx, vy = px - bx, py - by
            length = max(1, math.hypot(vx, vy))
            for index, fraction in enumerate((.35, .62, .9)):
                self.add_boss_hazard("wind_blast", bx + vx * fraction, by + vy * fraction,
                                     .42 + index * .18, 27, .45, 125)
        elif boss_id == 4:
            self.tell("嵐鐘の守護者が地面を揺らす！")
            for ring, radius in enumerate((72, 128)):
                for index in range(8):
                    angle = math.tau * index / 8
                    self.add_boss_hazard("quake", bx + math.cos(angle) * radius,
                                         by + math.sin(angle) * radius, .55 + ring * .22,
                                         25, .5)
        else:
            phase = demon_phase(enemy)
            rotations = ((3, 0, 1, 2), (4, 3, 1, 0, 2), (5, 3, 0, 4, 2, 1))
            rotation = rotations[phase-1]
            pattern = rotation[enemy.special_count % len(rotation)]
            if self.interior==wastes.THRONE and enemy.special_count%3==0:
                self.tell("灰冠の潮！　刻印の間を抜け、最後の鐘で横へ。")
                for i in range(7):
                    self.add_boss_hazard("meteor",90+i*100,py+(-1)**i*45,.8+i*.09,34,.48)
                self.add_boss_hazard("down",px,py,1.85,16,.42)
                if phase>=2:self.aimed_fan(bx,by,px,py,1.35)
                if phase==3:self.add_boss_hazard("pull",bx,by,.4,245,.8,70)
            elif self.interior in ROYAL and enemy.special_count%3==0:
                self.realm_signature(enemy,int(self.interior[-1]))
            elif pattern == 3:
                self.tell("断界の鎖！　光る十字線から斜めに離れよう。")
                for axis in ("across", "down"):
                    self.add_boss_hazard(axis, px, py, .95, 15, .38)
            elif pattern == 4:
                self.tell("落星！　紫の印から離れよう。")
                for i, (ox, oy) in enumerate(((0,0), (-85,0), (85,0), (0,-85), (0,85))):
                    self.add_boss_hazard("meteor", px+ox, py+oy, .8+i*.14, 35, .4)
            elif pattern == 5:
                self.tell("黒炎の弾幕！　弾と弾の間を抜けよう。")
                aim = math.atan2(py-by, px-bx)
                for i in range(-3, 4):
                    angle = aim + i*.31
                    self.add_boss_hazard("orb", bx, by, .85, 12, 2.4)
                    self.hostile_attacks[-1].update(vx=245*math.cos(angle), vy=245*math.sin(angle))
            elif pattern == 0:
                self.tell("魔王が重力の渦を放つ！引き寄せられるぞ！")
                self.add_boss_hazard("pull", bx, by, .3, 285, 1.55, 145)
            elif pattern == 1:
                self.tell("魔王が火柱を広げる！赤い印から逃げろ！")
                self.add_boss_hazard("fire_pillar", px, py, .65, 28)
                for ring, radius in enumerate((68, 132)):
                    for index in range(8):
                        angle = math.tau * index / 8
                        self.add_boss_hazard("fire_pillar", px + math.cos(angle) * radius,
                                             py + math.sin(angle) * radius,
                                             .8 + ring * .22 + (index % 2) * .08, 25)
            else:
                self.tell("魔王が炎の輪を放った！輪の外へ走れ！")
                for ring, radius in enumerate((80, 150)):
                    for index in range(12):
                        angle = math.tau * index / 12
                        self.add_boss_hazard("fire_pillar", bx + math.cos(angle) * radius,
                                             by + math.sin(angle) * radius,
                                             .58 + ring * .24 + (index % 3) * .06, 24)
        if boss_id==5 and phase>=2 and enemy.special_count%2==0:
            # Lock the overlapping casts to the same aim point before warnings appear.
            self.add_boss_hazard("down",px,py,1.05,13,.40)
            self.aimed_fan(bx,by,px,py,1.05)
            if phase==3:
                self.add_boss_hazard("meteor",px,py,1.05,32,.44)
        elif 0<=boss_id<5 and enemy.hp*2<=enemy.max_hp:
            self.aimed_fan(bx,by,px,py,.8)
        if boss_id==5:
            for hazard in self.hostile_attacks[first_hazard:]:
                hazard["damage"]={"meteor":3,"fire_pillar":2,"down":2,"across":2,
                                  "root_burst":2,"quake":2}.get(hazard["kind"],1)
        enemy.special_count += 1
        interval = (3.3, 2.95, 2.65)[phase-1] if boss_id == 5 else 3.0 + boss_id * .16
        enemy.special_timer=max(interval,enemy.special_timer)

    def update_boss_hazards(self, dt):
        active = []
        px, py = self.player.center
        for hazard in self.hostile_attacks:
            if hazard["kind"]=="melee" and (hazard["attacker"].hp<=0 or hazard["attacker"].stun>0):
                continue
            if hazard["kind"]=="tidal_disk" and hazard["delay"]>tide.LOCK_TIME:
                hazard["x"],hazard["y"]=px,py
                if hazard["delay"]-dt<=tide.LOCK_TIME:
                    audio.play("bell")
                    self.tell("中心固定！　外へ縮地 I → 槍 J",1)
            hazard["delay"] = max(0.0, hazard["delay"] - dt)
            if hazard["delay"] > 0:
                active.append(hazard)
                continue
            if hazard.get("bell") and not hazard.get("rang"):
                audio.play("bell")
                hazard["rang"]=True
            hazard["release_age"]=hazard.get("release_age",0)+dt
            hazard["life"] -= dt
            if hazard["kind"] == "orb":
                hazard["x"] += hazard["vx"]*dt
                hazard["y"] += hazard["vy"]*dt
            dx, dy = hazard["x"] - px, hazard["y"] - py
            distance = math.hypot(dx, dy)
            if hazard["kind"] == "pull" and distance < hazard["radius"] and distance > 40:
                step = min(distance - 36, hazard["force"] * dt)
                if step > 0:
                    ux, uy = dx / distance, dy / distance
                    moved = self.player.copy()
                    moved.x += round(ux * step)
                    if not self.blocked(moved):
                        self.player.x = moved.x
                    moved = self.player.copy()
                    moved.y += round(uy * step)
                    if not self.blocked(moved):
                        self.player.y = moved.y
                    px, py = self.player.center
                    dx, dy = hazard["x"] - px, hazard["y"] - py
                    distance = math.hypot(dx, dy)
            rival=hazard.get("rival")
            if rival is not None:
                if not hazard["hit"] and rival.hp>0 and math.dist((rival.x+12,rival.y+12),(hazard["x"],hazard["y"]))<=hazard["radius"]:
                    hazard["hit"]=True
                    self.damage_enemy(rival,1,0,0)
                if hazard["life"]>0:active.append(hazard)
                continue
            hit_radius = 36 if hazard["kind"] == "pull" else hazard["radius"]
            if hazard["kind"] == "across":
                distance = abs(dy)
            elif hazard["kind"] == "down":
                distance = abs(dx)
            if self.companion:
                self.companion.hazard(self,hazard,hit_radius)
            if not hazard["hit"] and distance <= hit_radius:
                hazard["hit"] = True
                if hazard["kind"] == "wind_blast":
                    length = max(1, distance)
                    moved = self.player.copy()
                    moved.x -= round(dx / length * hazard["force"] * dt * 4)
                    if not self.blocked(moved):
                        self.player.x = moved.x
                    moved = self.player.copy()
                    moved.y -= round(dy / length * hazard["force"] * dt * 4)
                    if not self.blocked(moved):
                        self.player.y = moved.y
                if hazard["kind"]=="tidal_disk":
                    self.hurt_player("大潮に呑まれた！",damage=2,tidal_impact=True,attacker=hazard.get("attacker"))
                else:
                    self.hurt_player("敵の攻撃を受けた！",source=(hazard["attacker"].x+12,hazard["attacker"].y+12) if hazard["kind"]=="melee" else None,damage=hazard.get("damage",1),attacker=hazard.get("attacker"))
            if hazard["life"] > 0:
                active.append(hazard)
            elif hazard.get("open_crown"):
                for boss in self.enemies:
                    if boss.kind=="boss" and boss.hp>0:
                        boss.exposed=1.4
                        boss.special_timer=max(2,boss.special_timer)
                        self.tell("王冠が消えた！　今が反撃の隙！",1.4)
        self.hostile_attacks = active

    def grant_boss_power(self, boss_id):
        boss = BOSSES[boss_id]
        power = boss["power"]
        if power is None or power in self.abilities:
            return
        self.abilities.add(power)
        self.tell(f"{boss['name']}を撃破！「{POWER_NAMES[power]}の力」を手に入れた！", 5)

    def request_power(self, power):
        remaining = self.power_cooldowns[power]
        if power in self.abilities and 0 < remaining <= .22:
            self.buffered_powers[power] = self.location_key()
        else:
            self.buffered_powers.pop(power, None)
            self.cast_power(power)

    def resolve_power_inputs(self):
        for power, location in tuple(self.buffered_powers.items()):
            if location != self.location_key():
                del self.buffered_powers[power]
            elif self.power_cooldowns[power] <= 0:
                del self.buffered_powers[power]
                self.cast_power(power)
                if self.ending_open or self.game_over:
                    self.buffered_powers.clear()
                    break

    def cast_power(self, power):
        if power not in self.abilities:
            self.tell(f"まだ「{POWER_NAMES[power]}の力」を持っていない。")
            return
        if self.power_cooldowns[power] > 0:
            self.tell(f"{POWER_NAMES[power]}の力はあと{self.power_cooldowns[power]:.1f}秒で使える。")
            return
        cx, cy = self.player.center
        dx, dy = self.direction
        magnitude = max(1, math.hypot(dx, dy))
        ux, uy = dx / magnitude, dy / magnitude

        if tide.use_power(self,power):
            self.power_cooldowns[power]=POWER_COOLDOWNS[power]
            return
        enhanced="master_"+power in self.chapter_flags or any(q[0]==power and self.quest_steps[i]==3 for i,q in enumerate(COMMISSIONS))
        if wastes.power(self,power) or self.use_quest_power(power):
            self.power_cooldowns[power]=POWER_COOLDOWNS[power]
            return
        if power == "heal":
            roots=[e for e in self.enemies if e.hp>0 and self.awakened_weakness(e,power)
                   and math.dist((cx,cy),(e.x+12,e.y+12))<=150]
            if self.hp >= self.max_hp and not roots:
                self.tell("体力はすでに満タンだ。")
                return
            self.hp = min(self.max_hp, self.hp + (5 if enhanced else 3))
            self.burst_effect("heal", cx, cy, (117, 235, 150), 12)
            self.tell("回復の光が荊の根に届いた！" if roots else "回復の力！体力を回復した。")
            for enemy in roots:
                self.damage_enemy(enemy,3,0,0,power)
        elif power == "lightning":
            targets = [enemy for enemy in self.enemies if enemy.hp > 0 and
                       math.hypot(enemy.x + 12 - cx, enemy.y + 12 - cy) <= (290 if enhanced else 220)]
            if not targets:
                self.tell("雷を落とせる魔物が近くにいない。")
                return
            boss_defeated = False
            for enemy in targets:
                ex, ey = enemy.x + 12, enemy.y + 12
                vx, vy = ex - cx, ey - cy
                length = max(1, math.hypot(vx, vy))
                enemy.stun=.65 if enemy.kind=="boss" else 1.8
                self.damage_enemy(enemy, 4 if enhanced else 3, vx / length, vy / length,power)
                boss_defeated = boss_defeated or (enemy.kind == "boss" and enemy.hp <= 0)
                self.effects.append({"kind": "lightning", "x": ex, "y": ey, "age": 0.0,
                                     "life": .34, "color": (157, 225, 255), "particles": []})
            self.enemies = [enemy for enemy in self.enemies if enemy.hp > 0]
            if self.room is not None and not self.enemies:
                self.cleared_rooms.add(self.location_key())
                self.room_specials()
            if not boss_defeated:
                self.tell("雷の力！近くの魔物に雷が落ちた。")
        elif power == "flame":
            self.flame_timer = 12.0 if enhanced else 8.0
            self.tell("焔の力！武器に炎をまとわせた。")
        elif power == "wind":
            wind_radius=250 if enhanced else 190
            affected = 0
            for enemy in self.enemies:
                vx, vy = enemy.x + 12 - cx, enemy.y + 12 - cy
                distance = math.hypot(vx, vy)
                if enemy.hp>0 and distance <= wind_radius:
                    distance=max(distance,.001)
                    ux2, uy2 = vx / distance, vy / distance
                    push = max(85, 145 - distance * .25)
                    moved = pygame.Rect(round(enemy.x + ux2 * push),
                                        round(enemy.y + uy2 * push), 25, 25)
                    if not self.enemy_blocked(moved):
                        enemy.x, enemy.y = moved.x, moved.y
                    enemy.stun=max(enemy.stun,.5 if enemy.kind=="boss" else (2.2 if enhanced else 1.4))
                    enemy.hurt = .3
                    if self.awakened_weakness(enemy,power):
                        self.damage_enemy(enemy,3,0,0,power)
                    affected += 1
            self.effects.append({"kind": "wind", "radius":wind_radius, "x": cx, "y": cy, "age": 0.0,
                                 "life": .48, "color": (190, 238, 232), "particles": []})
            self.tell("嵐の力！近くの魔物を吹き飛ばした。" if affected else "嵐が周囲を吹き抜けた。")
        elif power == "earth":
            sx,sy=(dx,0) if dx else (0,dy or 1)
            rect=pygame.Rect(0,0,16 if sx else 52,52 if sx else 16)
            rect.center=(cx+sx*26,cy+sy*26)
            hits=set()
            jam=False
            last=None
            for step in range(0,97 if enhanced else 65,4):
                face=rect.move(sx*step,sy*step)
                if self.blocked(face) or any(face.colliderect(pygame.Rect(x,y,20,20)) for x,y,_ in self.pickups):
                    break
                jam=False
                for enemy in self.enemies:
                    body=pygame.Rect(enemy.x,enemy.y,25,25)
                    if enemy.hp<=0 or not face.colliderect(body):
                        continue
                    pushed=body.copy()
                    if sx>0: pushed.left=face.right
                    elif sx<0: pushed.right=face.left
                    elif sy>0: pushed.top=face.bottom
                    else: pushed.bottom=face.top
                    if self.enemy_blocked(pushed):
                        self.damage_enemy(enemy,5 if enhanced else 3,0,0,power)
                        jam=enemy.hp>0 or jam
                    else:
                        enemy.x,enemy.y=pushed.topleft
                        if id(enemy) not in hits:
                            self.damage_enemy(enemy,2,0,0,power)
                            hits.add(id(enemy))
                if jam:
                    break
                last=face
            if last is None and not hits and not jam:
                self.tell("土壁を起こす空間がない。")
                return
            if last is not None:
                self.magic_walls.append({"rect":last,"timer":7.0,"location":self.location_key()})
            self.burst_effect("earth",*(last or rect).center,(203,159,93),14)
            self.tell("せり出す土壁が魔物を押しつぶす！")

        self.enemies=[e for e in self.enemies if e.hp>0]
        self.power_cooldowns[power] = POWER_COOLDOWNS[power]

    def attack(self):
        if self.attack_timer > .06:
            return
        self.attack_timer = .32
        self.attack_weapon = self.weapon
        self.spear_chain = self.weapon=="spear" and self.blink_followup>0
        self.blink_followup=0
        self.attack_direction = self.direction
        flaming = self.flame_timer > 0
        if flaming and self.weapon=="sword":
            self.use_quest_power("flame",strike=True)
        self.attack_hits.clear()
        self.attack_flaming=flaming and self.weapon!="none"
        self.rush_steps=0
        self.last_ember_frame=-1
        if self.weapon=="bow":
            self.attack_timer=.56
            bow.loose(self)
            return
        self.advance_strike()

    def strike_layer(self):
        # Collision and display share the identical painted frame and origin.
        key=(self.attack_timer,self.attack_weapon,self.attack_direction,self.weapon_level,
             self.attack_flaming,self.running,self.direction,self.walk_time)
        if self.strike_cache is None or self.strike_cache[0]!=key:
            canvas=pygame.Surface((256,256),pygame.SRCALPHA)
            anchor=128
            if self.attack_weapon=="none":
                dx,dy=self.attack_direction
                length=max(1,math.hypot(dx,dy))
                center=(anchor+round(25*dx/length),anchor+round(25*dy/length))
                pygame.draw.circle(canvas,(250,199,115),center,8)
                pygame.draw.circle(canvas,WHITE,center,8,2)
            else:
                self.paint_weapon("down",pygame.Rect(116,115,24,26),canvas)
            bounds=canvas.get_bounding_rect()
            image=canvas.subsurface(bounds).copy()
            self.strike_cache=(key,image,pygame.mask.from_surface(image),bounds.move(-anchor,-anchor))
        return self.strike_cache[1:]

    def advance_strike(self):
        if self.attack_weapon=="bow":return
        dx,dy=self.attack_direction
        length=max(1,math.hypot(dx,dy))
        ux,uy=dx/length,dy/length
        if self.attack_weapon=="spear":
            limit=43 if self.spear_chain else 12 if self.attack_flaming else 8
            target=min(limit,1+int((.32-self.attack_timer)*limit/.14))
            while self.rush_steps<target:
                self.rush_steps+=1
                step=self.player.move(round(5*ux),round(5*uy))
                if self.blocked(step):
                    self.rush_steps=limit
                    break
                self.player.topleft=step.topleft
                self.move_player(0,0,0)
                if self.attack_timer<=0:
                    return
        image,mask,offset=self.strike_layer()
        lift=round(math.sin((1-self.jump_timer/.48)*math.pi)*23) if self.jump_timer>0 else 0
        area=offset.move(self.player.centerx,self.player.centery-lift)
        weapon=self.attack_weapon
        bonus=int(self.weapon_level>=2)+int(self.weapon_level>=5) if weapon=="sword" else self.weapon_level if weapon=="spear" else 0
        for enemy in self.enemies:
            if enemy.hp<=0 or id(enemy) in self.attack_hits:
                continue
            sprite,rect=self.enemy_pose(enemy)
            if area.colliderect(rect) and mask.overlap(sprite_mask(sprite),(rect.x-area.x,rect.y-area.y)) is not None:
                self.attack_hits.add(id(enemy))
                if self.attack_flaming and weapon=="sword":
                    if not enemy.burn_ticks: enemy.burn_delay=1
                    enemy.burn_ticks=5 if self.quest_steps[1]==3 else 3
                self.damage_enemy(enemy,1+int(self.attack_flaming)+bonus,ux,uy,"flame" if self.attack_flaming else None)
        frame=int((.32-self.attack_timer)*24)
        if self.attack_flaming and frame!=self.last_ember_frame:
            self.last_ember_frame=frame
            points=mask.outline(3)
            if points:
                tip=max(points,key=lambda pt:(pt[0]+area.x-self.player.centerx)**2+(pt[1]+area.y-self.player.centery)**2)
                px,py=tip[0]+area.x,tip[1]+area.y
                self.effects.append(dict(kind="ember",x=px,y=py,age=0,life=.4,color=(255,143,57),
                                         particles=[[px,py,0,-30,2]]))
        self.enemies=[e for e in self.enemies if e.hp>0]
        if not self.enemies:
            self.cleared_rooms.add(self.location_key())
            if self.room is not None: self.room_specials()

    def use_elixir(self):
        if not self.elixirs:
            self.tell("王室の霊薬を持っていない。")
        elif self.hp >= self.max_hp:
            self.tell("体力は満タンだ。")
        else:
            self.elixirs -= 1
            self.hp = self.max_hp
            self.burst_effect("heal", *self.player.center, (158,232,201), 16)
            self.tell("王室の霊薬で全回復した。")

    def place_bomb(self, heavy=False):
        if heavy:
            if self.heavy_bombs:
                self.heavy_bombs -= 1
                self.bomb_list.append([*self.player.center, 1.1, "heavy"])
            else:
                self.tell("大爆弾を持っていない。")
            return
        if self.bombs <= 0:
            self.tell("爆弾がない。")
            return
        self.bombs -= 1
        self.bomb_list.append([self.player.centerx, self.player.centery, 1.1])

    def blocked(self, rect):
        if self.interior==tide.PORT and tide.harbor_water(rect):
            return True
        if self.interior=="capital":
            for index,ox,oy in districts_under(rect):
                _,solid=district_art(index)
                if solid.overlap(body_mask(rect.size),(rect.left-ox,rect.top-oy)) is not None:
                    return True
            if math.hypot(rect.centerx/WIDTH,rect.centery/PLAY_H)>100:
                return True
            if any(rect.colliderect(r) for k,r,_ in self.capital_features(moving=False) if k not in PASSABLE_PEOPLE):
                return True
        elif self.interior is not None:
            if self.interior == "forecourt" and 105 <= rect.centery <= 520:
                half_width = 53 + (rect.centery - 110)//4
                if abs(rect.centerx - 400) + rect.width//2 > half_width:
                    return True
            if rect.left < 20 or rect.right > WIDTH - 20 or rect.top < HUD_H + 15 or rect.bottom > HEIGHT - 15:
                return True
        elif self.room is None:
            if rect.left < 0 or rect.right > WORLD_W or rect.top < 0 or rect.bottom > WORLD_H:
                return True
        else:
            _, rx, ry = self.room
            if ((rect.left < 0 and rx == 0) or (rect.right > WIDTH and rx == 5)
                    or (rect.top < HUD_H and ry == 0) or (rect.bottom > HEIGHT and ry == 4)):
                return True
        if any(rect.colliderect(obstacle) for _, obstacle in self.obstacles):
            return True
        if any(wall["location"] == self.location_key() and rect.colliderect(wall["rect"])
               for wall in self.magic_walls):
            return True
        return False

    def move_player(self, dx, dy, dt, dashing=False):
        if (dx or dy) and self.interior=="capital" and self.blocked(self.player):
            self.recover_arrival()
        if dx and dy:
            dx *= .7071
            dy *= .7071
        if dx or dy:
            self.direction = (1 if dx > 0 else -1 if dx < 0 else 0,
                              1 if dy > 0 else -1 if dy < 0 else 0)
        speed = 310 if dashing else 190
        step_x, step_y = dx * speed * dt, dy * speed * dt
        if step_x and not self.blocked(self.player.move(round(step_x),0)):
            self.player.x += round(step_x)
        if step_y and not self.blocked(self.player.move(0,round(step_y))):
            self.player.y += round(step_y)
        if self.interior=="capital":
            self.record_road_anchor()
        if self.interior is not None:
            return
        if self.room is None:
            new_world = (min(14, max(0, self.player.centerx // WIDTH)),
                         min(9, max(0, self.player.centery // PLAY_H)))
            if new_world != self.world:
                self.world = new_world
                self.load_room()
            return
        if self.player.left < 0:
            self.transition("left")
        elif self.player.right > WIDTH:
            self.transition("right")
        elif self.player.top < HUD_H:
            self.transition("up")
        elif self.player.bottom > HEIGHT:
            self.transition("down")

    def shukuchi(self):
        if self.shukuchi_cooldown > 0:
            self.tell(f"縮地はあと{self.shukuchi_cooldown:.1f}秒で使える。")
            return
        dx, dy = self.direction
        if not dx and not dy:
            dy = 1
        length = max(1, math.hypot(dx, dy))
        ux, uy = dx / length, dy / length
        origin = self.player.copy()
        old_center = origin.center
        best = origin.copy()
        for step in range(5, 126, 5):
            candidate = origin.copy()
            candidate.x += round(ux * step)
            candidate.y += round(uy * step)
            if self.blocked(candidate):
                break
            best = candidate
        if best == origin:
            self.tell("前方がふさがっていて縮地できない。")
            return
        self.burst_effect("blink", *old_center, (155, 211, 255), 8)
        self.player.topleft = best.topleft
        self.move_player(0, 0, 0)
        self.burst_effect("blink", *self.player.center, (155, 211, 255), 8)
        self.blink_followup=.46
        self.shukuchi_cooldown = 1.35
        self.tell("縮地！")

    def dash(self):
        if self.dash_cooldown > 0:
            self.tell(f"ダッシュはあと{self.dash_cooldown:.1f}秒で使える。")
            return
        dx, dy = self.direction
        if not dx and not dy:
            dy = 1
        length = max(1, math.hypot(dx, dy))
        ux, uy = dx / length, dy / length
        moved = 0
        for _ in range(18):
            candidate = self.player.copy()
            candidate.x += round(ux * 5)
            candidate.y += round(uy * 5)
            if self.blocked(candidate):
                break
            self.player.topleft = candidate.topleft
            moved += 5
        if moved == 0:
            self.tell("前方がふさがっていてダッシュできない。")
            return
        self.dash_cooldown = .65
        self.burst_effect("dust", *self.player.center, (196, 205, 158), 7)
        self.move_player(0, 0, 0)
        self.handle_touch_interactions()

    def jump(self):
        if self.jump_cooldown > 0 or self.jump_timer > 0:
            return
        # A jump is a smooth vertical hop in place; WASD remains normal air movement.
        self.burst_effect("dust", *self.player.midbottom, (215, 194, 145), 7)
        self.jump_timer = .48
        self.jump_cooldown = .72

    @staticmethod
    def royal_cell(x,y):
        return ((x+WIDTH//2)//WIDTH,(y+PLAY_H//2)//PLAY_H)

    def record_road_anchor(self):
        point=self.player.center
        cell=self.royal_cell(*point)
        if cell not in CITY_INDEX and cell not in self.road_anchors and not self.blocked(self.player):
            self.road_anchors[cell]=point

    def open_royal_warp(self):
        self.record_road_anchor()
        current=self.royal_cell(*self.player.center)
        destinations=[((0,0),"環都アルカ・王城前広場",CROWN_PLAZA)]
        for index,(name,x,y,*_) in enumerate(REALMS,1):
            if self.royal_order or current==(x,y) or self.quest_steps[index-1] or index in self.lords:
                destinations.append(((x,y),name,(x*WIDTH,y*PLAY_H+80)))
        for cell,point in sorted(self.road_anchors.items(),key=lambda entry:
                                  (math.dist(current,entry[0]),entry[0])):
            label=east.WARDS.get(cell) or ("街道宿" if cell in ROADSIDE_INNS else "砦前" if cell in FORT_CELLS else
                   "峠道" if cell in TRAIL_CELLS else "王都の街区" if cell in CROWN_WARDS else
                   "湾岸" if cell in BAY_CELLS else "街道" if cell in ROYAL_ROADS else "郊外")
            destinations.append((cell,label,point))
        self.royal_destinations=destinations
        region,target,_=life.destination(self,REALMS)
        self.warp_index=next((i for i,(cell,_,_) in enumerate(destinations) if region=="royal" and cell==target),0)
        self.warp_open=True

    def open_warp(self):
        if self.interior in tide.NAMES:
            if self.interior==tide.PORT:self.tell("港からは北の舟を選ぼう。")
            elif any(e.hp>0 for e in self.enemies):self.tell("交戦中は帰港できない。南の退路を使おう。")
            else:tide.travel(self,tide.PORT)
            return
        if self.interior=="capital":
            self.open_royal_warp()
            return
        if self.room is not None or self.interior is not None:
            self.tell("ワープは地上でだけ使える。")
            return
        if not self.map_obtained:
            self.tell("ワープには旅人から受け取る探索地図が必要だ。")
            return
        places = [loc[1:] for loc in self.visited if len(loc) == 3 and loc[0] == "over"]
        if len(places) < 2:
            self.tell("まだワープできる訪問済みの場所がない。")
            return
        self.warp_cursor = self.world if self.world in places else sorted(places)[0]
        self.warp_open = True

    def move_warp_cursor(self, dx, dy):
        if self.interior=="capital":
            self.warp_index=max(0,min(len(self.royal_destinations)-1,self.warp_index+dy+8*dx))
            return
        places = [loc[1:] for loc in self.visited if len(loc) == 3 and loc[0] == "over"]
        candidates = []
        for x, y in places:
            vx, vy = x - self.warp_cursor[0], y - self.warp_cursor[1]
            if (dx and vx * dx > 0 and abs(vy) <= abs(vx)) or (dy and vy * dy > 0 and abs(vx) <= abs(vy)):
                candidates.append((vx * vx + vy * vy, (x, y)))
        if candidates:
            self.warp_cursor = min(candidates, key=lambda item: item[0])[1]

    def warp_to_cursor(self):
        if self.interior=="capital":
            _,name,point=self.royal_destinations[self.warp_index]
            self.royal_travel("capital",point)
            self.warp_open=False
            self.transition_cooldown=.3
            self.burst_effect("blink",*self.player.center,(155,211,255),12)
            self.tell(name+"へワープした。")
            return
        x, y = self.warp_cursor
        if ("over", x, y) not in self.visited:
            self.tell("未踏の場所にはワープできない。")
            return
        self.world = (x, y)
        ox, oy = self.chunk_offset(self.world)
        local_y = 100 if self.world == (7, 5) else PLAY_H // 2
        self.player.topleft = (ox + WIDTH // 2 - 12, oy + local_y - 13)
        self.load_room()
        self.warp_open = False
        self.transition_cooldown = .25
        self.burst_effect("blink", *self.player.center, (155, 211, 255), 12)
        self.tell(f"{self.room_name()}へワープした。")

    def merge_slimes(self):
        grounded=[e for e in self.enemies if e.kind=="slime" and e.hp>0 and not e.hop_left]
        for index,slime in enumerate(grounded):
            if slime.hp<=0:
                continue
            for other in grounded[index+1:]:
                count=slime.slime_count+other.slime_count
                if other.hp<=0 or count>4 or math.dist((slime.x,slime.y),(other.x,other.y))>38:
                    continue
                first=pygame.Rect(round(slime.x),round(slime.y),25,25)
                second=pygame.Rect(round(other.x),round(other.y),25,25)
                if self.enemy_blocked(first.union(second)):
                    continue
                slime.x=(slime.x*slime.slime_count+other.x*other.slime_count)/count
                slime.y=(slime.y*slime.slime_count+other.y*other.slime_count)/count
                slime.slime_count=count
                slime.hp+=other.hp
                slime.max_hp+=other.max_hp
                slime.burn_ticks=max(slime.burn_ticks,other.burn_ticks)
                slime.stun=max(slime.stun,other.stun)
                slime.move_cooldown=max(.55,slime.move_cooldown,other.move_cooldown)
                other.hp=0
                self.burst_effect("dust",slime.x+12,slime.y+20,(126,218,150),10)

    def update_slime(self, slime, dt, target):
        if slime.hop_left <= 0:
            if not target or slime.move_cooldown > 0:
                return
            tx, ty, rival = target
            dx, dy = tx - slime.x - 12, ty - slime.y - 12
            distance = math.hypot(dx, dy)
            attacking = distance <= (95 if self.interior in tide.CELLS else 65)+5*(slime.slime_count-1) and (rival is None or rival.kind!="slime")
            travel = min(distance, (86 if self.interior in tide.CELLS else 58) if attacking else slime.speed * .8)
            if rival is not None and rival.kind=="slime":
                travel=min(travel,distance/2)
            speed = travel / (max(1, distance) * SLIME_AIR_TIME)
            slime.hop_vx, slime.hop_vy = dx * speed, dy * speed
            slime.hop_target = ("rival" if rival else "player") if attacking else ""
            slime.hop_left = SLIME_WINDUP + SLIME_AIR_TIME
            slime.move_cooldown = 1.28 if self.interior in tide.CELLS else 2.0
        before = slime.hop_left
        slime.hop_left = max(0, before - dt)
        airborne = min(before, SLIME_AIR_TIME) - min(slime.hop_left, SLIME_AIR_TIME)
        nx = slime.x + slime.hop_vx * airborne
        ny = slime.y + slime.hop_vy * airborne
        body = pygame.Rect(round(nx), round(ny), 25, 25)
        if not self.enemy_blocked(body):
            slime.x, slime.y = nx, ny
        if slime.hop_left > 0:
            return
        body.topleft = round(slime.x), round(slime.y)
        spread=8*(slime.slime_count-1)
        body=body.inflate(spread,spread)
        damage=slime.slime_count
        if slime.hop_target:
            self.burst_effect("dust", *body.midbottom, (165, 157, 110), 4)
        if slime.hop_target == "player" and body.colliderect(self.player):
            self.hurt_player("スライムの飛びかかりを受けた！", body.center,damage,attacker=slime)
        elif slime.hop_target == "rival":
            for enemy in self.enemies:
                if enemy.kind != "slime" and enemy.hp > 0 and body.colliderect(pygame.Rect(enemy.x, enemy.y, 25, 25)):
                    length = max(1, math.hypot(slime.hop_vx, slime.hop_vy))
                    self.damage_enemy(enemy, damage, slime.hop_vx / length, slime.hop_vy / length)
                    break
        slime.hop_target = ""

    def player_visible_to_enemy(self, enemy):
        px, py = self.player.center
        ex, ey = enemy.x + 12, enemy.y + 12
        if self.room is None and self.interior is None:
            cam_x, cam_y = self.camera_offset()
            view = pygame.Rect(cam_x, cam_y, WIDTH, PLAY_H)
        else:
            view = pygame.Rect(0, HUD_H, WIDTH, PLAY_H)
        if not view.collidepoint(px, py) or not view.collidepoint(ex, ey):
            return False
        distance = math.hypot(px - ex, py - ey)
        steps = max(1, int(distance / 12))
        for i in range(1, steps):
            x = ex + (px - ex) * i / steps
            y = ey + (py - ey) * i / steps
            if any(obstacle.collidepoint(x, y) for _, obstacle in self.obstacles):
                return False
        return True

    def update(self, dt, keys):
        if self.seal_open:
            return
        if self.interior in tide.NAMES and not (self.game_over or self.home_screen or self.name_editing or self.inventory_open or self.map_open):
            self.talk_counts["sea_seconds"]=self.talk_counts.get("sea_seconds",0)+dt
        if self.ending_open:
            self.ending_age=min(4,self.ending_age+dt)
        self.message_timer = max(0, self.message_timer - dt)
        self.attack_timer = max(0, self.attack_timer - dt)
        self.shield_cooldown = max(0, self.shield_cooldown - dt)
        self.invulnerable = max(0, self.invulnerable - dt)
        self.blink_followup=max(0,self.blink_followup-dt)
        self.shukuchi_cooldown = max(0, self.shukuchi_cooldown - dt)
        self.dash_cooldown = max(0, self.dash_cooldown - dt)
        self.jump_cooldown = max(0, self.jump_cooldown - dt)
        if 0 < self.jump_timer <= dt:
            self.burst_effect("dust", *self.player.midbottom, (218, 192, 145), 9)
        self.jump_timer = max(0, self.jump_timer - dt)
        self.dash_flash = max(0, self.dash_flash - dt)
        self.transition_cooldown = max(0, self.transition_cooldown - dt)
        self.flame_timer = max(0, self.flame_timer - dt)
        self.power_cooldowns = {power: max(0.0, time_left - dt)
                                for power, time_left in self.power_cooldowns.items()}
        self.guard_cooldowns = {name: max(0.0, time_left - dt)
                                for name, time_left in self.guard_cooldowns.items()}
        for wall in self.magic_walls:
            wall["timer"] -= dt
        self.magic_walls = [wall for wall in self.magic_walls if wall["timer"] > 0]
        for effect in self.effects:
            effect["age"] += dt
            for particle in effect["particles"]:
                particle[0] += particle[2] * dt
                particle[1] += particle[3] * dt
                particle[2] *= .94
                particle[3] *= .94
        self.effects = [effect for effect in self.effects if effect["age"] < effect["life"]]
        if self.home_screen or self.map_open or self.inventory_open or self.name_editing or self.warp_open:
            self.buffered_powers.clear()
            return
        if self.game_over or self.ending_open:
            self.buffered_powers.clear()
        else:
            if self.next_defender():
                self.capture_boss()
            self.resolve_power_inputs()
        dx = int(keys[pygame.K_d]) - int(keys[pygame.K_a])
        dy = int(keys[pygame.K_s]) - int(keys[pygame.K_w])
        if not self.ending_open and not self.game_over:
            self.courier_run=max(0,self.courier_run-dt)
            self.town_time+=dt
            self.advance_people(dt)
            self.walking = bool(dx or dy)
            if self.walking:
                self.walk_time += dt
            else:
                self.walk_time = 0.0
            dashing = bool(keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
            previous = self.player.topleft
            self.move_player(dx, dy, dt, dashing=dashing)
            self.input_review.move((dx, dy) if previous != self.player.topleft else (0, 0), dt)
            self.running = dashing and previous != self.player.topleft
            if self.attack_timer>0:
                self.advance_strike()
            if dashing and (dx or dy) and self.dash_flash <= 0:
                self.dash_flash = .11
                self.burst_effect("dust", *self.player.center, (196, 205, 158), 3)
            self.handle_touch_interactions()
            if self.interior is None and self.room is None:
                guards = (npc for npc in self.npcs_for_cell((7, 5)) if npc.get("role") == "guard")
                for guard in guards:
                    if self.guard_cooldowns[guard["name"]] > 0:
                        continue
                    candidates = [(math.hypot(enemy.x + 12 - guard["x"], enemy.y + 12 - guard["y"]), enemy)
                                  for enemy in self.enemies if enemy.hp > 0]
                    candidates = [(distance, enemy) for distance, enemy in candidates if distance < 88]
                    if candidates:
                        _distance, target = min(candidates, key=lambda pair: pair[0])
                        vx, vy = target.x + 12 - guard["x"], target.y + 12 - guard["y"]
                        length = max(1, math.hypot(vx, vy))
                        self.damage_enemy(target, 1, vx / length, vy / length)
                        self.guard_cooldowns[guard["name"]] = .8
                        self.effects.append({"kind": "guard_melee", "x": guard["x"], "y": guard["y"],
                                             "tx": target.x + 12, "ty": target.y + 12,
                                             "weapon": guard.get("weapon", "sword"),
                                             "age": 0.0, "life": .2, "color": (246, 221, 143),
                                             "particles": []})
                self.enemies = [enemy for enemy in self.enemies if enemy.hp > 0]
            self.merge_slimes()
            for e in self.enemies[:]:
                e.walking_boss=False
                if e.hp <= 0:
                    continue
                e.weakness_flash=max(0,e.weakness_flash-dt)
                if e.burn_ticks:
                    e.burn_delay -= dt
                    if e.burn_delay <= 0:
                        e.burn_ticks -= 1
                        e.burn_delay += 1
                        self.damage_enemy(e,1,0,0)
                        if e.hp<=0:
                            continue
                if e.exposed>0:
                    e.exposed=max(0,e.exposed-dt)
                    continue
                if e.stun>0:
                    e.hop_left = 0
                    e.hop_target = ""
                    e.stun=max(0,e.stun-dt)
                    continue
                e.hurt = max(0, e.hurt - dt)
                e.attack_cooldown = max(0, e.attack_cooldown - dt)
                e.move_cooldown = max(0, e.move_cooldown - dt)
                e.special_timer = (e.special_timer-dt)%1.6 if e.kind=="stalfos" else max(0, e.special_timer - dt)
                ex, ey = e.x + 12, e.y + 12
                player_distance = math.hypot(self.player.centerx - ex, self.player.centery - ey)
                if (e.kind == "boss" and e.special_timer <= 0 and (self.interior in tide.CELLS or e.boss_id == 5 or player_distance <= 360)
                        and self.player_visible_to_enemy(e)):
                    self.start_boss_attack(e)

                # Different species fight when they meet within this distance.
                rivals = []
                for other in self.enemies:
                    if other is e or other.hp <= 0 or other.kind == e.kind:
                        continue
                    ox, oy = other.x + 12, other.y + 12
                    distance = math.hypot(ox - ex, oy - ey)
                    if distance <= 170:
                        rivals.append((distance, other, ox, oy))

                target = None
                if rivals and not (self.interior in tide.CELLS and player_distance<180 and self.player_visible_to_enemy(e)):
                    _, rival, tx, ty = min(rivals, key=lambda item: item[0])
                    target = (tx, ty, rival)
                elif self.player_visible_to_enemy(e):
                    target = (self.player.centerx, self.player.centery, None)
                else:
                    # Out of sight, same-species monsters gather into a loose pack.
                    allies = []
                    for other in self.enemies:
                        if other is e or other.hp <= 0 or other.kind != e.kind:
                            continue
                        ox, oy = other.x + 12, other.y + 12
                        distance = math.hypot(ox - ex, oy - ey)
                        if 65 < distance <= 210:
                            allies.append((distance, ox, oy))
                    if allies:
                        _, tx, ty = min(allies, key=lambda item: item[0])
                        target = (tx, ty, None)

                if self.interior in tide.CELLS and e.kind in ("stalfos","bat") and target and target[2] is None and 55<player_distance<255 and e.attack_cooldown<=0:
                    first=len(self.hostile_attacks)
                    if e.kind=="stalfos":
                        self.aimed_fan(ex,ey,*self.player.center,.54)
                    else:
                        self.add_boss_hazard("wind_blast",*self.player.center,.64,33,.27,100)
                    for hazard in self.hostile_attacks[first:]:hazard["attacker"]=e
                    e.attack_cooldown=3.2 if e.kind=="stalfos" else 2.65
                if e.kind == "slime":
                    if not e.hop_left and not e.move_cooldown and e.slime_count<4:
                        mates=(m for m in self.enemies if m is not e and m.kind=="slime" and
                               m.hp>0 and m.slime_count+e.slime_count<=4)
                        mate=min(mates,key=lambda m:math.hypot(m.x-e.x,m.y-e.y),default=None)
                        if mate and 30<math.hypot(mate.x-e.x,mate.y-e.y)<=145:
                            target=(mate.x+12,mate.y+12,mate)
                    self.update_slime(e, dt, target)
                    continue
                if e.boss_id == 5 and 0 < e.special_timer < .58:
                    target = None  # Brief recovery before the next cast.
                if target is not None:
                    tx, ty, rival = target
                    vx, vy = tx - ex, ty - ey
                    distance = max(1, math.hypot(vx, vy))
                    ux, uy = vx / distance, vy / distance
                    if rival is not None and distance <= 34:
                        if e.attack_cooldown <= 0:
                            if self.interior in tide.CELLS:
                                self.add_boss_hazard("melee",tx,ty,.38,26,.10)
                                self.hostile_attacks[-1].update(attacker=e,rival=rival)
                            else:self.damage_enemy(rival,1,ux,uy)
                            e.attack_cooldown = .72
                    elif distance > 16:
                        # Bats weave while pursuing; the others walk straight toward a target.
                        if e.kind == "bat" and rival is None:
                            ux, uy = ux - uy * .28, uy + ux * .28
                        # Leave room for companions so a pack does not collapse into one sprite.
                        if rival is None:
                            for other in self.enemies:
                                if other is e or other.hp <= 0 or other.kind != e.kind:
                                    continue
                                ox, oy = other.x + 12, other.y + 12
                                apart = math.hypot(ox - ex, oy - ey)
                                if 0 < apart < 29:
                                    ux -= (ox - ex) / apart * .65
                                    uy -= (oy - ey) / apart * .65
                            length = max(1, math.hypot(ux, uy))
                            ux, uy = ux / length, uy / length
                        pace=e.speed
                        if rival is None and e.kind=="stalfos" and distance<115:
                            pace*=1.5 if (e.special_timer%1.6)<.42 else .92
                        if e.kind=="boss" and self.interior in tide.CELLS:
                            cast=tide.art.current_attack(self,e)
                            if cast and cast["kind"]!="melee" and cast["delay"]<=.23:
                                pace=0
                        move_distance = pace * dt
                        r = pygame.Rect(round(e.x + ux * move_distance),
                                        round(e.y + uy * move_distance), 25, 25)
                        if not self.enemy_blocked(r):
                            if e.kind=="boss" and move_distance>0 and (ux or uy):
                                e.facing_octant=tide.art.heading(ux,uy)
                                e.walking_boss=True
                                e.stride_distance+=move_distance
                            e.x += ux * move_distance
                            e.y += uy * move_distance

                r = pygame.Rect(round(e.x), round(e.y), 25, 25)
                if r.colliderect(self.player) and self.invulnerable <= 0 and e.attack_cooldown <= 0:
                    if self.interior in tide.CELLS:
                        self.add_boss_hazard("melee",*self.player.center,.46,28,.12)
                        self.hostile_attacks[-1]["attacker"]=e
                    else:
                        self.hurt_player("攻撃を受けた！",r.center,2 if self.interior in wastes.NAMES else 1,attacker=e)
                    e.attack_cooldown = .85
            self.enemies = [enemy for enemy in self.enemies if enemy.hp > 0]
            bow.advance(self,dt)
            tide.hazard_tick(self,dt)
            self.update_boss_hazards(dt)
            if self.room is not None and not self.enemies:
                self.cleared_rooms.add(self.location_key())
                self.room_specials()
            for bomb in self.bomb_list[:]:
                bomb[2] -= dt
                if bomb[2] <= 0:
                    bx, by = bomb[0], bomb[1]
                    heavy = len(bomb)>3 and bomb[3]=="heavy"
                    radius = 155 if heavy else 110
                    self.burst_effect("explosion", bx, by, (255, 137, 47), 38 if heavy else 26)
                    self.effects[-1]["spread"]=radius
                    for e in self.enemies:
                        vx, vy = e.x + 12 - bx, e.y + 12 - by
                        distance = math.hypot(vx, vy)
                        if distance < radius:
                            length = max(1, distance)
                            self.damage_enemy(e, 6 if heavy else 4, vx / length, vy / length)
                    self.enemies = [e for e in self.enemies if e.hp > 0]
                    self.bomb_list.remove(bomb)
                    if not self.enemies:
                        self.cleared_rooms.add(self.location_key())
                        if self.room is not None:
                            self.room_specials()

    def draw_home_screen(self):
        screen.fill((23, 34, 44))
        for y in range(0, HEIGHT, 24):
            shade = y // 36
            pygame.draw.rect(screen, (24 + shade, 39 + shade, 53 + shade), (0, y, WIDTH, 24))
        pygame.draw.circle(screen, (239, 207, 135), (WIDTH - 150, 138), 39)
        pygame.draw.polygon(screen, (45, 68, 72), [(0, 350), (135, 204), (278, 355),
                                                    (430, 218), (610, 355), (735, 260), (800, 330),
                                                    (800, 600), (0, 600)])
        pygame.draw.polygon(screen, (28, 56, 51), [(0, 420), (128, 310), (270, 435),
                                                    (440, 315), (590, 428), (730, 325), (800, 390),
                                                    (800, 600), (0, 600)])
        for x, y in ((60, 390), (120, 416), (682, 408), (752, 430), (535, 455), (320, 466)):
            pygame.draw.rect(screen, (93, 66, 47), (x + 7, y + 20, 7, 25))
            pygame.draw.polygon(screen, (35, 86, 58), [(x, y + 28), (x + 10, y), (x + 24, y + 28)])
            pygame.draw.polygon(screen, (55, 111, 69), [(x + 3, y + 19), (x + 10, y - 3), (x + 21, y + 19)])
        hero = HERO_SPRITES["down"][1]
        screen.blit(hero, hero.get_rect(center=(230, 420)))
        if self.home_help:
            panel = pygame.Rect(110, 66, 580, 480)
            pygame.draw.rect(screen, (20, 29, 34), panel, border_radius=12)
            pygame.draw.rect(screen, GOLD, panel, 3, border_radius=12)
            self.center_text("操作方法", WIDTH // 2, 100, BIG, GOLD)
            lines = [
                "移動: WASD",
                "攻撃: J    爆弾: K    薬: L    演出量: F",
                "ダッシュ: U    縮地: I    ジャンプ: Space",
                "ワープ: O    地図: /    調べる: E    バッグ: ;",
                "回復: Y    雷: G    焔: B    嵐: N    大地: M",
                "剣: R    槍: T    弓: .    盾: ,　ジャストガード: P",
                "セーブ: F5    ロード: F9    冒険開始時に名前を入力",
                "名前を1018にすると全ての力と装備がそろう",
                "本編の仲間を募集・終了: F3　　Escで戻る",
            ]
            for index, line in enumerate(lines):
                self.center_text(line, WIDTH // 2, 154 + index * 39, SMALL, WHITE)
        else:
            self.center_text("星図の旅人 III　白暦の海", WIDTH // 2, 108, BIG, GOLD)
            self.center_text("父を葬った朝、まだ生まれていない弟から手紙が来た。", WIDTH // 2, 146, SMALL, WHITE)
            options = ["新しく冒険を始める", "続きから", "操作方法", "同じWi-Fiで対戦", "本編ストーリーに参加", "終了"]
            has_save = SAVE_PATH.exists()
            for index, option in enumerate(options):
                y = 210 + index * 43
                color = (145, 150, 148) if index == 1 and not has_save else WHITE
                if self.home_selection == index:
                    pygame.draw.rect(screen, (30, 45, 48), (365, y - 17, 300, 36), border_radius=7)
                    pygame.draw.rect(screen, GOLD, (365, y - 17, 300, 36), 2, border_radius=7)
                    color = GOLD
                    self.center_text("▶", 383, y, FONT, GOLD)
                self.center_text(option, 515, y, FONT, color)
            self.center_text("W/Sで選択・Enterで決定　 V 序幕　 F1 利用規約", WIDTH // 2, 460, SMALL, (207, 216, 205))
            if not has_save:
                self.center_text("セーブデータがあると「続きから」を選べます", WIDTH // 2, 490, SMALL, (168, 179, 176))
        pygame.display.flip()

    def draw_castle(self):
        stage = self.interior
        for row, y in enumerate(range(HUD_H, HEIGHT, 32)):
            for col in range(-1, 14):
                x = col*64 + (row%2)*32
                v = (row*7+col*11)%11
                pygame.draw.rect(screen, (42+v, 43+v, 54+v), (x,y,62,30))
        if stage == "forecourt":
            for y in range(110, 524, 16):
                half = 53 + (y-110)//4
                pygame.draw.rect(screen,(104,104,115),(400-half,y,half*2,12))
                pygame.draw.line(screen,(155,151,153),(400-half,y),(400+half,y),2)
            for x in (162, 545):
                pygame.draw.rect(screen,(63,60,75),(x,56,92,102))
                for dx in (0,32,64):
                    pygame.draw.rect(screen,(100,93,107),(x+dx,43,22,22))
        else:
            pygame.draw.rect(screen,(115,45,57),(332,98,136,455))
            for x in (336,461):
                pygame.draw.line(screen,GOLD,(x,98),(x,552),2)
        if stage == "throne" or stage in ROYAL:
            pygame.draw.rect(screen,GOLD,(364,74,72,62),border_radius=8)
            pygame.draw.rect(screen,(112,32,50),(370,80,60,49),border_radius=6)
            pygame.draw.rect(screen,(157,86,70),(355,131,90,17))
        else:
            pygame.draw.rect(screen,(127,111,99),CASTLE_DOOR.inflate(14,12),border_radius=8)
            pygame.draw.rect(screen,(64,38,43),CASTLE_DOOR)
            pygame.draw.line(screen,GOLD,CASTLE_DOOR.midtop,CASTLE_DOOR.midbottom,2)
            prompt = "城門" if stage=="forecourt" else "王の間　Eで開く"
            self.center_text(prompt,400,93,SMALL,WHITE)
            self.center_text("戻る",400,559,SMALL,WHITE)
        for x in (322,478):
            height = 17 + round(3*math.sin(pygame.time.get_ticks()*.008+x))
            pygame.draw.polygon(screen,(238,105,47),[(x-6,119),(x,119-height),(x+6,119)])
            pygame.draw.line(screen,(97,68,50),(x,119),(x,129),4)

    def draw(self):
        if self.home_screen:
            self.draw_home_screen()
            return
        screen.fill(INK)
        if self.interior=="capital":
            self.draw_capital()
        elif self.interior in east.ROOMS:
            east.draw(self,screen,SMALL,pygame)
            if self.interior=="guild":
                cy=381+round(self.courier_run*65)
                if self.courier_run:self.npc_poses[("急使の報告",400,cy)]=(2 if int(self.courier_run*9)%2 else -2,0)
                self.draw_npc(royal_npc("急使の報告",400,cy,2))
                self.center_text("E　救援の受付",400,402,SMALL,GOLD)
        elif self.interior in tide.NAMES:
            tide.draw(self,screen,SMALL)
        elif self.interior in rift.AREAS:
            rift.draw(self,screen,SMALL)
        elif self.interior=="palace" or (self.interior and self.interior.startswith("keep")):
            self.draw_castle()
            self.center_text("南の出口",400,558,SMALL,WHITE)
            if self.interior=="palace":
                self.draw_npc(royal_npc("国王",400,158,3))
        elif self.interior in CASTLE:
            self.draw_castle()
            if self.interior=="throne" and self.final_boss_defeated:
                self.center_text("南へ　きさらぎ町に帰還",400,551,SMALL,GOLD)
        elif self.interior is not None:
            pygame.draw.rect(screen, (93, 69, 51), (0, HUD_H, WIDTH, HEIGHT - HUD_H))
            for y in range(HUD_H + 14, HEIGHT, 32):
                for x in range(0, WIDTH, 48):
                    shade = 4 if (x // 48 + y // 32) % 2 else -3
                    pygame.draw.rect(screen, (151 + shade, 116 + shade, 77 + shade),
                                     (x, y, 46, 30))
            pygame.draw.rect(screen, (64, 48, 39), (0, HUD_H, WIDTH, 18))
            pygame.draw.rect(screen, (64, 48, 39), (0, HEIGHT - 20, WIDTH, 20))
            self.center_text(INTERIOR_NAMES[self.interior], WIDTH // 2, 76, FONT, GOLD)
            pygame.draw.rect(screen, (47, 35, 30), (WIDTH // 2 - 38, HEIGHT - 37, 76, 17))
            self.center_text("出口", WIDTH // 2, HEIGHT - 29, SMALL, WHITE)
            if self.interior=="inn" and "hearth_inn" in self.chapter_flags:
                pygame.draw.rect(screen,(102,68,46),(352,383,96,30))
                for i,name in enumerate(("旅の荷運び","旅の職人")):
                    self.draw_npc(royal_npc(name,370+i*62,384,i))
                self.center_text("E　相席する",400,428,SMALL,GOLD)
            if self.interior=="inn" and "hearth_spoon" in self.chapter_flags:
                for name,x,y in hearth.COOK:
                    if name=="薪の炉":
                        pygame.draw.rect(screen,(94,61,47),(x-15,y-22,30,22))
                        pygame.draw.polygon(screen,(251,163,72),[(x-8,y-6),(x+1,y-19),(x+7,y-5)])
                    elif name=="麦の臼":
                        pygame.draw.ellipse(screen,(96,91,81),(x-20,y-17,40,18))
                        pygame.draw.line(screen,(179,132,85),(x,y-11),(x+15,y-29),4)
                    else:
                        pygame.draw.ellipse(screen,(109,158,167),(x-11,y-23,22,23))
                        pygame.draw.ellipse(screen,(62,90,101),(x-7,y-25,14,7))
                    self.center_text(name,x,y+15,SMALL,WHITE)
            if self.interior == "shop":
                self.center_text("R 薬 ◆5　 T 爆弾 ◆2　 Shift＋R 命の器 ◆24　 Shift＋T 不死鳥の羽 ◆16", WIDTH//2, 112, SMALL, WHITE)
            elif self.interior == "blacksmith":
                self.center_text("E: 武器を強化する (8)", WIDTH // 2, HEIGHT - 55, SMALL, WHITE)
            else:
                self.center_text("E: 休む    下の出口から町へ戻る", WIDTH // 2, HEIGHT - 55, SMALL, WHITE)
        elif self.room is None:
            cam_x, cam_y = self.camera_offset()
            for cell in self.chunks_in_view():
                left = cell[0] * WIDTH - cam_x
                top = cell[1] * PLAY_H - cam_y + HUD_H
                self.draw_world_features_for_chunk(cell, left, top)
            if (7, 5) in self.chunks_in_view():
                self.draw_roofs()
        else:
            base = (61, 54, 50)
            pygame.draw.rect(screen, base, (0, HUD_H, WIDTH, HEIGHT - HUD_H))
            for y in range(ROWS):
                for x in range(COLS):
                    col = (base[0] + (x * 5 + y * 3) % 8, base[1] + (x * 4 + y * 2) % 8, base[2] + (x * 2 + y * 5) % 8)
                    pygame.draw.rect(screen, col, (x * TILE, HUD_H + y * TILE, TILE - 1, TILE - 1))
            _, rx, ry = self.room
            for closed, start, end in ((rx == 0, (2,HUD_H), (2,HEIGHT)),
                                        (rx == 5, (WIDTH-3,HUD_H), (WIDTH-3,HEIGHT)),
                                        (ry == 0, (0,HUD_H+2), (WIDTH,HUD_H+2)),
                                        (ry == 4, (0,HEIGHT-3), (WIDTH,HEIGHT-3))):
                if closed:
                    pygame.draw.line(screen, (37,34,35), start, end, 5)
        for i, (kind, rect) in enumerate(self.obstacles):
            draw_rect = self.to_screen_rect(rect) if self.room is None else rect
            if self.interior is not None:
                if kind == "bed":
                    pygame.draw.rect(screen, (63, 42, 34), draw_rect.move(3, 4))
                    pygame.draw.rect(screen, (110, 72, 61), draw_rect)
                    pygame.draw.rect(screen, (214, 202, 174), (draw_rect.x + 8, draw_rect.y + 8, draw_rect.width - 16, 23))
                    pygame.draw.rect(screen, (119, 57, 52), (draw_rect.x + 8, draw_rect.y + 34, draw_rect.width - 16, draw_rect.height - 40))
                elif kind == "forge":
                    pygame.draw.rect(screen, (66, 61, 60), draw_rect)
                    pygame.draw.rect(screen, (130, 83, 58), draw_rect.inflate(-16, -18))
                    pygame.draw.circle(screen, (247, 117, 44), draw_rect.center, 18)
                elif kind == "shelf":
                    pygame.draw.rect(screen, (103, 67, 42), draw_rect)
                    for sy in range(draw_rect.top + 15, draw_rect.bottom, 23):
                        pygame.draw.line(screen, (201, 154, 83), (draw_rect.left + 5, sy), (draw_rect.right - 5, sy), 4)
                else:
                    pygame.draw.rect(screen, (79, 51, 37), draw_rect)
                    pygame.draw.rect(screen, (156, 108, 67), draw_rect, 5)
                    pygame.draw.line(screen, (205, 160, 99), draw_rect.midleft, draw_rect.midright, 2)
            elif self.room is None:
                if kind == "town_wall":
                    pygame.draw.rect(screen, (77, 81, 85), draw_rect)
                    pygame.draw.rect(screen, (128, 132, 132), draw_rect, 3)
                    if draw_rect.width > 40:
                        for stone_x in range(draw_rect.left + 18, draw_rect.right, 48):
                            pygame.draw.line(screen, (57, 62, 65), (stone_x, draw_rect.top), (stone_x, draw_rect.bottom), 2)
                        pygame.draw.line(screen, (55, 59, 61), draw_rect.midleft, draw_rect.midright, 2)
                    else:
                        for stone_y in range(draw_rect.top + 18, draw_rect.bottom, 30):
                            pygame.draw.line(screen, (55, 59, 61), (draw_rect.left, stone_y), (draw_rect.right, stone_y), 2)
                elif kind == "solid":
                    continue
                elif kind == "tree":
                    pygame.draw.rect(screen, (91, 61, 42), (draw_rect.centerx - 5, draw_rect.centery + 3, 10, 18))
                    crown = [(draw_rect.left + 2, draw_rect.centery - 2), (draw_rect.left + 9, draw_rect.top + 7),
                             (draw_rect.centerx - 3, draw_rect.top), (draw_rect.centerx + 5, draw_rect.top + 8),
                             (draw_rect.right - 2, draw_rect.centery - 2), (draw_rect.right - 7, draw_rect.bottom - 3),
                             (draw_rect.left + 7, draw_rect.bottom - 1)]
                    pygame.draw.polygon(screen, (32, 82 + (i % 3) * 8, 51), crown)
                    pygame.draw.lines(screen, (72, 122, 73), True, crown[1:5], 2)
                elif kind == "rock":
                    points = [(draw_rect.left + 3, draw_rect.bottom - 6), (draw_rect.left + 7, draw_rect.top + 8),
                              (draw_rect.centerx - 3, draw_rect.top + 2), (draw_rect.right - 4, draw_rect.top + 11),
                              (draw_rect.right - 1, draw_rect.bottom - 8), (draw_rect.centerx, draw_rect.bottom - 2)]
                    pygame.draw.polygon(screen, (101, 103, 101), points)
                    pygame.draw.line(screen, (148, 149, 140), points[1], points[2], 2)
            else:
                pygame.draw.rect(screen, STONE, draw_rect, border_radius=5)
                pygame.draw.rect(screen, (145, 149, 157), draw_rect.inflate(-12, -12), border_radius=3)
        for wall in self.magic_walls:
            if wall["location"] != self.location_key():
                continue
            wall_rect = self.to_screen_rect(wall["rect"]) if self.room is None else wall["rect"]
            pygame.draw.rect(screen, (111, 81, 55), wall_rect, border_radius=3)
            for i in range(1, 4):
                fx = wall_rect.left + wall_rect.width*i//4
                fy = wall_rect.top + wall_rect.height*i//4
                pygame.draw.lines(screen, (226, 184, 117), False,
                                  [(fx-3,fy+3), (fx,fy-2), (fx+2,fy), (fx+4,fy-4)], 2)
            pygame.draw.rect(screen, (183, 143, 85), wall_rect, 2, border_radius=3)
            pygame.draw.line(screen, (204, 174, 116), wall_rect.midtop,
                             (wall_rect.centerx, wall_rect.centery), 2)
        for x, y, kind in self.pickups:
            if self.room is None:
                x, y = self.to_screen_point(x, y)
            if kind == "chest":
                pygame.draw.rect(screen, (55,35,29), (x-3,y+1,26,20), border_radius=3)
                pygame.draw.rect(screen, (157,90,42), (x-2,y+2,24,8), border_radius=3)
                pygame.draw.line(screen, GOLD, (x-2,y+10), (x+21,y+10), 2)
                pygame.draw.rect(screen, GOLD, (x+7,y+8,6,7))
            elif kind.startswith("entrance"):
                pygame.draw.ellipse(screen, (27, 24, 36), (x - 8, y - 8, 42, 35))
                pygame.draw.ellipse(screen, PURPLE, (x - 8, y - 8, 42, 35), 3)
                self.label("入", x + 4, y - 3, WHITE)
            elif kind == "final_gate":
                pygame.draw.rect(screen, GOLD, (x - 4, y - 12, 30, 42), 4)
                self.label("✦", x, y - 8, GOLD)
                self.center_text("Eで魔王城前へ",x+10,y+42,SMALL,GOLD)
            elif kind == "stairs":
                pygame.draw.ellipse(screen, (20, 20, 24), (x - 3, y - 4, 28, 24))
                self.label("↓", x + 2, y - 7, WHITE)
            elif kind in ("sword", "spear", "shield"):
                pygame.draw.circle(screen, (41, 44, 48), (x + 10, y + 10), 15)
                if kind == "sword":
                    pygame.draw.line(screen, (219, 230, 237), (x + 4, y + 17), (x + 17, y + 3), 4)
                    pygame.draw.line(screen, GOLD, (x + 5, y + 10), (x + 12, y + 17), 3)
                elif kind == "spear":
                    pygame.draw.line(screen, (152, 101, 59), (x + 3, y + 18), (x + 17, y + 4), 3)
                    pygame.draw.polygon(screen, (222, 231, 236), [(x + 13, y + 4), (x + 19, y + 1), (x + 17, y + 8)])
                else:
                    pygame.draw.polygon(screen, (126, 83, 52), [(x + 10, y + 1), (x + 18, y + 5), (x + 17, y + 14), (x + 10, y + 20), (x + 3, y + 14), (x + 2, y + 5)])
                    pygame.draw.polygon(screen, GOLD, [(x + 10, y + 4), (x + 15, y + 7), (x + 14, y + 13), (x + 10, y + 17), (x + 6, y + 13), (x + 5, y + 7)], 1)
            else:
                color = {"rupee": (43, 207, 123), "heart": RED, "bomb": INK, "key": GOLD}.get(kind, GOLD)
                if kind == "rupee":
                    crystal = [(x + 10, y), (x + 17, y + 7), (x + 14, y + 19),
                               (x + 6, y + 19), (x + 3, y + 7)]
                    pygame.draw.polygon(screen, color, crystal)
                    pygame.draw.polygon(screen, (153, 255, 189), [(x + 10, y + 3), (x + 14, y + 8),
                                                                   (x + 12, y + 16), (x + 9, y + 15)], 1)
                else:
                    pygame.draw.circle(screen, color, (x + 10, y + 10), 10)
                if kind == "heart":
                    self.label("♥", x + 1, y - 1, WHITE)
        for bomb in self.bomb_list:
            bx, by = self.to_screen_point(bomb[0], bomb[1])
            pygame.draw.circle(screen, (119,66,44) if len(bomb)>3 else INK, (bx, by), 15 if len(bomb)>3 else 10)
            fuse = round(3 + 2 * math.sin(bomb[2] * 35))
            pygame.draw.line(screen, (193, 154, 94), (bx+4, by-6), (bx+8, by-13), 2)
            pygame.draw.circle(screen, (255, 209, 97), (bx+8, by-13), fuse)
            pygame.draw.circle(screen, GOLD, (bx, by), 4)
        self.draw_hostile_attacks()
        bow.draw_arrows(self,screen)
        # Y-sort actors so a person in front is drawn over a person behind.
        actors = [(e.y + 28, "enemy", e) for e in self.enemies]
        if self.room is None and self.interior is None:
            for cell in self.chunks_in_view():
                actors.extend((npc["y"] + 4, "npc", npc) for npc in self.npcs_for_cell(cell))
        if self.companion and self.companion.body:
            actors.append((self.companion.body.bottom+4,"companion",None))
        actors.append((self.player.bottom + 4, "player", None))
        for _, actor_type, actor in sorted(actors, key=lambda entry: entry[0]):
            if actor_type == "companion":
                self.companion.draw(self,screen,HERO_SPRITES,SMALL)
            elif actor_type == "enemy":
                self.draw_enemy(actor)
            elif actor_type == "npc":
                self.draw_npc(actor)
            else:
                self.draw_player()
        self.draw_effects()
        self.draw_hud()
        if self.seal_open:
            self.draw_seal()
            pygame.display.flip()
            return
        if self.seal_waiting():
            self.center_text("四天王の封印盤　 Eで調べる",400,185,FONT,GOLD)
        if self.message_timer > 0:
            box = pygame.Rect(90, HEIGHT - 72, WIDTH - 180, 42)
            pygame.draw.rect(screen, (25, 28, 34), box, border_radius=6)
            pygame.draw.rect(screen, GOLD, box, 2, border_radius=6)
            lines=[""]
            for char in self.message:
                if SMALL.size(lines[-1]+char)[0]>box.width-24:lines.append("")
                lines[-1]+=char
            if len(lines)>1:
                box.height=8+SMALL.get_linesize()*len(lines);box.bottom=HEIGHT-30
                pygame.draw.rect(screen,(25,28,34),box,border_radius=6)
                pygame.draw.rect(screen,GOLD,box,2,border_radius=6)
            for i,line in enumerate(lines):
                self.center_text(line,box.centerx,box.centery+round((i-(len(lines)-1)/2)*SMALL.get_linesize()),SMALL,WHITE)
        if self.ending_open:
            screen.fill((26,23,41))
            gap=round(54*min(1,self.ending_age/2))
            pygame.draw.rect(screen,(134,66,137),(336,112,128,150))
            for x in (336-gap,400+gap):
                pygame.draw.rect(screen,(67,67,89),(x,110,64,152))
                pygame.draw.rect(screen,(166,142,105),(x,110,64,152),3)
            for i in range(6):
                a=i*math.tau/6
                pos=(400+round(103*math.cos(a)),186+round(101*math.sin(a)))
                pygame.draw.circle(screen,GOLD if self.ending_age>i*.3 else STONE,pos,6)
            self.center_text("地上編・結　六灯の向こう岸",400,346,BIG,GOLD)
            self.center_text("六人目の冠が砕けた夜、西街道の土の下から鐘が鳴った。",400,401,FONT,WHITE)
            if self.ending_age>=2:
                self.center_text("一打、間を置いて二打。霞港の船乗りが立ち上がる。「あれは救難信号だ」",400,449,SMALL,WHITE)
            self.center_text("Enter：王都から遺跡を探しに行く　・　R：新しい冒険",400,494,SMALL,GOLD)
        elif self.game_over:
            self.overlay("冒険失敗", "Enterで宿に戻る    Rで新しい冒険" if self.inn_registered else "Rキーでもう一度挑戦する。")
        if self.game_over and self.retry_data:
            self.center_text("J：ボスの扉から再挑戦",400,410,FONT,GOLD)
        if self.map_open:
            self.draw_map_overlay()
        if self.warp_open:
            self.draw_warp_overlay()
        if self.inventory_open:
            self.draw_inventory_overlay()
        if self.name_editing:
            self.draw_name_editor()
        pygame.display.flip()

    def draw_hostile_attacks(self):
        for hazard in self.hostile_attacks:
            x, y = self.to_screen_point(hazard["x"], hazard["y"])
            radius = round(hazard["radius"])
            phase = pygame.time.get_ticks() / 220
            kind = hazard["kind"]
            warning = hazard["delay"] > 0
            if hazard.get("bell") and hazard["delay"]>0:
                self.center_text("鐘"+"ⅠⅡⅢ"[hazard["bell"]-1],x,120+25*hazard["bell"],SMALL,GOLD)
            if kind=="tidal_disk":
                tide.draw_wave(screen,x,y,hazard)
                continue
            if kind in ("across", "down"):
                color = (227, 160, 80) if warning else (245, 101, 207)
                for delta in (-radius, radius):
                    start, end = ((0,y+delta),(WIDTH,y+delta)) if kind=="across" else ((x+delta,HUD_H),(x+delta,HEIGHT))
                    pygame.draw.line(screen,color,start,end,2)
                if not warning:
                    start,end = ((0,y),(WIDTH,y)) if kind=="across" else ((x,HUD_H),(x,HEIGHT))
                    pygame.draw.line(screen,(247,181,241),start,end,2*radius)
                    pygame.draw.line(screen,WHITE,start,end,4)
                continue
            if kind == "meteor":
                pygame.draw.circle(screen,(211,125,242),(x,y),radius,2)
                lift = round(100*min(1,hazard["delay"]))
                pygame.draw.line(screen,(166,91,232),(x+lift//2,y-lift),(x+lift//2+8,y-lift-22),5)
                pygame.draw.circle(screen,(255,197,142),(x+lift//2,y-lift),8 if warning else radius-3)
                continue
            if kind == "orb":
                vx, vy = hazard["vx"]/245, hazard["vy"]/245
                if warning:
                    pygame.draw.line(screen,(189,99,164),(x,y),(round(x+vx*78),round(y+vy*78)),2)
                else:
                    pygame.draw.line(screen,(134,54,153),(round(x-vx*24),round(y-vy*24)),(x,y),9)
                    pygame.draw.circle(screen,(239,106,132),(x,y),radius)
                    pygame.draw.circle(screen,GOLD,(x,y),5)
                continue
            pygame.draw.circle(screen,(214,126,97) if warning else (231,154,108),(x,y),radius,1)
            if kind=="pull":
                pygame.draw.circle(screen,(208,123,202),(x,y),36,2)
            for i in range(10):
                a = i * math.tau / 10 + phase * .22
                rr = radius if hazard["delay"] > 0 else radius * (.65 + .25 * math.sin(phase+i))
                dot = (round(x+rr*math.cos(a)), round(y+rr*math.sin(a)))
                pygame.draw.circle(screen, (255, 173, 93) if hazard["delay"] > 0 else (237, 212, 162), dot, 2)
            if hazard["delay"] > 0:
                color = (248, 108, 63) if hazard["kind"] in ("fire_pillar", "root_burst") else (228, 190, 92)
                pygame.draw.circle(screen,(54,28,25),(x,y),radius)
                pygame.draw.circle(screen,color,(x,y),radius,3)
                pygame.draw.circle(screen, color, (x, y), max(3, radius // 4), 2)
            elif hazard["kind"] == "pull":
                pulse = round(12 + (1.0 - hazard["life"] / 1.55) * 26)
                for ring in range(3):
                    rr = max(10, round(radius * (.35 + ring * .22)) - pulse)
                    pygame.draw.circle(screen, (158, 89, 188), (x, y), rr, 2)
                for index in range(8):
                    angle = hazard["life"] * 4 + index * math.tau / 8
                    start = (round(x + math.cos(angle) * 18), round(y + math.sin(angle) * 18))
                    end = (round(x + math.cos(angle + .7) * 36), round(y + math.sin(angle + .7) * 36))
                    pygame.draw.line(screen, (214, 139, 231), start, end, 2)
            elif hazard["kind"] == "fire_pillar":
                pygame.draw.ellipse(screen, (42, 25, 23), (x - radius, y - 8, radius * 2, 16))
                points = [(x - radius // 2, y + 5), (x - radius // 3, y - 18),
                          (x - 3, y - 42), (x + 5, y - 20),
                          (x + radius // 2, y + 4), (x, y + 10)]
                pygame.draw.polygon(screen, (219, 73, 39), points)
                pygame.draw.polygon(screen, (255, 183, 68),
                                    [(x - 5, y + 4), (x - 1, y - 23), (x + 8, y + 3)])
            elif hazard["kind"] == "wind_blast":
                pygame.draw.circle(screen, (110, 205, 224), (x, y), radius, 3)
                pygame.draw.line(screen, WHITE, (x - 9, y), (x + 9, y), 2)
                pygame.draw.polygon(screen, WHITE, [(x + 9, y), (x + 2, y - 5), (x + 2, y + 5)])
            else:
                color = (176, 123, 67) if hazard["kind"] == "quake" else (168, 73, 53)
                pygame.draw.circle(screen,color,(x,y),radius,3)
                if hazard["kind"] == "quake":
                    pygame.draw.polygon(screen, (185, 159, 125),
                                        [(x - 5, y + 5), (x, y - 19), (x + 5, y + 5)])

        # Draw timing cues on top of filled telegraphs.
        for hazard in self.hostile_attacks:
            delay=hazard["delay"]
            if hazard["kind"]=="tidal_disk" or delay<=0:continue
            x,y=self.to_screen_point(hazard["x"],hazard["y"])
            if hazard.get("arena_seal"):
                pygame.draw.lines(screen,(115,225,239),True,[(x,y-16),(x+16,y),(x,y+16),(x-16,y)],2)
            radius=8+round(16*min(1,delay/max(.001,hazard.get("windup",1))))
            pygame.draw.circle(screen,(255,242,176) if delay<=.25 else (210,166,102),(x,y),radius,2)

    def draw_inventory_overlay(self):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((8, 11, 16, 225))
        screen.blit(veil, (0, 0))
        panel = pygame.Rect(150, 52, 500, 506)
        pygame.draw.rect(screen, (35, 42, 48), panel, border_radius=10)
        pygame.draw.rect(screen, GOLD, panel, 3, border_radius=10)
        if self.journal_page:
            self.center_text("冒険手帳",400,84,BIG,GOLD)
            self.center_text(self.journal_goal(self.pinned),400,132,SMALL,WHITE)
            if self.interior in tide.NAMES:
                v=min(tide.voyage(self),tide.TOTAL-1)
                for row,line in enumerate((tide.STORY[v//7][1],tide.STORY[v//7][3], tide.BRIEFS[v%7], "先遣艇で現場へ　 P ジャストガード")):
                    self.center_text(line,400,205+row*62,SMALL,WHITE)
                return
            for i in range(6):
                if not self.royal_order:
                    name=DUNGEON_NAMES[i-1] if i else "きさらぎ町・保管庫"
                    state=("攻略済" if i-1 in self.seals else "探索") if i else "町"
                    self.label(("旗　" if i==self.pinned else "　　")+name+"　"+state,224,180+i*38,GOLD if i==self.pinned else WHITE)
                    continue
                name=REALMS[i-1][0] if i else "王城西街道"
                state=("解放済" if i in self.lords else "力が覚醒" if self.quest_steps[i-1]==3 else "未解放") if i else ("開通" if self.bridge_fixed else "探索")
                self.label(("旗　" if i==self.pinned else "　　")+name+"　"+state,224,180+i*38,GOLD if i==self.pinned else WHITE)
            if self.royal_order and self.pinned and self.quest_steps[self.pinned-1]==3:
                line=TALES[self.pinned-1][3 if self.pinned in self.lords else 2]
                self.center_text(line,400,399,SMALL,WHITE)
            line=life.destination(self,REALMS)[2]
            self.center_text("追跡中の目的" if line else "最後の手掛かり",400,430,SMALL,GOLD)
            self.center_text(line or self.last_clue,400,463,SMALL,WHITE)
            self.center_text("鍋底の五本線　"+hearth.goal(self.chapter_flags),400,499,SMALL,GOLD)
            self.center_text("A/D 追跡切替　"+self.tracking,400,519,SMALL,WHITE)
            self.center_text("W/S 地域の旗　 Tab バッグ　 ; 閉じる",400,540,SMALL,GOLD)
            return
        self.center_text("バッグ", WIDTH // 2, 82, BIG, GOLD)
        self.center_text(f"冒険者：{self.player_name}", WIDTH // 2, 120, FONT, WHITE)
        lines = [
            f"体力 {self.hp}/{self.max_hp}      エメラルド {self.rupees}      鍵 {self.keys}",
            f"薬 {self.potions}  爆弾 {self.bombs}   霊薬 {self.elixirs}（Shift+L） 大爆弾 {self.heavy_bombs}（Shift+K）",
            f"武器：{ {'none': '素手', 'sword': '鉄の剣', 'spear': '旅人の槍', 'bow':'潮木の短弓'}[self.weapon] }  強化 +{self.weapon_level}",
            f"不死鳥の羽 {self.revival_feathers}枚（自動復活）　 盾：{'装備中' if self.shield_equipped else 'なし'}",
            "所持品：" + ("、".join({"sword": "鉄の剣", "spear": "旅人の槍", "shield": "木の盾","bow":"潮木の短弓"}[item]
                                     for item in sorted(self.owned_gear)) or "なし"),
            f"完了した航海 {tide.voyage(self)}/182　冒険時間 {int(self.talk_counts.get('sea_seconds',0))//3600}時間{int(self.talk_counts.get('sea_seconds',0))//60%60}分",
            "獲得した力：" + ("、".join(POWER_NAMES[item] for item in POWER_NAMES if item in self.abilities) or "なし"),
            "L：薬    K：爆弾    J：攻撃    U：ダッシュ",
            "R：剣    T：槍    .：弓    ,：盾    Y/G/B/N/M：力",
            "F5：セーブ    F9：ロード    ;：バッグを閉じる",
            "I：縮地    Space：ジャンプ    O：ワープ    /：地図",
        ]
        for index, line in enumerate(lines):
            self.center_text(line, WIDTH // 2, 166 + index * 32, SMALL if index >= 7 else FONT,
                             (192, 214, 217) if index >= 7 else WHITE)
        self.center_text("Tab：冒険手帳　　; または Esc：閉じる", WIDTH // 2, 533, SMALL, GOLD)

    def draw_name_editor(self):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((8, 11, 16, 210))
        screen.blit(veil, (0, 0))
        panel = pygame.Rect(170, 210, 460, 160)
        pygame.draw.rect(screen, (35, 42, 48), panel, border_radius=10)
        pygame.draw.rect(screen, GOLD, panel, 3, border_radius=10)
        self.center_text("冒険者の名前", WIDTH // 2, 246, FONT, GOLD)
        self.center_text(self.name_buffer + "▏", WIDTH // 2, 291, BIG, WHITE)
        prompt = "Enter：既存セーブを上書きして開始　Esc：戻る" if SAVE_PATH.exists() else "名前を入力してEnterで冒険開始 / Escでタイトルへ戻る"
        self.center_text(prompt, WIDTH // 2, 338, SMALL, WHITE)

    def draw_map_overlay(self):
        if self.interior in tide.NAMES:
            tide.draw_chart(self,screen,SMALL);return
        if self.interior in rift.AREAS:
            screen.fill((31,30,47))
            if self.interior in wastes.CELLS:
                wastes.map_view(self,screen,SMALL);return
            self.center_text("灰冠宮・無声の玉座" if self.interior==wastes.THRONE else "境界の道筋",400,90,BIG,GOLD)
            for i,(key,name) in enumerate((k,rift.AREAS[k]) for k in rift.OLD_AREAS):
                self.center_text(("◆　" if key==self.interior else "")+name,400,147+i*49,FONT,GOLD if key==self.interior else WHITE)
            self.center_text(rift.objective(self.chapter_flags),400,410,SMALL,WHITE)
            self.center_text("/で閉じる",400,505,SMALL,GOLD)
            return
        if self.interior in ROYAL:
            self.draw_royal_map()
            return
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((12, 16, 22, 238))
        screen.blit(veil, (0, 0))
        self.center_text("探索地図", WIDTH // 2, 28, FONT, GOLD)
        self.center_text("歩いて訪れた場所だけが記録される。未知の場所へ進もう。",
                         WIDTH // 2, 52, SMALL, WHITE)

        pygame.draw.rect(screen, (29, 35, 42), (20, 76, 400, 350), border_radius=8)
        pygame.draw.rect(screen, (111, 125, 132), (20, 76, 400, 350), 2, border_radius=8)
        self.label("地上 15×10", 34, 86, GOLD)
        cell, gap = 22, 3
        start_x, start_y = 34, 112
        for y in range(10):
            for x in range(15):
                rect = pygame.Rect(start_x + x * (cell + gap), start_y + y * (cell + gap), cell, cell)
                seen = ("over", x, y) in self.visited
                color = (68, 117, 78) if seen else (43, 49, 57)
                if (x, y) == (7, 5) and seen:
                    color = (150, 116, 55)
                if self.room is None and (x, y) == self.world:
                    color = (224, 180, 66)
                if seen:
                    if y < 2:
                        terrain = ((63, 119, 145), (67, 128, 151), (76, 139, 157), (58, 112, 137))
                    elif x in (0, 1, 14) and 3 <= y <= 5:
                        terrain = ((106, 107, 98), (126, 122, 106), (112, 114, 107), (137, 130, 111))
                    elif y in (3, 4) and 4 <= x <= 7:
                        terrain = ((154, 132, 91), (161, 140, 97), (148, 127, 86), (170, 147, 102))
                    else:
                        terrain = ((62, 112, 72), (69, 122, 76), (76, 128, 78), (58, 105, 68))
                    if (x, y) == (7, 5):
                        terrain = ((153, 119, 76), (174, 140, 91), (139, 106, 72), (187, 151, 99))
                    for sy in range(4):
                        for sx in range(4):
                            shade = terrain[(sx + sy * 3 + x + y) % len(terrain)]
                            tile = pygame.Rect(rect.x + sx * 5, rect.y + sy * 5, 5, 5)
                            pygame.draw.rect(screen, shade, tile)
                    # Fine map marks: winding roads, streams, ridges and settlement blocks.
                    if 4 <= x <= 7 and y in (3, 4):
                        pygame.draw.line(screen, (206, 183, 134), (rect.left, rect.centery), (rect.right, rect.centery), 2)
                    if y < 2:
                        pygame.draw.line(screen, (117, 181, 196), (rect.left + 2, rect.bottom - 4),
                                         (rect.right - 2, rect.bottom - 5), 1)
                    if x in (0, 1, 14) and 3 <= y <= 5:
                        pygame.draw.line(screen, (174, 169, 151), rect.midleft, rect.midright, 2)
                    if (x, y) == (7, 5):
                        for hx in (rect.left + 4, rect.left + 13):
                            pygame.draw.rect(screen, (77, 64, 57), (hx, rect.top + 4, 5, 5))
                            pygame.draw.rect(screen, (93, 75, 62), (hx, rect.bottom - 9, 5, 5))
                else:
                    pygame.draw.rect(screen, color, rect, border_radius=2)
                pygame.draw.rect(screen, (92, 103, 109), rect, 1, border_radius=2)
                if self.room is None and (x, y) == self.world:
                    pygame.draw.rect(screen, WHITE, rect.inflate(-5, -5), 2)
        if not self.royal_order:
            target=DUNGEON_ENTRANCES[self.pinned-1] if self.pinned else ((7,4) if len(self.seals)==5 and not self.final_boss_defeated else (7,5))
            fx=start_x+target[0]*(cell+gap)+9
            fy=start_y+target[1]*(cell+gap)+17
            pygame.draw.line(screen,GOLD,(fx,fy),(fx,fy-14),2)
            pygame.draw.polygon(screen,(244,130,76),[(fx,fy-14),(fx+10,fy-11),(fx,fy-7)])
        pygame.draw.rect(screen, (68, 117, 78), (35, 391, 12, 12))
        self.label("訪問済み", 52, 389, WHITE)
        pygame.draw.rect(screen, (43, 49, 57), (127, 391, 12, 12))
        self.label("未踏", 144, 389, WHITE)
        pygame.draw.rect(screen, (224, 180, 66), (195, 391, 12, 12))
        self.label("現在地", 212, 389, WHITE)
        self.label(f"地上の探索: {sum(1 for loc in self.visited if loc[0] == 'over')}/150", 35, 409, (190, 220, 197))

        pygame.draw.rect(screen, (29, 35, 42), (435, 76, 345, 440), border_radius=8)
        pygame.draw.rect(screen, (111, 125, 132), (435, 76, 345, 440), 2, border_radius=8)
        self.label("ダンジョン", 450, 86, GOLD)
        for dungeon, name in enumerate(DUNGEON_NAMES):
            if dungeon in self.seals:
                continue
            y0 = 111 + dungeon * 79
            pygame.draw.rect(screen, (38, 44, 51), (447, y0, 321, 73), border_radius=5)
            self.label(f"{dungeon + 1}. {name}", 458, y0 + 7, WHITE)
            explored = sum(1 for loc in self.visited if len(loc) >= 4 and loc[0] == "dun" and loc[1] == dungeon)
            self.label(f"{explored}/30", 458, y0 + 35, (190, 205, 210))
            mini, mini_gap = 12, 2
            gx, gy = 635, y0 + 3
            for ry in range(5):
                for rx in range(6):
                    rect = pygame.Rect(gx + rx * (mini + mini_gap), gy + ry * (mini + mini_gap), mini, mini)
                    seen = ("dun", dungeon, rx, ry) in self.visited
                    color = (113, 78, 111) if seen else (43, 49, 57)
                    if self.room is not None and self.room == (dungeon, rx, ry):
                        color = (224, 180, 66)
                    pygame.draw.rect(screen, color, rect)
                    pygame.draw.rect(screen, (92, 103, 109), rect, 1)
        region,target,line=life.destination(self,REALMS)
        if region=="over":
            x,y=target
            pygame.draw.rect(screen,GOLD,(34+x*25,112+y*25,22,22),3)
        self.center_text("追跡　"+line if line else "/キーで閉じる",WIDTH//2,557,SMALL,WHITE)

    def draw_warp_overlay(self):
        if self.interior=="capital":
            panel=pygame.Rect(115,64,570,466)
            pygame.draw.rect(screen,(27,34,45),panel,border_radius=10)
            pygame.draw.rect(screen,GOLD,panel,2,border_radius=10)
            self.center_text("王領ワープ",400,99,BIG,GOLD)
            self.center_text("W/S・↑↓ 選択　 A/D・←→ 8件移動　 Enter 決定　 Esc 戻る",400,139,SMALL,WHITE)
            region,target,line=life.destination(self,REALMS)
            if line:self.center_text("追跡　"+line,400,555,SMALL,GOLD)
            start=(self.warp_index//8)*8
            current=self.royal_cell(*self.player.center)
            for i,(cell,name,_) in enumerate(self.royal_destinations[start:start+8],start):
                top=166+(i-start)*38
                if i==self.warp_index:
                    pygame.draw.rect(screen,(74,81,82),(139,top,522,32),border_radius=4)
                self.label(("◆ " if region=="royal" and cell==target else "")+name,157,top+6,GOLD if i==self.warp_index else WHITE)
                self.label(f"東西 {cell[0]}　南北 {cell[1]}",387,top+6,WHITE)
                if cell==current:
                    self.label("現在地",583,top+6,GOLD)
            self.center_text(f"{self.warp_index+1} / {len(self.royal_destinations)}",400,494,SMALL,WHITE)
            return
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((7, 12, 22, 218))
        screen.blit(veil, (0, 0))
        self.center_text("ワープ先を選ぶ", WIDTH // 2, 54, BIG, GOLD)
        self.center_text("矢印キーで訪問済みの場所を選択 / Enterで移動 / Escで戻る",
                         WIDTH // 2, 86, SMALL, WHITE)
        panel = pygame.Rect(78, 118, 644, 435)
        pygame.draw.rect(screen, (29, 35, 42), panel, border_radius=8)
        pygame.draw.rect(screen, (111, 125, 132), panel, 2, border_radius=8)
        cell, gap = 37, 3
        start_x, start_y = 115, 139
        for y in range(10):
            for x in range(15):
                rect = pygame.Rect(start_x + x * (cell + gap), start_y + y * (cell + gap), cell, cell)
                seen = ("over", x, y) in self.visited
                if seen:
                    color = (151, 119, 72) if (x, y) == (7, 5) else (68, 117, 78)
                    pygame.draw.rect(screen, color, rect, border_radius=3)
                    if 4 <= x <= 7 and y in (3, 4):
                        pygame.draw.line(screen, (201, 177, 128), rect.midleft, rect.midright, 3)
                else:
                    pygame.draw.rect(screen, (42, 48, 55), rect, border_radius=3)
                pygame.draw.rect(screen, (93, 103, 111), rect, 1, border_radius=3)
                if (x, y) == self.warp_cursor:
                    pygame.draw.rect(screen, GOLD, rect.inflate(2, 2), 3, border_radius=4)
                    self.center_text("◆", rect.centerx, rect.centery, SMALL, WHITE)
        name = f"{self.warp_cursor[0] + 1}列・{self.warp_cursor[1] + 1}行"
        if self.warp_cursor == (7, 5):
            name = "きさらぎ町"
        self.center_text(f"行き先：{name}", WIDTH // 2, 535, FONT, GOLD)
        region,target,line=life.destination(self,REALMS)
        if region=="over":
            x,y=target
            pygame.draw.rect(screen,GOLD,(start_x+x*(cell+gap),start_y+y*(cell+gap),cell,cell),3)
        self.center_text("追跡　"+line if line else "訪問済みの地上エリアへワープできます",WIDTH//2,565,SMALL,WHITE)

    def draw_world_features_for_chunk(self, cell, left, top):
        global screen
        viewport = screen
        chunk_surface = self.terrain_cache.get(cell)
        if chunk_surface is None:
            chunk_surface = pygame.Surface((WIDTH, HEIGHT)).convert()
            old_world = self.world
            try:
                screen = chunk_surface
                self.world = cell
                base = GREEN
                screen.fill(base)
                # Fine two-tone ground texture and scattered blades break up the old large grid.
                terrain_rng = random.Random(709 + cell[0] * 1031 + cell[1] * 9173)
                for ty in range((PLAY_H + 19) // 20):
                    for tx in range((WIDTH + 19) // 20):
                        shade = terrain_rng.randrange(-5, 8)
                        col = (base[0] + shade, base[1] + shade, base[2] + shade)
                        pygame.draw.rect(screen, col, (tx * 20, HUD_H + ty * 20, 19, 19))
                for _ in range(48):
                    fx = terrain_rng.randrange(8, WIDTH - 8)
                    fy = HUD_H + terrain_rng.randrange(8, PLAY_H - 8)
                    pygame.draw.line(screen, (91, 151, 86), (fx, fy), (fx + 2, fy - 3), 1)
                self.draw_world_features()
            finally:
                self.world = old_world
                screen = viewport
            self.terrain_cache[cell] = chunk_surface
            if len(self.terrain_cache) > 12:
                self.terrain_cache.pop(next(iter(self.terrain_cache)))
        viewport.blit(chunk_surface, (left, top), (0, HUD_H, WIDTH, PLAY_H))

    def draw_world_features(self):
        # Region landmarks give the map a varied, grounded landscape.
        if self.world[1] < 2:
            pygame.draw.rect(screen, WATER, (0, HUD_H, WIDTH, 18))
            for px in range((self.world[0] * 97) % 60, WIDTH, 60):
                pygame.draw.line(screen, (77, 147, 188), (px, HUD_H + 12), (px + 25, HUD_H + 12), 2)
        if self.world[1] in (3, 4) and self.world[0] in (4, 5, 6, 7):
            road = [(0, 360), (180, 332), (350, 370), (520, 338), (800, 365),
                    (800, 397), (520, 370), (350, 402), (180, 364), (0, 395)]
            pygame.draw.polygon(screen, (121, 103, 75), road)
            pygame.draw.lines(screen, (208, 184, 129), False, [(0, 376), (180, 348), (350, 386), (520, 354), (800, 381)], 3)
        if self.world[0] in (0, 1, 14) and self.world[1] in (3, 4, 5):
            for rx, ry in ((80, 300), (120, 330), (160, 287)):
                ridge = [(rx, ry + 48), (rx + 5, ry + 14), (rx + 22, ry), (rx + 37, ry + 19), (rx + 42, ry + 48)]
                pygame.draw.polygon(screen, (126, 120, 107), ridge)
                pygame.draw.line(screen, (157, 150, 136), (rx + 22, ry + 4), (rx + 30, ry + 33), 3)
        if self.world == (7, 5):
            # Stone walls close the settlement on three sides; the northern gate is open.
            pygame.draw.rect(screen, (145, 119, 82), (0, 360, WIDTH, 60))
            pygame.draw.rect(screen, (174, 147, 105), (375, HUD_H, 52, HEIGHT - HUD_H))
            for px in range(18, WIDTH, 38):
                pygame.draw.rect(screen, (202, 180, 137), (px, 388, 15, 3))
            for py in range(HUD_H + 18, HEIGHT, 38):
                pygame.draw.rect(screen, (202, 180, 137), (399, py, 3, 14))
            for rect, title, wall, roof in TOWN_BUILDINGS:
                self.draw_town_building(rect, title, wall, roof)
            pygame.draw.rect(screen, (81, 84, 85), (354, HUD_H - 4, 25, 48))
            pygame.draw.rect(screen, (81, 84, 85), (421, HUD_H - 4, 25, 48))
            pygame.draw.rect(screen, (116, 84, 52), (379, HUD_H + 3, 42, 35))
            pygame.draw.rect(screen, (191, 155, 99), (379, HUD_H + 3, 42, 35), 3)
            self.center_text("北門", 400, 32, SMALL, GOLD)
            # Open stone well at the plaza; the center remains walkable.
            pygame.draw.ellipse(screen, (67, 72, 70), (430, 458, 52, 22))
            pygame.draw.ellipse(screen, (128, 133, 124), (430, 454, 52, 20))
            pygame.draw.ellipse(screen, (35, 70, 86), (437, 458, 38, 12))
            pygame.draw.rect(screen, (95, 68, 44), (437, 445, 4, 11))
            pygame.draw.rect(screen, (95, 68, 44), (471, 445, 4, 11))
            pygame.draw.line(screen, (83, 58, 39), (434, 444), (478, 444), 4)
            self.label("きさらぎ町", 365, 428, WHITE)
        if self.world == (7, 4):
            pygame.draw.rect(screen, (89, 69, 48), (330, 270, 80, 90), 5)
            self.label("地図保管庫", 321, 365, GOLD)

    def draw_roofs(self):
        ox, oy = self.chunk_offset((7, 5))
        for index, (building, _, _, roof) in enumerate(TOWN_BUILDINGS):
            if index not in self.roof_cache:
                self.roof_cache[index] = self.make_roof(building.width, roof)
            layer = self.roof_cache[index]
            bounds = layer.get_rect(topleft=(ox+building.left-10, oy+building.top-15))
            behind = self.player.bottom <= oy+building.top+8 and self.player.colliderect(bounds.inflate(10, 64))
            layer.set_alpha(85 if behind else 255)
            screen.blit(layer, self.to_screen_point(*bounds.topleft))

    def make_roof(self, width, roof):
        surface = pygame.Surface((width+24, 52), pygame.SRCALPHA)
        rect = pygame.Rect(10, 15, width, 1)
        roof_points = [(rect.left - 9, rect.top + 19), (rect.centerx, rect.top - 14),
                       (rect.right + 9, rect.top + 19), (rect.right + 3, rect.top + 30),
                       (rect.centerx, rect.top + 1), (rect.left - 3, rect.top + 30)]
        pygame.draw.polygon(surface, (42, 39, 40), [(x + 3, y + 3) for x, y in roof_points])
        pygame.draw.polygon(surface, roof, roof_points)
        pygame.draw.lines(surface, (215, 183, 128), False, [roof_points[0], roof_points[1], roof_points[2]], 3)
        for row_y in (rect.top + 13, rect.top + 21):
            pygame.draw.line(surface, (76, 57, 48), (rect.left + 10, row_y), (rect.right - 10, row_y), 2)
        return surface

    def draw_town_building(self, rect, title, wall, roof):
        # Pixel-like layered house shapes, drawn directly by the game.
        shadow = rect.move(5, 7)
        pygame.draw.rect(screen, (47, 47, 41), shadow)
        pygame.draw.rect(screen, wall, rect)
        for beam in (rect.left+4, rect.right-8):
            pygame.draw.rect(screen,(83,61,50),(beam,rect.top+23,5,rect.height-23))
        pygame.draw.rect(screen,(111,102,85),(rect.left,rect.bottom-9,rect.width,9))
        for sx in range(rect.left+7,rect.right-2,17):
            pygame.draw.line(screen,(79,76,66),(sx,rect.bottom-8),(sx,rect.bottom-2),2)
        pygame.draw.rect(screen, (67, 47, 38), (rect.centerx - 11, rect.bottom - 36, 22, 36))
        pygame.draw.rect(screen, (163, 119, 71), (rect.centerx - 8, rect.bottom - 33, 16, 33))
        for stripe in (-5,0,5):
            pygame.draw.line(screen,(121,84,59),(rect.centerx+stripe,rect.bottom-32),(rect.centerx+stripe,rect.bottom-2))
        pygame.draw.circle(screen, GOLD, (rect.centerx + 5, rect.bottom - 17), 2)
        for wx in (rect.left + 18, rect.right - 38):
            pygame.draw.rect(screen, (60, 47, 39), (wx - 2, rect.top + 43, 24, 22))
            pygame.draw.rect(screen, (106, 157, 169), (wx, rect.top + 45, 20, 18))
            pygame.draw.line(screen, (231, 215, 174), (wx + 10, rect.top + 45), (wx + 10, rect.top + 63), 2)
            pygame.draw.line(screen, (231, 215, 174), (wx, rect.top + 54), (wx + 20, rect.top + 54), 2)
        pygame.draw.rect(screen, (73, 52, 38), (rect.centerx - 34, rect.top + 34, 68, 16))
        self.center_text(title, rect.centerx, rect.top + 42, SMALL, GOLD)
        self.center_text("入口", rect.centerx, rect.bottom + 9, SMALL, WHITE)

    def draw_npc(self, npc):
        # NPCs are assembled on a tiny pixel canvas so they match the hero's sprite style.
        x, y = self.to_screen_point(npc["x"], npc["y"])
        role = {"国王":"king","村長":"elder","駅馬車":"traveler","港守":"traveler"}.get(npc["name"],npc.get("role",""))
        if role=="map_traveler":
            role="traveler"
        stride,face=self.npc_poses.get((npc["name"],npc["x"],npc["y"]),(0,0))
        cache_key = (npc["coat"], npc["hair"], npc["skin"], role,stride,face)
        if cache_key not in NPC_SPRITE_CACHE:
            NPC_SPRITE_CACHE[cache_key] = citizen(*cache_key)
        sprite = NPC_SPRITE_CACHE[cache_key]
        screen.blit(sprite, sprite.get_rect(midbottom=(x, y + 4)))
        if npc.get("role") == "guard":
            if npc.get("weapon") == "spear":
                pygame.draw.line(screen, (116, 81, 49), (x - 10, y - 6), (x - 14, y - 34), 3)
                pygame.draw.polygon(screen, (216, 224, 224),
                                    [(x - 14, y - 38), (x - 18, y - 31), (x - 11, y - 32)])
            else:
                pygame.draw.line(screen, (123, 82, 48), (x + 7, y - 9), (x + 16, y - 28), 3)
                pygame.draw.line(screen, (224, 230, 231), (x + 11, y - 22), (x + 20, y - 18), 2)
        self.label(npc["name"], x - 24, y - 40, WHITE)

    def enemy_pose(self, enemy):
        cache_key = (enemy.kind, enemy.color, enemy.boss_id,enemy.slime_count)
        if cache_key not in ENEMY_SPRITE_CACHE:
            size = (64 if enemy.boss_id==5 else 52) if enemy.kind == "boss" else 32
            size+=10*(enemy.slime_count-1)
            sprite = pygame.transform.scale(build_enemy_sprite(*cache_key[:3]), (size,size))
            crouch = pygame.transform.scale(sprite,(size*9//8,size*25//32)) if enemy.kind=="slime" else None
            ENEMY_SPRITE_CACHE[cache_key] = sprite,crouch
        sprite,crouch = ENEMY_SPRITE_CACHE[cache_key]
        ex, ey = enemy.x, enemy.y
        rect = sprite.get_rect(midbottom=(round(ex + 12), round(ey + 28)))
        if enemy.kind == "slime":
            foot = rect.midbottom

            if enemy.hop_left > SLIME_AIR_TIME:
                sprite = crouch
                rect = sprite.get_rect(midbottom=foot)
            elif enemy.hop_left > 0:
                progress = 1 - enemy.hop_left / SLIME_AIR_TIME
                height = 36 if enemy.hop_target else 22
                rect.y -= round(height * 4 * progress * (1-progress))
        return sprite,rect

    def draw_enemy(self, enemy):
        sprite,world=self.enemy_pose(enemy)
        rect=self.to_screen_rect(world)
        boss_pose=enemy.kind=="boss" and self.interior in tide.CELLS
        if boss_pose:
            index=tide.CELLS[self.interior][0]%12
            h=tide.art.current_attack(self,enemy)
            view=enemy.facing_octant
            if h and h["kind"]=="melee" and not enemy.walking_boss:
                dx,dy=h["x"]-enemy.x-12,h["y"]-enemy.y-12
                if abs(dx)+abs(dy)>2:view=tide.art.heading(dx,dy)
            stride=(0,1,0,-1)[int(enemy.stride_distance//7)%4] if enemy.walking_boss else 0
            sprite=tide.art.armor(index,view,stride)
            rect=sprite.get_rect(midbottom=rect.midbottom)
        else:
            tell=tide.art.attack_pose(self,enemy,sprite,rect)
            if tell:sprite,rect=tell
        if enemy.kind=="slime":
            x,y=self.to_screen_point(enemy.x+12,enemy.y+28)
            width=24+8*(enemy.slime_count-1)
            pygame.draw.ellipse(screen,(42,64,41),(x-width//2,y-5,width,5+enemy.slime_count-1))
        if enemy.weakness_flash>0:
            self.center_text("弱点！",rect.centerx,rect.top-30,SMALL,(255,217,130))
        elif enemy.exposed>0:
            self.center_text("反撃！",rect.centerx,rect.top-30,SMALL,GOLD)
        elif enemy.boss_id == 5:
            stage = demon_phase(enemy)
            color = ((166,99,164),(203,90,227),(255,108,65))[stage-1]
            for i in range(3+stage):
                angle = pygame.time.get_ticks()*.002 + i*math.tau/(3+stage)
                spark = (round(rect.centerx+28*math.cos(angle)), round(rect.centery+17*math.sin(angle)))
                pygame.draw.circle(screen,color,spark,2+stage)
            self.center_text(("黒冠","裂影","終焔")[stage-1], rect.centerx, rect.top-30, SMALL, color)
        screen.blit(sprite, rect)
        if boss_pose:tide.art.draw_boss_sword(screen,rect,view,h)
        if enemy.burn_ticks:
            for i in range(3):
                x=rect.left+8+i*8
                y=rect.bottom-2
                h=8+round(5*math.sin(i+pygame.time.get_ticks()*.017))
                pygame.draw.polygon(screen,(255,135,46),[(x-4,y),(x+1,y-h),(x+4,y)])
        if enemy.stun>0:
            for i in range(3):
                angle=pygame.time.get_ticks()*.007+i*math.tau/3
                pygame.draw.circle(screen,GOLD,(rect.centerx+round(12*math.cos(angle)),rect.top-4+round(3*math.sin(angle))),2)
        if enemy.hurt > 0:
            pygame.draw.rect(screen, GOLD, rect.inflate(3, 3), 2)
        if enemy.kind == "boss" and 0 <= enemy.boss_id < len(BOSSES):
            name = REALMS[int(self.interior[-1])-1][3] if self.interior and self.interior.startswith("keep") else BOSSES[enemy.boss_id]["name"]
            if self.interior in tide.CELLS:name=tide.boss_name(tide.CELLS[self.interior][0])
            elif self.interior==wastes.THRONE:name=wastes.FINAL
            elif self.interior in wastes.CELLS:name=wastes.REGIONS[wastes.CELLS[self.interior][0]][10]
            if enemy.captain>=0:
                name=f"四天王 {enemy.captain+1}/4　"+CAPTAINS[self.arena_index()][enemy.captain]
            self.center_text(name, rect.centerx, rect.top - 12, SMALL, WHITE)
            bar = pygame.Rect(rect.centerx - 24, rect.top - 5, 48, 5)
            pygame.draw.rect(screen, INK, bar)
            fill_w = round(bar.width * max(0, enemy.hp) / max(1, enemy.max_hp))
            pygame.draw.rect(screen, RED, (bar.x, bar.y, fill_w, bar.height))
            pygame.draw.rect(screen, WHITE, bar, 1)

    def draw_effects(self):
        for effect in self.effects:
            x, y = self.to_screen_point(effect["x"], effect["y"])
            fade = max(0.0, 1.0 - effect["age"] / effect["life"])
            if effect["kind"]=="parry":
                spread=round(9+34*(1-fade))
                pygame.draw.circle(screen,(int(245*fade),int(211*fade),int(132*fade)),(x,y),spread,2)
                for j in range(8):
                    a=j*math.tau/8+.16
                    u,v=math.cos(a),math.sin(a)
                    pygame.draw.line(screen,(255,244,180),(x+u*spread,y+v*spread),(x+u*(spread+14*fade),y+v*(spread+14*fade)),2)
            elif effect["kind"] == "guard_melee":
                tx, ty = self.to_screen_point(effect["tx"], effect["ty"])
                pygame.draw.line(screen, (180, 146, 90), (x,y), (tx,ty), 3)
                if effect.get("weapon") == "spear":
                    pygame.draw.line(screen, WHITE, ((x+tx)//2,(y+ty)//2), (tx,ty), 2)
                else:
                    pygame.draw.arc(screen,effect["color"],pygame.Rect(tx-12,ty-16,24,24),.1,2.9,3)
            elif effect["kind"] == "lightning":
                points = [(x - 4, y - 54), (x + 5, y - 39), (x - 3, y - 25),
                          (x + 5, y - 12), (x, y + 1)]
                pygame.draw.lines(screen, effect["color"], False, points, 4)
                for i in (1, 3):
                    ax, ay = points[i]
                    sign = 1 if i == 1 else -1
                    pygame.draw.lines(screen, (108, 168, 255), False,
                                      [(ax, ay), (ax + sign*12, ay+4), (ax + sign*18, ay+15)], 2)
                pygame.draw.lines(screen, WHITE, False, points, 1)
                pygame.draw.circle(screen, (180, 231, 255), (x, y), max(3, round(12 * fade)), 2)
            elif effect["kind"] == "wind":
                for band in range(0, 4, 1 if self.rich_effects else 2):
                    angle = effect["age"] * 8 + band * math.pi / 2
                    spiral = []
                    for step in range(14):
                        r = (12 + step * 6) * (1.3 - fade)
                        a = angle + step * .11
                        spiral.append((round(x+r*math.cos(a)), round(y+r*math.sin(a)*.65)))
                    pygame.draw.lines(screen, (156, 230, 215), False, spiral, 2)
                radius=effect["radius"]
                pygame.draw.circle(screen,effect["color"],(x,y),radius,1)
                pygame.draw.circle(screen,WHITE,(x,y),max(2,round(radius*(1-fade))),2)
            else:
                kind = effect["kind"]
                progress = 1 - fade
                spread = {"explosion": effect.get("spread",110), "death": 30, "guard": 24, "heal": 28, "blink": 35}.get(kind, 13)
                radius = max(2, round(spread * (1 - fade * fade)))
                rim = tuple(round(channel * (.35 + .65 * fade)) for channel in effect["color"])
                if kind=="explosion":
                    pygame.draw.circle(screen,rim,(x,y),spread,1)
                    pygame.draw.circle(screen,rim,(x,y),radius,2)
                else:
                    pygame.draw.ellipse(screen, rim, (x-radius, y-radius//2, radius*2, radius), 2)
                if kind == "explosion":
                    pygame.draw.circle(screen, (255, 218, 123), (x, y), max(2, round(24*fade)), 3)
                base = effect["color"]
                color = tuple(max(0, min(255, round(channel * fade))) for channel in base)
                for particle in effect["particles"]:
                    px, py = self.to_screen_point(particle[0], particle[1])
                    radius = max(1, round(particle[4] * fade))
                    if kind == "heal":
                        py -= round(progress * 26)
                        pygame.draw.line(screen, WHITE, (px-3, py), (px+3, py), 2)
                        pygame.draw.line(screen, WHITE, (px, py-3), (px, py+3), 2)
                    else:
                        tail = (round(px-particle[2]*.06), round(py-particle[3]*.06))
                        pygame.draw.line(screen, rim, tail, (px, py), max(1, radius))
                    pygame.draw.rect(screen, color, (px - radius, py - radius, radius * 2, radius * 2))

    def draw_player(self):
        blinking = self.invulnerable and int(self.invulnerable * 14) % 2
        r = self.to_screen_rect(self.player) if self.room is None else self.player
        if self.jump_timer > 0:
            progress = 1 - self.jump_timer / .48
            lift = round(math.sin(progress * math.pi) * 23)
            shadow_x, shadow_y = self.to_screen_point(self.player.centerx, self.player.bottom - 1)
            pygame.draw.ellipse(screen, (32, 39, 31), (shadow_x - 10, shadow_y - 3, 20, 7))
            r = r.move(0, -lift)
        dx, dy = self.direction
        facing = {
            (0, 1): "down", (1, 1): "down_right", (1, 0): "right",
            (1, -1): "up_right", (0, -1): "up", (-1, -1): "up_left",
            (-1, 0): "left", (-1, 1): "down_left",
        }.get((dx, dy), "down")
        walk_sequence = (0, 1, 2, 1)
        frame = walk_sequence[int(self.walk_time / (.085 if self.running else .13)) % len(walk_sequence)] if self.walking else 1
        sprite = running_sprite(facing,frame) if self.running else HERO_SPRITES[facing][frame]
        sprite_rect = sprite.get_rect(midbottom=(r.centerx, r.bottom + 4))
        if self.shield_equipped:
            self.draw_shield(facing, r)
        # Gear behind the hero when it points away, in front when it points toward us.
        if facing in ("up", "up_left", "up_right"):
            self.draw_held_weapon(facing, r)
        if not blinking:
            screen.blit(sprite, sprite_rect)
        self.center_text(self.player_name, r.centerx, sprite_rect.top - 8, SMALL, GOLD)
        if facing not in ("up", "up_left", "up_right"):
            self.draw_held_weapon(facing, r)
    def draw_shield(self, facing, r):
        cx, cy = r.center
        # Keep the shield beside the body, on the side opposite the weapon hand.
        vx, vy = {"right": (1, 0), "down_right": (1, 1), "down": (0, 1),
                  "down_left": (-1, 1), "left": (-1, 0), "up_left": (-1, -1),
                  "up": (0, -1), "up_right": (1, -1)}[facing]
        sx = cx - (12 if vx > 0 else -12 if vx < 0 else (12 if facing == "up" else -12))
        sy = cy + 4
        pts = [(sx, sy - 8), (sx + 6, sy - 5), (sx + 5, sy + 3), (sx, sy + 9),
               (sx - 5, sy + 3), (sx - 6, sy - 5)]
        pygame.draw.polygon(screen, (91, 61, 43), pts)
        pygame.draw.polygon(screen, (195, 156, 87), pts, 1)
        pygame.draw.line(screen, (217, 196, 139), (sx, sy - 5), (sx, sy + 5), 1)

    def draw_held_weapon(self, facing, r):
        if self.attack_timer>0:
            image,_,offset=self.strike_layer()
            screen.blit(image,offset.move(r.centerx,r.centery))
        else:
            self.paint_weapon(facing,r,screen)

    def paint_weapon(self,facing,r,surface):
        burning=self.attack_flaming if self.attack_timer>0 else self.flame_timer>0
        weapon = self.attack_weapon if self.attack_timer > 0 else self.weapon
        if weapon == "none":
            return
        cx, cy = r.center
        diagonal = .7071
        vectors = {
            "right": (1, 0), "down_right": (diagonal, diagonal), "down": (0, 1),
            "down_left": (-diagonal, diagonal), "left": (-1, 0),
            "up_left": (-diagonal, -diagonal), "up": (0, -1),
            "up_right": (diagonal, -diagonal),
        }
        attack_names = {
            (0, 1): "down", (1, 1): "down_right", (1, 0): "right",
            (1, -1): "up_right", (0, -1): "up", (-1, -1): "up_left",
            (-1, 0): "left", (-1, 1): "down_left",
        }
        gear_facing = attack_names.get(self.attack_direction, facing) if self.attack_timer > 0 else facing
        vx, vy = vectors[gear_facing]
        hand_offsets = {
            # Anchor the grip at the outside hand and lower than the face.
            "right": (7, 9), "down_right": (7, 8), "down": (6, 9),
            "down_left": (-7, 8), "left": (-7, 9), "up_left": (-7, -2),
            "up": (-7, -2), "up_right": (7, -2),
        }
        hx, hy = round(cx + hand_offsets[gear_facing][0]), round(cy + hand_offsets[gear_facing][1])
        if self.running:
            hx += self.direction[0]*3
            hy += 2+self.direction[1]
        point = lambda x, y: (round(x), round(y))
        if weapon=="bow":
            bow.draw_bow(surface,hx,hy,vx,vy,self.attack_timer)
            return
        if weapon == "sword":
            if self.attack_timer > 0 and self.attack_weapon == "sword":
                progress = 1 - self.attack_timer / .32
                angle = -1.05 + 2.1 * progress
                vx, vy = vx * math.cos(angle) - vy * math.sin(angle), vx * math.sin(angle) + vy * math.cos(angle)
                blade_angle=math.atan2(vy,vx)
                radius=52+self.weapon_level*2 if not burning else 108
                def blade_point(angle,length):
                    return point(hx+length*math.cos(angle),hy+length*math.sin(angle))
                ribbon=[blade_point(blade_angle,18),blade_point(blade_angle,radius)]
                ribbon.extend(blade_point(blade_angle-k*.075,radius-k) for k in range(1,8))
                pygame.draw.polygon(surface,(232,109,47) if burning else (136,177,191),ribbon)
                for length, width, color in ((radius,3,(255,153,57) if burning else (160,202,217)),
                                              (radius-4,2,(255,225,153) if burning else WHITE)):
                    points=[point(hx+length*math.cos(blade_angle-k*.075),
                                  hy+length*math.sin(blade_angle-k*.075)) for k in range(8)]
                    pygame.draw.lines(surface,color,False,points,width)
            start = point(hx + vx * 5, hy + vy * 5)
            tip = point(hx + vx * 19, hy + vy * 19)
            guard = point(hx - vy * 3, hy + vx * 3)
            guard2 = point(hx + vy * 3, hy - vx * 3)
            pygame.draw.line(surface, (126, 82, 48), point(hx - vx * 3, hy - vy * 3), start, 2)
            pygame.draw.line(surface, GOLD, guard, guard2, 2)
            pygame.draw.line(surface, (221, 231, 239), start, tip, 2)
            pygame.draw.line(surface, WHITE, start, tip, 1)
        elif weapon == "spear":
            thrust = 0
            if self.attack_timer > 0 and self.attack_weapon == "spear":
                progress = 1 - self.attack_timer / .32
                thrust = round(13 * math.sin(progress * math.pi))
                reach = 24+thrust+(46 if burning else 12)
                for side in (-3,0,3):
                    offset = abs(side)*2
                    start_fx=point(hx+vx*(20+thrust)-vy*side,hy+vy*(20+thrust)+vx*side)
                    end_fx=point(hx+vx*(reach-offset)-vy*side,hy+vy*(reach-offset)+vx*side)
                    pygame.draw.line(surface,(255,178,72) if burning else (195,225,235),start_fx,end_fx,2)
            start = point(hx - vx * 9, hy - vy * 9)
            tip = point(hx + vx * (24 + thrust), hy + vy * (24 + thrust))
            pygame.draw.line(surface, (133, 83, 48), start, tip, 2)
            base = (hx + vx * (18 + thrust), hy + vy * (18 + thrust))
            left = point(base[0] - vy * 3, base[1] + vx * 3)
            right = point(base[0] + vy * 3, base[1] - vx * 3)
            pygame.draw.polygon(surface, (218, 228, 235), [tip, left, right])
        if burning:
            flame_x = round(hx + vx * (24+thrust if weapon == "spear" else 18))
            flame_y = round(hy + vy * (24+thrust if weapon == "spear" else 18))
            flicker = round(math.sin(self.walk_time * 25) * 2)
            pygame.draw.circle(surface, (219, 67, 36), (flame_x, flame_y), 6 + flicker)
            pygame.draw.circle(surface, (255, 176, 62), (flame_x, flame_y), 3 + flicker // 2)
            pygame.draw.circle(surface, (255, 237, 173), (flame_x, flame_y), 1)

    def draw_hud(self):
        pygame.draw.rect(screen, (26, 29, 34), (0, 0, WIDTH, HUD_H))
        if self.autosave_notice > 0:
            pygame.draw.rect(screen, (30, 43, 40), (WIDTH-122, HUD_H+6, 116, 24), border_radius=4)
            self.label("自動セーブ済み", WIDTH-116, HUD_H+9, (169, 230, 182))
        self.label(self.room_name()+("　"+life.period(self) if self.interior=="capital" else ""), 10, 10, WHITE)
        self.label("♥" * self.hp + "♡" * (self.max_hp - self.hp), 405, 10, RED)
        self.label(f"◆{self.rupees} 鍵{self.keys} 爆{self.bombs} 薬{self.potions}", 585, 10, GOLD)
        self.label(f"航海 {tide.voyage(self)}/182", 10, HEIGHT - 26, GOLD)
        weapon_name = {"none": "素手", "sword": "剣", "spear": "槍", "bow":"弓"}[self.weapon]
        shield_name = "盾なし"
        if self.shield_equipped:
            now=monotonic()
            if now-self.last_guard<=.25:
                shield_name="盾 構え"
            elif now<self.guard_ready:
                shield_name=f"盾 P {self.guard_ready-now:.1f}秒"
            else:
                shield_name="盾 P"
        self.label(f"装備 {weapon_name} R/T/.・{shield_name} ,", 105, HEIGHT - 26, WHITE)
        powers = ("heal", "lightning", "flame", "wind", "earth")
        power_marks = " ".join(f"{POWER_LABELS[power]}{POWER_NAMES[power][0] if power in self.abilities else '－'}"
                                for power in powers)
        self.label("力 " + power_marks, 335, HEIGHT - 26, (190, 225, 239))
        if self.map_obtained:
            self.label("地図 /", 555, HEIGHT - 26, GOLD)
        if self.weapon_level:
            self.label(f"強化 +{self.weapon_level}", 630, HEIGHT - 26, GOLD)
        self.label(f"第{min(26,tide.voyage(self)//7+1)}章", 690, HEIGHT - 26, WHITE)

    def label(self, text, x, y, color):
        screen.blit(rendered_text(SMALL, text, color), (x, y))

    def center_text(self, text, x, y, font, color):
        surf = rendered_text(font, text, color)
        screen.blit(surf, surf.get_rect(center=(x, y)))

    def overlay(self, title, subtitle):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((10, 12, 18, 200))
        screen.blit(veil, (0, 0))
        self.center_text(title, WIDTH // 2, HEIGHT // 2 - 25, BIG, GOLD)
        self.center_text(subtitle, WIDTH // 2, HEIGHT // 2 + 25, FONT, WHITE)


DUNGEON_NAMES = ["根脈の洞穴", "古い熔炉", "水没した駅", "高原の天文台", "嵐の書庫"]
DUNGEON_ENTRANCES = [(2, 2), (12, 2), (2, 7), (12, 7), (7, 8)]
INTERIOR_NAMES = {"inn": "宿屋", "home_north": "民家", "home_south": "民家", "home_east": "民家",
                  "home_west": "民家", "home_southwest": "民家", "shop": "道具屋", "blacksmith": "鍛冶屋"}
TOWN_BUILDINGS = [
    (pygame.Rect(58, 132, 166, 122), "宿屋", (151, 104, 69), (130, 65, 51)),
    (pygame.Rect(260, 142, 112, 91), "民家", (174, 138, 91), (102, 83, 68)),
    (pygame.Rect(478, 135, 151, 112), "道具屋", (158, 121, 78), (85, 94, 110)),
    (pygame.Rect(76, 440, 128, 84), "民家", (160, 126, 88), (113, 72, 55)),
    (pygame.Rect(590, 442, 148, 88), "鍛冶屋", (135, 112, 87), (91, 78, 69)),
    (pygame.Rect(238, 298, 105, 78), "民家", (164, 132, 91), (100, 82, 71)),
    (pygame.Rect(458, 298, 105, 78), "民家", (154, 120, 84), (120, 76, 62)),
    (pygame.Rect(238, 440, 105, 82), "民家", (168, 136, 95), (105, 86, 69)),
]

# NPC figures are drawn from polygons, circles, and lines in draw_npcs().
NPCS = {
    (7, 5): [
        {"name": "槍の門番", "role": "guard", "x": 350, "y": 105,
         "weapon": "spear",
         "coat": (91, 98, 102), "hair": (53, 49, 45), "skin": (205, 158, 121),
         "dialogue": "槍の門番：北門に近づく魔物は、槍で追い払う。"},
        {"name": "剣の門番", "role": "guard", "x": 450, "y": 105,
         "weapon": "sword",
         "coat": (91, 98, 102), "hair": (53, 49, 45), "skin": (205, 158, 121),
         "dialogue": "剣の門番：北門から町に入れる。町の建物も使ってくれ。"},
        {"name": "ミラ", "x": 350, "y": 410, "coat": (89, 124, 105), "hair": (77, 51, 39), "skin": (220, 177, 137),
         "dialogue": "ミラ：嵐で5つの地図の欠片が散らばったの。すべて集めて保管庫へ届けて。"},
        {"name": "トウマ", "x": 500, "y": 410, "coat": (138, 91, 66), "hair": (47, 43, 38), "skin": (188, 132, 97),
         "dialogue": "トウマ：古い道は草や石に隠れているよ。道しるべを見逃さないで。"},
        {"name": "旅人", "role": "map_traveler", "x": 410, "y": 300,
         "coat": (91, 105, 137), "hair": (55, 48, 44), "skin": (211, 169, 128),
         "dialogue": "歩いた場所を地図に記録する。"},
    ],
    (3, 5): [
        {"name": "リン", "x": 460, "y": 300, "coat": (93, 117, 137), "hair": (90, 58, 40), "skin": (225, 190, 153),
         "dialogue": "リン：西の尾根で壊れた羅針盤を見かけたよ。"},
    ],
    (10, 5): [
        {"name": "オド", "x": 350, "y": 350, "coat": (150, 118, 68), "hair": (70, 70, 67), "skin": (201, 158, 116),
         "dialogue": "オド：水没した駅の入口は南東のどこかにある。"},
    ],
    (5, 2): [
        {"name": "セラ", "x": 520, "y": 250, "coat": (119, 83, 131), "hair": (46, 39, 37), "skin": (229, 190, 159),
         "dialogue": "セラ：天文台の屋根は、今も北の古道を指しているよ。"},
    ],
}


def main():
    if not terms.read() and not terms.dialog(screen,FONT,SMALL):
        pygame.quit()
        return
    session = None
    guard_down = False
    film=Prologue()
    game = Ashvale()
    running = True
    while running:
        dt = min(clock.tick(FPS) / 1000, .05)
        for event in pygame.event.get():
            if event.type == pygame.WINDOWFOCUSLOST or (event.type == pygame.KEYUP and event.key == pygame.K_p):
                guard_down = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                if guard_down or getattr(event, "repeat", False):
                    continue
                guard_down = True
            if event.type == pygame.QUIT:
                running = False
            elif film.active:
                if event.type==pygame.KEYDOWN:
                    if event.key==pygame.K_ESCAPE:film.cut(len(CAPTIONS))
                    elif event.key in (pygame.K_RETURN,pygame.K_KP_ENTER):film.cut(film.index+1)
                continue
            elif event.type == pygame.TEXTINPUT and game.name_editing:
                game.name_buffer = (game.name_buffer + event.text)[:12]
            elif event.type == pygame.KEYDOWN:
                if game.home_screen:
                    if event.key==pygame.K_F1:
                        running=terms.dialog(screen,FONT,SMALL,review=True)
                    elif event.key==pygame.K_v and not game.home_help:
                        film.start(RESOURCE_DIR)
                    elif game.home_help:
                        if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
                            game.home_help = False
                    elif event.key in (pygame.K_UP, pygame.K_w):
                        game.home_selection = (game.home_selection - 1) % 6
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        game.home_selection = (game.home_selection + 1) % 6
                    elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        if game.home_selection == 0:
                            game = Ashvale()
                            game.home_screen = False
                            game.name_editing = True
                            game.initial_name_prompt = True
                            game.name_buffer = ""
                            pygame.key.start_text_input()
                        elif game.home_selection == 1 and SAVE_PATH.exists():
                            if game.load_game(silent=True):
                                game.home_screen = False
                        elif game.home_selection == 2:
                            game.home_help = True
                        elif game.home_selection == 3:
                            running = lan_duel.run(screen, FONT, HERO_SPRITES)
                        elif game.home_selection == 4:
                            running = story_link.join(screen,FONT)
                        elif game.home_selection == 5:
                            running = False
                    elif event.key == pygame.K_ESCAPE:
                        running = False
                    continue
                if game.name_editing:
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        game.player_name = game.name_buffer.strip() or "旅人"
                        game.name_editing = False
                        game.initial_name_prompt = False
                        pygame.key.stop_text_input()
                        game.tell("ミオの雨瓶に明日の雨が入っていた。左の武器箱で装備を受け取ろう。",8)
                        game.apply_1018_bonus()
                        film.start(RESOURCE_DIR)
                    elif event.key == pygame.K_BACKSPACE:
                        game.name_buffer = game.name_buffer[:-1]
                    elif event.key == pygame.K_ESCAPE:
                        game.name_editing = False
                        if game.initial_name_prompt:
                            game.home_screen = True
                            game.initial_name_prompt = False
                            game.name_buffer = ""
                        pygame.key.stop_text_input()
                    continue
                if game.seal_open:
                    game.seal_input(event.key)
                    continue
                if game.ending_open and event.key in (pygame.K_RETURN,pygame.K_KP_ENTER):
                    game.ending_open=False
                    game.royal_travel("capital",CROWN_PLAZA)
                    game.last_clue=rift.objective(game.chapter_flags)
                    game.tell("境界遺跡は王城から西へ三地区。国王に話せば馬車も借りられる。",7)
                    continue
                if game.warp_open:
                    if event.key == pygame.K_ESCAPE:
                        game.warp_open = False
                    elif event.key in (pygame.K_LEFT, pygame.K_a):
                        game.move_warp_cursor(-1, 0)
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        game.move_warp_cursor(1, 0)
                    elif event.key in (pygame.K_UP, pygame.K_w):
                        game.move_warp_cursor(0, -1)
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        game.move_warp_cursor(0, 1)
                    elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        game.warp_to_cursor()
                    continue
                if event.key == pygame.K_ESCAPE:
                    if game.inventory_open:
                        game.inventory_open = False
                    else:
                        running = False
                    continue
                if event.key == pygame.K_f:
                    game.rich_effects = not game.rich_effects
                    game.tell("エフェクト量：" + ("多め" if game.rich_effects else "標準"))
                    continue
                if event.key == pygame.K_F3:
                    if session:
                        session.close()
                        session = game.companion = None
                        game.tell("協力募集を終了しました。")
                    else:
                        session = story_link.StoryRoom()
                        try:
                            session.host()
                            game.tell("本編の仲間を募集中　"+session.local_ips+"　F3で終了",12)
                        except OSError:
                            session.close()
                            session = None
                            game.tell("協力部屋を開けませんでした。",5)
                    continue
                if event.key == pygame.K_F6:
                    try:
                        game.input_review.export(APP_DIR, getattr(sys, "frozen", False))
                        game.tell("戦闘記録をゲームのフォルダーに保存しました。", 5)
                    except OSError:
                        game.tell("戦闘記録を保存できません。フォルダーの書き込み権限を確認してください。", 5)
                    continue
                if event.key == pygame.K_F7:
                    game.tell(game.input_review.report(), 8)
                    continue
                if event.key == pygame.K_F8 and game.interior=="capital":
                    cell=((game.player.centerx+400)//800,(game.player.centery+280)//560)
                    if cell in CROWN_WARDS and not (game.game_over or game.ending_open):
                        game.map_open = game.inventory_open = False
                        game.royal_travel("capital", CROWN_PLAZA)
                        game.tell("王城前の広場に戻った。")
                    continue
                if event.key == pygame.K_F5:
                    game.save_game()
                    continue
                if event.key == pygame.K_F9:
                    game.load_game()
                    continue
                if event.key == KEY_BAG:
                    game.inventory_open = not game.inventory_open
                    if game.inventory_open:
                        game.map_open = False
                    continue
                if game.inventory_open:
                    if event.key==pygame.K_TAB:
                        game.journal_page=not game.journal_page
                    elif game.journal_page and event.key in (pygame.K_a,pygame.K_d,pygame.K_LEFT,pygame.K_RIGHT):
                        step=-1 if event.key in (pygame.K_a,pygame.K_LEFT) else 1
                        game.tracking=life.TRACKS[(life.TRACKS.index(game.tracking)+step)%len(life.TRACKS)]
                    elif game.journal_page and event.key in (pygame.K_w,pygame.K_UP,pygame.K_s,pygame.K_DOWN):
                        step=-1 if event.key in (pygame.K_w,pygame.K_UP) else 1
                        game.pinned=(game.pinned+step)%6
                    continue
                if event.key==pygame.K_p and not (game.map_open or game.ending_open):
                    if not getattr(event,"repeat",False):game.guard_press()
                    continue
                if game.game_over and game.retry_data and event.key==KEY_ATTACK:
                    game.retry_boss()
                    continue
                if game.game_over and game.inn_registered and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    game.revive_at_inn()
                    continue
                if event.key == pygame.K_r and (game.game_over or game.ending_open):
                    if session:
                        session.close()
                        session = None
                    game = Ashvale()
                    game.home_screen = False
                    game.name_editing = True
                    game.initial_name_prompt = True
                    game.name_buffer = ""
                    pygame.key.start_text_input()
                    continue
                if game.map_open and event.key != KEY_MAP:
                    continue
                if not game.game_over and not game.ending_open:
                    if event.key == KEY_ATTACK:
                        game.attack()
                    elif event.key in (KEY_BOMB, pygame.K_x):
                        game.place_bomb(heavy=bool(event.mod & pygame.KMOD_SHIFT))
                    elif event.key in (KEY_INTERACT, pygame.K_e):
                        game.try_interact()
                    elif event.key == KEY_MAP:
                        if game.map_obtained or game.interior in ROYAL or game.interior in rift.AREAS:
                            game.map_open = not game.map_open
                            if game.map_open:
                                game.inventory_open = False
                        else:
                            game.tell("地図はきさらぎ町の旅人から受け取れる。")
                    elif event.key in (KEY_WARP, pygame.K_v):
                        game.open_warp()
                    elif event.key in (KEY_SHUKUCHI, pygame.K_q):
                        game.shukuchi()
                    elif event.key in (pygame.K_SPACE, pygame.K_z):
                        game.jump()
                    elif event.key == KEY_DASH:
                        game.dash()
                    elif event.key in POWER_KEYS.values():
                        power = next(name for name, key in POWER_KEYS.items() if key == event.key)
                        game.request_power(power)
                    elif event.key==pygame.K_PERIOD:
                        if "bow" in game.owned_gear:
                            game.weapon="bow";game.tell("潮木の短弓を装備。Jで矢を射る。")
                        else:game.tell("泊地の武器箱で短弓を受け取ろう。")
                    elif event.key in (KEY_SWORD, KEY_SPEAR):
                        if game.interior == "shop":
                            stock=("heart_vessel","revival_feather") if event.mod & pygame.KMOD_SHIFT else ("potion","bomb")
                            game.buy_shop_item(stock[0] if event.key==KEY_SWORD else stock[1])
                        else:
                            gear = {KEY_SWORD: "sword", KEY_SPEAR: "spear"}[event.key]
                            if gear in game.owned_gear:
                                game.weapon = gear
                                game.tell("剣を装備した。" if gear == "sword" else "槍を装備した。")
                            else:
                                game.tell("まだ剣を見つけていない。" if gear == "sword" else "まだ槍を見つけていない。")
                    elif event.key == KEY_SHIELD:
                        if "shield" in game.owned_gear:
                            game.shield_equipped = not game.shield_equipped
                            game.tell("盾を装備した。武器はそのまま使える。" if game.shield_equipped else "盾をしまった。")
                        else:
                            game.tell("まだ盾を見つけていない。")
                    elif event.key in (KEY_POTION, pygame.K_c):
                        if event.mod & pygame.KMOD_SHIFT:
                            game.use_elixir()
                        elif game.potions > 0:
                            game.potions -= 1
                            game.hp = min(game.max_hp, game.hp + 3)
                            game.tell("薬を使った。体力が3回復した。")
        if film.active:
            film.draw(screen,FONT,SMALL,dt)
            continue
        if session:
            try:
                session.poll()
                if session.ready:
                    if game.companion is None:
                        game.companion = story_link.Companion()
                        game.tell("2Pが冒険に参加しました。",4)
                    game.companion.update(game,dt,session.remote_dir,session.remote_actions)
                    session.remote_actions = 0
            except OSError:
                session.close()
                session = game.companion = None
                game.tell("仲間が退出しました。冒険を続けられます。",4)
        game.update(dt, pygame.key.get_pressed())
        game.update_autosave(dt)
        audio.update(game)
        game.draw()
        if session:
            try:
                session.send_frame(screen)
            except OSError:
                session.close()
                session = game.companion = None
                game.tell("仲間との通信が終了しました。",4)
    if session:
        session.close()
    if not game.home_screen and not game.name_editing and not game.game_over:
        game.save_game(silent=True)
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
