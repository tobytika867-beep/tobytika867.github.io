"""王都東街区の遊技卓とギルド掲示板。"""
import math
import random

VENUES={"星灯カジノ":"casino","冒険者ギルド":"guild"}
WARDS={(2,0):"星灯街",(3,0):"東門街"}
ROOMS={value:key for key,value in VENUES.items()}
DOORS={"casino":(1600,-50),"guild":(2400,-50)}
STATIONS={"casino":(("丁の卓",235,255),("半の卓",565,255),("星輪の卓",400,390)),
          "guild":(("配達依頼",205,242),("測量依頼",400,242),("補給依頼",595,242))}
JOBS={"配達依頼":("letter","霞港の荷秤のハルに紹介状を届ける",14),
      "測量依頼":("survey","東門の先、東西4・南北0の道標を調べる",18),
      "補給依頼":("supply","薬を2個集めてこの掲示板に納める",16)}

def perform(game,site):
    if site in JOBS:
        job,task,reward=JOBS[site]
        flags=game.chapter_flags
        if job+"_paid" in flags:
            game.tell("依頼は達成済み。報酬は受け取りました。")
        elif job+"_taken" not in flags:
            flags.add(job+"_taken")
            game.tell(f"受注：{task}。報酬◆{reward}。",6)
        elif job+"_ready" in flags or (job=="supply" and game.potions>=2):
            if job=="supply":
                game.potions-=2
            game.rupees+=reward
            flags.add(job+"_paid")
            game.tell(f"依頼達成！ エメラルド{reward}個を受け取った。")
        else:
            game.tell("依頼中："+task+"。",5)
        return
    if game.rupees<2:
        game.tell("一回◆2。エメラルドが足りない。")
        return
    game.rupees-=2
    if site=="星輪の卓":
        face=random.choice(("星","月","帆","鳥","花","鍵"))
        prize=10 if face=="星" else 0
        line="星輪は「"+face+"」で止まった。"
    else:
        a,b=random.randint(1,6),random.randint(1,6)
        even=(a+b)%2==0
        prize=4 if even==(site=="丁の卓") else 0
        line=f"出目は{a}と{b}、合計{a+b}で"+("丁！" if even else "半！")
    game.rupees+=prize
    game.tell(line+(f" 払い戻し◆{prize}。" if prize else " 今回は外れ。"),5)

def nearby(game):
    site,x,y=min(STATIONS[game.interior],key=lambda p:math.dist(game.player.center,p[1:]))
    return site if math.dist(game.player.center,(x,y))<=61 else None

def draw(game,screen,font,pg):
    casino=game.interior=="casino"
    screen.fill((66,43,57) if casino else (82,69,53))
    for y in range(52,570,22):
        pg.draw.line(screen,(92,68,71) if casino else (101,86,66),(20,y),(780,y))
    pg.draw.rect(screen,(115,53,71) if casino else (62,89,77),(345,72,110,508))
    game.center_text(ROOMS[game.interior],400,93,font,(250,214,131))
    guide="一回◆2　丁＝偶数・半＝奇数で◆4　星輪は六面の星で◆10" if casino else "掲示板でEを押して受注。達成後は同じ掲示板で報告"
    game.center_text(guide,400,145,font,(238,219,190))
    for name,x,y in STATIONS[game.interior]:
        if casino:
            pg.draw.ellipse(screen,(179,145,85),(x-61,y-35,122,54))
            pg.draw.ellipse(screen,(50,104,92),(x-56,y-31,112,46))
            if name=="星輪の卓":
                pg.draw.circle(screen,(212,172,88),(x,y-10),17,3)
                for i in range(6):
                    a=math.tau*i/6
                    pg.draw.line(screen,(212,172,88),(x,y-10),(round(x+15*math.cos(a)),round(y-10+15*math.sin(a))))
            else:
                for offset in (-12,6):
                    pg.draw.rect(screen,(229,216,178),(x+offset,y-19,13,13))
                    pg.draw.circle(screen,(82,50,49),(x+offset+6,y-13),2)
        else:
            pg.draw.rect(screen,(93,60,42),(x-49,y-45,98,51))
            for offset in (-34,-10,14):
                pg.draw.rect(screen,(214,192,145),(x+offset,y-36,18,28))
            job=JOBS[name][0]
            name+= "（済）" if job+"_paid" in game.chapter_flags else "（受注中）" if job+"_taken" in game.chapter_flags else ""
        game.center_text(name,x,y+27,font,(241,221,178))
    game.center_text("南の出口",400,540,font,(231,202,149))
    if nearby(game):
        game.center_text("E　"+nearby(game),400,484,font,(255,214,111))
