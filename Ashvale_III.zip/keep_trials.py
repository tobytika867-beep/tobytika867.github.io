"""The six royal seals and the retinues sworn to defend them."""
from functools import reduce
from operator import xor

CAPTAINS = (
    ("灰門の盾伯", "影縫いの猟師", "黒冠の星読み", "奈落の執行官"),
    ("逆潮の水先人", "霧笛の銛手", "沈鐘の潜り手", "渦眼の提督"),
    ("炉床の番人", "赤錆の鋳手", "火花の槌使い", "熔鉱の工匠"),
    ("根道の守人", "茨弓の狩人", "花粉の祈祷師", "古樹の庭師"),
    ("低鐘の衛士", "音叉の射手", "鳴石の楽師", "雷鳴の指揮者"),
    ("薄月の渡守", "鏡面の射手", "星図の占師", "月蝕の司祭"),
)
ELEMENTS = ("meteor", "wind_blast", "fire_pillar", "root_burst", "quake", "meteor")
SEAL_NAMES = ("黒冠の印", "潮汐の灯", "鋳型の火", "根脈の芽", "鐘楼の響き", "星鏡の光")
# Each seal is scrambled by legal moves. Repeating a move cancels it.
SCRAMBLES = ((0,2,3,7), (1,3,4,6,8), (0,1,5,6,7), (0,2,3,4,7,8),
             (1,2,3,5,6,8), (0,1,3,4,5,6,8))
RULES = ("自分と上下左右", "自分と斜め四方", "自分と上下左右",
         "自分と斜め四方", "自分と上下左右", "自分と上下左右")

def linked_tiles(realm, tile):
    x, y = tile % 3, tile // 3
    diagonal = realm in (1, 3)
    offsets = ((1,1),(-1,1),(1,-1),(-1,-1)) if diagonal else ((0,1),(0,-1),(1,0),(-1,0))
    mask = 1 << tile
    for dx, dy in offsets:
        if 0 <= x+dx < 3 and 0 <= y+dy < 3:
            mask |= 1 << (3*(y+dy)+x+dx)
    return mask

def starting_board(realm):
    return reduce(xor, (linked_tiles(realm, tile) for tile in SCRAMBLES[realm]), 0)
