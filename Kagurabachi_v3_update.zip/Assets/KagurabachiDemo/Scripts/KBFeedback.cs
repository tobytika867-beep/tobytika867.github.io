using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace KBGame {
    // Feedback uses unscaled time so a hit pause never gets stuck.
    public class KBFeedback : MonoBehaviour {
        AudioSource audioSource; AudioClip[] clips; float freezeUntil, oldScale=1; bool frozen;
        void Awake(){audioSource=gameObject.AddComponent<AudioSource>();audioSource.playOnAwake=false;audioSource.spatialBlend=0;audioSource.volume=.68f;clips=new AudioClip[5];for(int i=0;i<5;i++)clips[i]=MakeClip(i);}
        public void Sound(int i,float volume=1){if(audioSource!=null&&clips!=null&&i>=0&&i<clips.Length)audioSource.PlayOneShot(clips[i],volume);}
        static AudioClip MakeClip(int type){int rate=22050;float dur=type==3?.34f:type==0?.19f:.16f;int n=(int)(rate*dur);float[] samples=new float[n];var rng=new System.Random(641+type);float low=0,phase=0;for(int i=0;i<n;i++){float t=i/(float)rate,u=t/dur;float noise=(float)rng.NextDouble()*2-1;low=low*.82f+noise*.18f;phase+=2*Mathf.PI*Mathf.Lerp(type==0?1600:type==3?210:110,type==0?450:48,u)/rate;float env=Mathf.Min(1,t/.008f)*Mathf.Pow(1-u,2);float val=type==0?(Mathf.Sin(phase)*.35f+(noise-low)*.42f):type==1?(noise-low)*.65f*Mathf.Sin(u*Mathf.PI):type==2?low*.72f+Mathf.Sin(phase)*.25f:type==3?Mathf.Sin(phase)*.45f+low*.75f:(noise-low)*.45f+Mathf.Sin(phase)*.35f;samples[i]=Mathf.Clamp(val*env,-1,1);}var clip=AudioClip.Create("KB effect "+type,n,1,rate,false);clip.SetData(samples,0);return clip;}
        public void Freeze(float seconds){if(!frozen){oldScale=Time.timeScale;if(oldScale<=0)return;frozen=true;Time.timeScale=oldScale*.08f;}freezeUntil=Mathf.Max(freezeUntil,Time.unscaledTime+seconds);}
        void Update(){if(frozen&&Time.unscaledTime>=freezeUntil)Restore();}
        void Restore(){if(frozen){Time.timeScale=oldScale;frozen=false;}}
        void OnDisable(){Restore();}
        void OnDestroy(){Restore();if(clips!=null)foreach(var c in clips)if(c!=null)Destroy(c);}
        public static void Burst(Vector3 point,Vector3 direction,Color color,int count,float life){var g=new GameObject("Impact particles");g.transform.position=point;var ps=g.AddComponent<ParticleSystem>();ps.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);var main=ps.main;main.loop=false;main.playOnAwake=false;main.duration=.1f;main.startLifetime=new ParticleSystem.MinMaxCurve(life*.45f,life);main.startSpeed=0;main.startSize=new ParticleSystem.MinMaxCurve(.025f,.085f);main.startColor=color;main.gravityModifier=.35f;main.simulationSpace=ParticleSystemSimulationSpace.World;main.maxParticles=count+2;
            var emission=ps.emission;emission.enabled=false;var shape=ps.shape;shape.enabled=false;var size=ps.sizeOverLifetime;size.enabled=true;size.size=new ParticleSystem.MinMaxCurve(1,new AnimationCurve(new Keyframe(0,1),new Keyframe(1,0)));var r=g.GetComponent<ParticleSystemRenderer>();var mat=KBVisuals.Glow(Color.white);r.sharedMaterial=mat;r.renderMode=ParticleSystemRenderMode.Billboard;r.shadowCastingMode=ShadowCastingMode.Off;g.AddComponent<KBTemporaryMaterial>().mat=mat;ps.Play();for(int i=0;i<count;i++){var ep=new ParticleSystem.EmitParams();ep.position=point+Random.insideUnitSphere*.055f;ep.velocity=(Random.insideUnitSphere*2.8f+direction.normalized*1.3f+Vector3.up*.55f)*(life>.4f?1.2f:.75f);ps.Emit(ep,1);}Destroy(g,life+.3f);}
        public static void Slash(Vector3 point,Quaternion rotation,int combo,Color color){var g=new GameObject("Animated slash crescent");g.transform.SetPositionAndRotation(point,rotation);g.AddComponent<KBSlashCrescent>().Build(combo,color);}
    }
    public class KBTemporaryMaterial : MonoBehaviour {public Material mat;void OnDestroy(){if(mat!=null)Destroy(mat);}}
    public class KBSlashCrescent : MonoBehaviour {
        Mesh mesh;Material mat;float age;Color tint;int mode;const int N=32;Vector3[] v=new Vector3[(N+1)*2];Color[] colors=new Color[(N+1)*2];
        public void Build(int combo,Color color){mode=combo;tint=color;mesh=new Mesh{name="Crescent"};mesh.MarkDynamic();GetComponentOrAdd();int[] ids=new int[N*12];int k=0;for(int i=0;i<N;i++){int a=i*2,b=a+1,c=a+2,d=a+3;foreach(int j in new[]{a,c,b,b,c,d,a,b,c,b,d,c})ids[k++]=j;}Draw(0);mesh.triangles=ids;}
        void GetComponentOrAdd(){gameObject.AddComponent<MeshFilter>().sharedMesh=mesh;var r=gameObject.AddComponent<MeshRenderer>();mat=KBVisuals.Glow(Color.white);r.sharedMaterial=mat;r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;}
        void Draw(float t){float radius=Mathf.Lerp(.8f,1.65f,t);for(int i=0;i<=N;i++){float u=i/(float)N,a=Mathf.Lerp(-105,105,u)*(mode==2?-1:1);Vector3 dir=mode==3?Quaternion.AngleAxis(a,Vector3.right)*Vector3.forward:Quaternion.AngleAxis(a,Vector3.up)*Vector3.forward;float w=Mathf.Sin(u*Mathf.PI)*.25f*(1-t*.65f);v[i*2]=dir*radius;v[i*2+1]=dir*(radius-w);Color c=tint;c.a=(1-t)*Mathf.Sin(u*Mathf.PI);colors[i*2]=c; c.a*=.12f;colors[i*2+1]=c;}mesh.vertices=v;mesh.colors=colors;mesh.RecalculateBounds();}
        void Update(){age+=Time.deltaTime;float t=age/.23f;if(t>=1){Destroy(gameObject);return;}Draw(t);}
        void OnDestroy(){if(mesh!=null)Destroy(mesh);if(mat!=null)Destroy(mat);}
    }
    // Two-edge ribbon samples the actual sword instead of a single tip trail.
    public class KBBladeRibbon {
        struct Sample {public Vector3 a,b;public float age;}
        readonly List<Sample> samples=new List<Sample>();Transform sword;GameObject host;Mesh mesh;Material mat;bool active;
        public KBBladeRibbon(Transform s){sword=s;host=new GameObject("Actual blade sweep");mesh=new Mesh{name="Blade sweep"};mesh.MarkDynamic();host.AddComponent<MeshFilter>().sharedMesh=mesh;var r=host.AddComponent<MeshRenderer>();mat=KBVisuals.Glow(Color.white);r.sharedMaterial=mat;r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;}
        public void Clear(){samples.Clear();mesh.Clear();active=false;}
        public void Tick(bool on,float dt){for(int i=samples.Count-1;i>=0;i--){var s=samples[i];s.age+=dt;if(s.age>.16f)samples.RemoveAt(i);else samples[i]=s;}if(on){if(!active)samples.Clear();Vector3 a=sword.TransformPoint(Vector3.forward*.19f),b=sword.TransformPoint(Vector3.forward*.82f);if(samples.Count==0||Vector3.Distance(samples[samples.Count-1].b,b)>.012f){samples.Add(new Sample{a=a,b=b});if(samples.Count>22)samples.RemoveAt(0);}}active=on;mesh.Clear();if(samples.Count<2)return;var v=new Vector3[samples.Count*2];var c=new Color[v.Length];var ix=new int[(samples.Count-1)*12];int k=0;for(int i=0;i<samples.Count;i++){var s=samples[i];float alpha=Mathf.Clamp01(1-s.age/.16f);v[i*2]=s.a;v[i*2+1]=s.b;c[i*2]=new Color(.2f,.5f,.9f,alpha*.12f);c[i*2+1]=new Color(.8f,.95f,1,alpha*.9f);if(i>0){int a=i*2-2,b=a+1,d=a+2,e=a+3;foreach(int j in new[]{a,d,b,b,d,e,a,b,d,b,e,d})ix[k++]=j;}}mesh.vertices=v;mesh.colors=c;mesh.triangles=ix;mesh.RecalculateBounds();}
        public void Dispose(){if(host!=null)Object.Destroy(host);if(mesh!=null)Object.Destroy(mesh);if(mat!=null)Object.Destroy(mat);}
    }
}
