using System;
using System.IO;
using UnityEngine;
using UnityEngine.Rendering;
namespace KBGame {
    public static class KBVisuals {
        public static Material Mat(Color color, float metallic=0, float smooth=.2f) {
            Shader s=GraphicsSettings.currentRenderPipeline!=null?Shader.Find("Universal Render Pipeline/Lit"):Shader.Find("Standard");
            if(s==null) s=Shader.Find("Standard");
            if(s==null) s=Shader.Find("Diffuse");
            Material m=new Material(s); m.color=color;
            if(m.HasProperty("_BaseColor")) m.SetColor("_BaseColor",color);
            if(m.HasProperty("_Metallic")) m.SetFloat("_Metallic",metallic);
            if(m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness",smooth);
            if(m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness",smooth);
            return m;
        }
        public static Material Glow(Color color) {
            Shader s=Shader.Find("Sprites/Default"); if(s==null) s=Shader.Find("Unlit/Color"); if(s==null) return Mat(color);
            Material m=new Material(s); m.color=color; return m;
        }
        public static GameObject Primitive(PrimitiveType type,string name,Transform parent,Vector3 pos,Vector3 scale,Material mat,bool collider=false) {
            var g=GameObject.CreatePrimitive(type); g.name=name; g.transform.SetParent(parent,false); g.transform.localPosition=pos;g.transform.localScale=scale;
            g.GetComponent<Renderer>().sharedMaterial=mat; if(!collider) {var c=g.GetComponent<Collider>(); if(c!=null){c.enabled=false; UnityEngine.Object.Destroy(c);}}
            return g;
        }
        public static Transform Weapon(TextAsset data, string name, Transform parent) {
            if(data==null) throw new InvalidOperationException(name+" mesh data missing");
            var root=new GameObject(name).transform; root.SetParent(parent,false);
            using(var r=new BinaryReader(new MemoryStream(data.bytes))) {
                if(new string(r.ReadChars(4))!="KBM1") throw new InvalidDataException(name);
                int count=r.ReadInt32();
                for(int part=0;part<count;part++) {
                    string label=System.Text.Encoding.UTF8.GetString(r.ReadBytes(r.ReadInt32()));
                    Color c=new Color(r.ReadSingle(),r.ReadSingle(),r.ReadSingle(),r.ReadSingle()); float metal=r.ReadSingle(),rough=r.ReadSingle();
                    int nv=r.ReadInt32(),ni=r.ReadInt32(); var v=new Vector3[nv];var n=new Vector3[nv];var ix=new int[ni];
                    for(int i=0;i<nv;i++) v[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
                    for(int i=0;i<nv;i++) n[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
                    for(int i=0;i<ni;i++) ix[i]=r.ReadInt32();
                    var mesh=new Mesh {name=label}; if(nv>65535) mesh.indexFormat=IndexFormat.UInt32; mesh.vertices=v;mesh.normals=n;mesh.triangles=ix;mesh.RecalculateBounds();
                    var g=new GameObject(label);g.transform.SetParent(root,false);g.AddComponent<MeshFilter>().sharedMesh=mesh;g.AddComponent<MeshRenderer>().sharedMaterial=Mat(c,metal,1-rough);
                }
            }
            return root;
        }
        public static LineRenderer Line(string name, Color color, float width, Transform parent=null) {
            var g=new GameObject(name); if(parent!=null)g.transform.SetParent(parent,false);
            var l=g.AddComponent<LineRenderer>();l.useWorldSpace=true;l.sharedMaterial=Glow(Color.white);g.AddComponent<KBTemporaryMaterial>().mat=l.sharedMaterial; l.startColor=color;l.endColor=color;l.startWidth=width;l.endWidth=width;l.numCapVertices=3;l.numCornerVertices=3;l.shadowCastingMode=ShadowCastingMode.Off;l.receiveShadows=false;return l;
        }
        public static void Ring(Vector3 center,float radius,Color color,float duration=.22f) {
            var l=Line("Combat ring",color,.045f);l.positionCount=41;
            for(int i=0;i<=40;i++){float a=i*Mathf.PI*2/40;l.SetPosition(i,center+new Vector3(Mathf.Cos(a)*radius,.04f,Mathf.Sin(a)*radius));}
            UnityEngine.Object.Destroy(l.gameObject,duration);
        }
        public static void Arc(Vector3 center,Vector3 forward,float radius,Color color,float duration=.18f) {
            var l=Line("Slash arc",color,.075f);l.positionCount=25;
            for(int i=0;i<25;i++){float a=Mathf.Lerp(-80,80,i/24f);l.SetPosition(i,center+Quaternion.AngleAxis(a,Vector3.up)*forward*radius+Vector3.up*Mathf.Sin(i/24f*Mathf.PI)*.18f);}
            UnityEngine.Object.Destroy(l.gameObject,duration);
        }
    }
}
