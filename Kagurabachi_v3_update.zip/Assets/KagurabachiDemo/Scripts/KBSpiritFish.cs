using UnityEngine;
namespace KBGame {
    // Three stylized goldfish apparitions. Meshes are runtime primitives, not imported illustrations.
    public class KBSpiritFish : MonoBehaviour {
        Transform target,tail,finL,finR;float age,life;int kind; Material bodyMat,accentMat,eyeMat; TrailRenderer trail;
        public static KBSpiritFish Spawn(Transform owner,int k,float seconds){var g=new GameObject("Spirit fish "+k);g.transform.SetParent(owner,true);var f=g.AddComponent<KBSpiritFish>();f.Build(owner,k,seconds);return f;}
        void Build(Transform owner,int k,float seconds){target=owner;kind=k;life=seconds;
            Color body=k==0?new Color(.035f,.045f,.075f):k==1?new Color(.86f,.07f,.11f):new Color(.93f,.77f,.42f);Color accent=k==0?new Color(.15f,.22f,.32f):k==1?new Color(1,.35f,.18f):new Color(.92f,.30f,.15f);
            bodyMat=KBVisuals.Mat(body,.15f,.6f);accentMat=KBVisuals.Mat(accent,.05f,.45f);eyeMat=KBVisuals.Mat(new Color(.025f,.025f,.035f),.2f,.7f);
            KBVisuals.Primitive(PrimitiveType.Sphere,"Body",transform,Vector3.zero,new Vector3(.42f,.48f,.74f),bodyMat);
            for(int s=-1;s<=1;s+=2){var eye=KBVisuals.Primitive(PrimitiveType.Sphere,"Eye",transform,new Vector3(s*.19f,.07f,.21f),Vector3.one*(k==0?.20f:.12f),accentMat).transform;KBVisuals.Primitive(PrimitiveType.Sphere,"Pupil",eye,new Vector3(s*.36f,0,.15f),Vector3.one*.62f,eyeMat);}
            tail=new GameObject("Tail pivot").transform;tail.SetParent(transform,false);tail.localPosition=new Vector3(0,0,-.30f);
            Fin(tail,"Tail upper",new Vector3(0,.12f,-.24f),new Vector3(.15f,.37f,.52f),-28);Fin(tail,"Tail lower",new Vector3(0,-.12f,-.24f),new Vector3(.15f,.37f,.52f),28);
            finL=Fin(transform,"Left fin",new Vector3(-.19f,-.09f,-.03f),new Vector3(.26f,.08f,.35f),0);finR=Fin(transform,"Right fin",new Vector3(.19f,-.09f,-.03f),new Vector3(.26f,.08f,.35f),0);Fin(transform,"Dorsal",new Vector3(0,.22f,-.08f),new Vector3(.08f,.21f,.33f),0);
            if(k==2){KBVisuals.Primitive(PrimitiveType.Sphere,"Calico patch",transform,new Vector3(.13f,.10f,.03f),new Vector3(.25f,.27f,.33f),accentMat);KBVisuals.Primitive(PrimitiveType.Sphere,"Dark patch",transform,new Vector3(-.15f,-.05f,-.12f),new Vector3(.19f,.25f,.27f),eyeMat);}
            trail=gameObject.AddComponent<TrailRenderer>();trail.time=.27f;trail.startWidth=.16f;trail.endWidth=0;trail.sharedMaterial=KBVisuals.Glow(accent);trail.emitting=false;Pose(0);trail.Clear();trail.emitting=true;
        }
        Transform Fin(Transform parent,string name,Vector3 pos,Vector3 scale,float tilt){var t=KBVisuals.Primitive(PrimitiveType.Sphere,name,parent,pos,scale,accentMat).transform;t.localRotation=Quaternion.Euler(tilt,0,0);return t;}
        void Pose(float t){float a=t*(kind==2?5.2f:4.6f)+(kind==1?1.3f:0);float radius=Mathf.Lerp(.20f,1.04f,Mathf.SmoothStep(0,1,Mathf.Clamp01(t/.20f)));float fade=Mathf.Min(Mathf.Clamp01(t/.13f),Mathf.Clamp01((life-t)/.20f));transform.localScale=Vector3.one*Mathf.Lerp(.03f,kind==0?1.27f:1f,fade);Vector3 local=new Vector3(Mathf.Sin(a)*radius,1.24f+.42f*Mathf.Sin(a*1.4f),Mathf.Cos(a)*radius);transform.localPosition=local;transform.localRotation=Quaternion.LookRotation(new Vector3(Mathf.Cos(a),.12f,-Mathf.Sin(a)),Vector3.up);transform.localRotation*=Quaternion.Euler(8*Mathf.Cos(a*1.4f),0,Mathf.Sin(a)*18);tail.localRotation=Quaternion.Euler(0,Mathf.Sin(t*18)*43,0);finL.localRotation=Quaternion.Euler(0,0,Mathf.Sin(t*11)*24);finR.localRotation=Quaternion.Euler(0,0,-Mathf.Sin(t*11)*24);}
        void Update(){age+=Time.deltaTime;if(target==null||age>=life){Destroy(gameObject);return;}Pose(age);}
        void OnDestroy(){if(trail!=null)Destroy(trail.sharedMaterial);if(bodyMat!=null)Destroy(bodyMat);if(accentMat!=null)Destroy(accentMat);if(eyeMat!=null)Destroy(eyeMat);}
    }
}
