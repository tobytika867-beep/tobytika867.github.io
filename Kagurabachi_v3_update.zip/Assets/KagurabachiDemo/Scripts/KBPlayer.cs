using UnityEngine;
namespace KBGame {
    public class KBPlayer : MonoBehaviour {
        public KagurabachiDemo game; public KBRig rig; public CharacterController cc; public Transform sword,saya; public Camera cam;
        public float health=100,energy=100;public bool drawn,guarding,dead; public KBEnemy locked;
        public KBAbilities abilities; KBCoatMotion coat; public int combo;public string status="E: Draw Enten";float statusTime;
        float vertical,phase,speed,yaw,pitch=13,distance=4.4f,dash,invuln,guardAge,attackTimer,attackLength,drawBlend,skillCooldown;
        bool hitDone,queued,skillAttack;Vector3 dashDir;TrailRenderer trail; bool captureClick; Vector3 planar; float landing, hurt, guardBlend, dodgeBlend, deathAge, footClock, lastDraw, cameraKick, cameraShake, baseFov=63; bool wasGrounded; float abilityPose,abilityLength; int abilityKind; KBFeedback feedback; KBBladeRibbon ribbon;
        public void Init(KagurabachiDemo owner) {
            game=owner;gameObject.layer=2;cc=gameObject.AddComponent<CharacterController>();cc.height=1.78f;cc.radius=.27f;cc.center=new Vector3(0,.89f,0);cc.stepOffset=.30f;cc.skinWidth=.035f;
            rig=new KBRig(transform,game.character);sword=KBVisuals.Weapon(game.swordData,"Enten sword v8",transform);saya=KBVisuals.Weapon(game.sayaData,"Enten saya v8",transform);
            var t=new GameObject("Blade trail").transform;t.SetParent(sword,false);t.localPosition=Vector3.forward*.78f;trail=t.gameObject.AddComponent<TrailRenderer>();trail.time=.15f;trail.startWidth=.13f;trail.endWidth=0;trail.sharedMaterial=KBVisuals.Glow(new Color(.5f,.85f,1,.8f));trail.emitting=false;
            feedback=gameObject.AddComponent<KBFeedback>();ribbon=new KBBladeRibbon(sword); abilities=gameObject.AddComponent<KBAbilities>();abilities.Init(this);coat=new KBCoatMotion(rig.model,transform);cam=game.cam;Cursor.lockState=CursorLockMode.Locked;Cursor.visible=false;CameraPose(true);
        }
        public void Say(string s,float time=1.4f){status=s;statusTime=time;}
        void Update(){
            if(game==null||rig==null||abilities==null)return;float dt=Time.deltaTime;if(dead){deathAge+=dt;rig.ResetPose();rig.model.localRotation=Quaternion.Slerp(rig.model.localRotation,Quaternion.AngleAxis(82,Vector3.forward)*deathBase,1-Mathf.Exp(-dt*5));rig.model.localPosition=deathPosition+Vector3.up*.16f*Mathf.Sin(Mathf.Clamp01(deathAge/.55f)*Mathf.PI);return;}if(dt<=0)return;abilityPose=Mathf.Max(0,abilityPose-dt);landing=Mathf.MoveTowards(landing,0,dt*4);hurt=Mathf.MoveTowards(hurt,0,dt*3.7f);invuln=Mathf.Max(0,invuln-dt);skillCooldown=Mathf.Max(0,skillCooldown-dt);statusTime-=dt;if(statusTime<0)status=drawn?"Enten drawn":"E: Draw Enten";
            abilities.Tick(dt); if(!abilities.Boosted)energy=Mathf.Min(100,energy+dt*(guarding?8:18));
            if(KBInput.Down(KBInput.K.Escape)){Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
            captureClick=false;if(Cursor.lockState!=CursorLockMode.Locked&&KBInput.Attack){Cursor.lockState=CursorLockMode.Locked;Cursor.visible=false;captureClick=true;}
            if(Cursor.lockState==CursorLockMode.Locked){Vector2 m=KBInput.MouseDelta;yaw+=m.x;pitch=Mathf.Clamp(pitch-m.y,-13,58);distance=Mathf.Clamp(distance-KBInput.Scroll*.35f,2.5f,7);}
            if(KBInput.Down(KBInput.K.Tab)){locked=locked==null?game.Nearest(transform.position,18):null;Say(locked!=null?"Lock on":"Lock off");}
            if(locked!=null&&locked.dead)locked=null;
            if(locked!=null){Vector3 d=locked.transform.position-transform.position;float want=Mathf.Atan2(d.x,d.z)*Mathf.Rad2Deg;yaw=Mathf.LerpAngle(yaw,want,dt*5);}
            if(KBInput.Down(KBInput.K.E)&&attackTimer<=0&&dash<=0){drawn=!drawn;if(!drawn)abilities.Cancel();Say(drawn?"Draw!":"Sheathe");}
            lastDraw=drawBlend;drawBlend=Mathf.MoveTowards(drawBlend,drawn?1:0,dt*(drawn?2.5f:1.9f));if((lastDraw<.48f&&drawBlend>=.48f)||(lastDraw>.48f&&drawBlend<=.48f)){feedback.Sound(0);cameraKick=.35f;}
            if(drawn&&drawBlend>.9f&&attackTimer<=0&&dash<=0){if(KBInput.Down(KBInput.K.C))abilities.Red();else if(KBInput.Down(KBInput.K.V))abilities.ToggleBoost();}
            bool wantGuard=drawn&&drawBlend>.8f&&attackTimer<=0&&dash<=0&&(KBInput.Held(KBInput.K.F)||KBInput.Right);
            guardAge=wantGuard?(guarding?guardAge+dt:0):0;guarding=wantGuard;guardBlend=Mathf.MoveTowards(guardBlend,guarding?1:0,dt*9);
            Vector2 input=KBInput.Move;Vector3 move=Quaternion.Euler(0,yaw,0)*new Vector3(input.x,0,input.y);
            if(KBInput.Down(KBInput.K.Shift)&&energy>=22&&dash<=0&&attackTimer<=0){energy-=22;dash=.25f;invuln=.30f;dashDir=move.sqrMagnitude>.01f?move.normalized:transform.forward;Say("Dodge");cameraKick=1;feedback.Sound(1);KBFeedback.Burst(transform.position+Vector3.up*.12f,-dashDir,new Color(.65f,.75f,.85f),14,.5f);KBVisuals.Ring(transform.position,.65f,Color.cyan);}
            if(KBInput.Attack&&!captureClick&&dash<=0&&!guarding){if(!drawn){drawn=true;Say("Draw Enten");}else if(drawBlend>.9f){if(attackTimer<=0)StartAttack(false);else if(attackTimer>attackLength*.20f)queued=true;}}
            if(KBInput.Down(KBInput.K.Q)&&drawn&&drawBlend>.9f&&attackTimer<=0&&!guarding&&energy>=35&&skillCooldown<=0){energy-=35;skillCooldown=1.2f;StartAttack(true);}
            if(cc.isGrounded&&vertical<0)vertical=-2;
            if(KBInput.Down(KBInput.K.Space)&&cc.isGrounded&&dash<=0&&attackTimer<=0){vertical=5.6f;feedback.Sound(1);KBFeedback.Burst(transform.position+Vector3.up*.08f,-transform.forward,new Color(.65f,.65f,.62f),9,.4f);}vertical-=18*dt;
            Vector3 face=locked!=null?locked.transform.position-transform.position:(attackTimer>0||guarding?Quaternion.Euler(0,yaw,0)*Vector3.forward:move);face.y=0;
            if(face.sqrMagnitude>.015f)transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(face),dt*(attackTimer>0?16:12));
            speed=(guarding?1.7f:attackTimer>0?.8f:KBInput.Held(KBInput.K.Ctrl)?2.0f:5.5f)*(abilities.Boosted?1.65f:1f);Vector3 target=move*speed;
            planar=Vector3.MoveTowards(planar,target,dt*(target.sqrMagnitude<.01f?24:18));Vector3 vel=planar;
            if(attackTimer>0&&!skillAttack){float t0=attackTimer/attackLength;vel+=transform.forward*(Mathf.Sin(Mathf.Clamp01((t0-.25f)/.44f)*Mathf.PI)*(combo==3?3.2f:2.2f));}
            if(dash>0){dash-=dt;vel=dashDir*(abilities.Boosted?15f:10f)*Mathf.Lerp(.6f,1,Mathf.Clamp01(dash/.12f));planar=vel*.35f;}dodgeBlend=Mathf.MoveTowards(dodgeBlend,dash>0?1:0,dt*13);
            if(attackTimer>0){attackTimer+=dt;float t=attackTimer/attackLength;
                if(!hitDone&&t>=.46f){hitDone=true;feedback.Sound(skillAttack?3:1);cameraKick=skillAttack?1:.45f;if(skillAttack){game.Projectile(transform.position+Vector3.up*1.08f+transform.forward*.6f,transform.forward);abilities.Black();}else{game.PlayerStrike(this,(combo==3?34:combo==2?27:22)*(abilities.Boosted?1.25f:1f),2.15f,110);KBFeedback.Slash(transform.position+Vector3.up*1.05f,transform.rotation,combo,new Color(.60f,.86f,1));} }
                if(t>=1){attackTimer=0;trail.emitting=false;if(queued&&!skillAttack&&combo<3){queued=false;StartAttack(false);}else{queued=false;combo=0;}}
            }
            float falling=vertical;Vector3 before=transform.position;cc.Move((vel+Vector3.up*vertical)*dt);Vector3 actual=(transform.position-before)/Mathf.Max(dt,.0001f);actual.y=0;
            if(!wasGrounded&&cc.isGrounded&&falling<-3){landing=Mathf.Clamp01(-falling/9);cameraShake=Mathf.Max(cameraShake,landing*.32f);feedback.Sound(2);KBFeedback.Burst(transform.position+Vector3.up*.08f,Vector3.up,new Color(.66f,.65f,.62f),18,.48f);}wasGrounded=cc.isGrounded;
            float strideLength=Mathf.Lerp(1.0f,2.35f,Mathf.InverseLerp(2,6,actual.magnitude));phase=Mathf.Repeat(phase+Mathf.Min(3.1f,actual.magnitude/strideLength)*dt*2*Mathf.PI,Mathf.PI*2);
            if(cc.isGrounded&&actual.magnitude>1.2f&&dash<=0&&attackTimer<=0){float next=Mathf.Floor(phase/Mathf.PI);if(next!=footClock){feedback.Sound(2,.24f);KBFeedback.Burst(transform.position+Vector3.up*.04f,-actual.normalized,new Color(.58f,.57f,.54f),4,.28f);}footClock=next;}else footClock=Mathf.Floor(phase/Mathf.PI);
            Pose(actual);coat.Update(actual,phase,attackTimer>0,dash>0,dt);ribbon.Tick(attackTimer>0&&attackTimer/attackLength>.20f&&attackTimer/attackLength<.78f,dt);
        }
        void StartAttack(bool skill){attackTimer=.0001f;combo=skill?0:(combo%3)+1;attackLength=(skill ? .72f : combo==3 ? .62f : .48f)*(abilities.Boosted ? .70f : 1f);hitDone=false;skillAttack=skill;trail.Clear();trail.emitting=false;ribbon.Clear();Say(skill?"KURO / ranged slash":"Slash "+combo,.5f);}
        Quaternion deathBase;Vector3 deathPosition;
        void Pose(Vector3 velocity){
            float v=velocity.magnitude, run=Mathf.InverseLerp(2,6,v), stride=Mathf.Clamp01(v/3);float t=attackTimer>0?Mathf.Clamp01(attackTimer/attackLength):0;
            float wind=attackTimer>0?Mathf.Sin(t*Mathf.PI):0;float turn=attackTimer>0?Mathf.Lerp(32,-38,Mathf.SmoothStep(0,1,Mathf.InverseLerp(.23f,.68f,t)))*wind*(combo==2?-1:1):0;
            Vector3 local=transform.InverseTransformDirection(velocity);
            rig.ResetPose();rig.MotionLegs(velocity,phase,!cc.isGrounded,vertical,dodgeBlend,landing,guardBlend,wind,hurt);
            rig.BodyMotion(turn+Mathf.Sin(phase)*stride*5,run*12+guardBlend*6+dodgeBlend*21+landing*17+wind*8-hurt*16,-local.x*1.5f+Mathf.Sin(phase)*stride*2+turn*.10f,0,-run*4);
            Vector3 sheathDir=new Vector3(-.17f,-.40f,-.90f).normalized;Vector3 sheathGrip=new Vector3(-.26f,1.03f,.21f);
            sheathGrip.y-=landing*.045f;sheathGrip.z+=Mathf.Sin(phase)*stride*.018f;
            saya.localPosition=sheathGrip;saya.localRotation=Quaternion.LookRotation(sheathDir,Vector3.up);
            float swingArm=Mathf.Sin(phase)*stride, breathe=Mathf.Sin(Time.time*2.1f)*.012f;
            Vector3 grip=new Vector3(.34f,.94f+breathe,.24f-swingArm*.12f),blade=new Vector3(.54f,-.19f,.82f).normalized;
            grip=Vector3.Lerp(grip,new Vector3(.18f,1.23f,.40f),guardBlend);blade=Vector3.Slerp(blade,new Vector3(-.86f,.47f,.10f).normalized,guardBlend);
            if(dodgeBlend>0){grip=Vector3.Lerp(grip,new Vector3(.37f,.87f,-.10f),dodgeBlend);blade=Vector3.Slerp(blade,new Vector3(.42f,.02f,-.91f).normalized,dodgeBlend);}
            Vector3 left=new Vector3(-.31f,.93f+breathe,swingArm*.21f);
            if(abilityPose>0&&attackTimer<=0&&drawn){float envelope=Mathf.Sin(Mathf.PI*Mathf.Clamp01(abilityPose/abilityLength));if(abilityKind==1){grip=Vector3.Lerp(grip,new Vector3(.12f,1.24f,.40f),envelope);blade=Vector3.Slerp(blade,new Vector3(-.12f,.90f,.42f),envelope);left=Vector3.Lerp(left,new Vector3(-.28f,1.23f,.44f),envelope);}else if(abilityKind==2){grip=Vector3.Lerp(grip,new Vector3(.28f,1.11f,.28f),envelope);blade=Vector3.Slerp(blade,new Vector3(.40f,.65f,.58f),envelope);left=Vector3.Lerp(left,new Vector3(-.36f,1.15f,.10f),envelope);}}
            if(attackTimer>0){float sign=combo==2?-1:1;Vector3 windGrip,cutGrip,followGrip;Vector3 windBlade,cutBlade,followBlade;
                if(combo==3||skillAttack){windGrip=new Vector3(.16f,1.54f,.13f);windBlade=new Vector3(.14f,.94f,-.32f);cutGrip=new Vector3(.16f,1.16f,.44f);cutBlade=new Vector3(.03f,.02f,1);followGrip=new Vector3(.18f,.82f,.38f);followBlade=new Vector3(.10f,-.87f,.48f);}
                else{windGrip=new Vector3(sign*.35f,1.25f,.12f);windBlade=new Vector3(sign*.88f,.25f,-.40f);cutGrip=new Vector3(.15f,1.16f,.44f);cutBlade=new Vector3(0,combo==2?.25f:-.13f,1);followGrip=new Vector3(-sign*.32f,.97f,.25f);followBlade=new Vector3(-sign*.93f,combo==2?.22f:-.18f,-.25f);}
                grip=KeyPose(t,grip,windGrip,cutGrip,followGrip,false);blade=KeyPose(t,blade,windBlade.normalized,cutBlade.normalized,followBlade.normalized,true).normalized;
                left=Vector3.Lerp(left,new Vector3(-.35f,1.13f,-.13f),wind);
            }
            float b=Mathf.SmoothStep(0,1,drawBlend);Vector3 extract=sheathGrip-sheathDir*.33f;
            float e=Mathf.SmoothStep(0,1,Mathf.InverseLerp(.12f,.52f,drawBlend));float settle=Mathf.SmoothStep(0,1,Mathf.InverseLerp(.52f,1,drawBlend));
            Vector3 rightTarget=Vector3.Lerp(Vector3.Lerp(sheathGrip,extract,e),grip,settle);Vector3 rightBlade=Vector3.Slerp(sheathDir,blade,settle).normalized;
            if(drawBlend<.015f&&!drawn){rig.Arm(true,new Vector3(.31f,.91f,-swingArm*.25f),Vector3.up,false,.23f);sword.localPosition=sheathGrip;sword.localRotation=saya.localRotation;}
            else{Vector3 actual=rig.Arm(true,rightTarget,rightBlade,true,.98f);sword.position=actual;Vector3 axis=transform.TransformDirection(rightBlade);Vector3 up=Vector3.ProjectOnPlane(transform.up,axis);if(up.sqrMagnitude<.015f)up=Vector3.ProjectOnPlane(transform.forward,axis);sword.rotation=Quaternion.LookRotation(axis,up);}
            Vector3 leftGrip=Vector3.Lerp(sheathGrip+new Vector3(-.035f,-.03f,-.055f),left,b);
            if(guardBlend>.01f)leftGrip=Vector3.Lerp(leftGrip,transform.InverseTransformPoint(sword.position-sword.forward*.115f),guardBlend*.9f);
            rig.Arm(false,leftGrip,guardBlend>.5f?rightBlade:sheathDir,drawBlend<.70f||guardBlend>.5f,Mathf.Max((1-b)*.7f,guardBlend*.9f));
        }
        static Vector3 KeyPose(float t,Vector3 ready,Vector3 wind,Vector3 cut,Vector3 follow,bool direction){
            Vector3 a,b;float u;if(t<.24f){a=ready;b=wind;u=t/.24f;}else if(t<.46f){a=wind;b=cut;u=(t-.24f)/.22f;}else if(t<.70f){a=cut;b=follow;u=(t-.46f)/.24f;}else{a=follow;b=ready;u=(t-.70f)/.30f;}u=Mathf.SmoothStep(0,1,u);return direction?Vector3.Slerp(a,b,u):Vector3.Lerp(a,b,u);
        }
        public void AbilityCue(int kind){abilityKind=kind;abilityLength=abilityPose=kind==1?.55f:.65f;cameraKick=.75f;feedback.Sound(3,.65f);}
        public void Impact(Vector3 point,bool heavy=false){cameraShake=Mathf.Max(cameraShake,heavy?.9f:.55f);cameraKick=Mathf.Max(cameraKick,heavy?.8f:.4f);feedback.Sound(heavy?3:4);feedback.Freeze(heavy?.085f:.048f);KBFeedback.Burst(point,transform.forward,new Color(.95f,.79f,.42f),heavy?32:20,.45f);}
        public void TakeMagic(float amount,Vector3 source){if(dead||invuln>0)return;if(abilities.Absorb(amount,source))return;TakeHit(amount,source);}
        void OnDestroy(){if(coat!=null)coat.Dispose();if(ribbon!=null)ribbon.Dispose();if(trail!=null)Destroy(trail.sharedMaterial);}
        public void TakeHit(float amount,Vector3 source){if(dead||invuln>0)return;Vector3 d=source-transform.position;d.y=0;bool front=Vector3.Angle(transform.forward,d)<105;
            if(guarding&&front&&energy>=8){if(guardAge<.20f){energy=Mathf.Min(100,energy+10);Say("PERFECT GUARD!",1.0f);Impact(transform.position+transform.forward*.6f+Vector3.up*1.15f,true);KBVisuals.Ring(transform.position,1,Color.cyan);return;}energy-=8;amount*=.2f;Say("Guard");}else Say("Hit!");
            health=Mathf.Max(0,health-amount);invuln=.28f;hurt=1;cameraShake=.85f;feedback.Sound(4);KBFeedback.Burst(transform.position+Vector3.up*1.1f,-d.normalized,new Color(.8f,.35f,.2f),13,.38f);if(!guarding){attackTimer=0;queued=false;combo=0;ribbon.Clear();}if(health<=0){dead=true;deathBase=rig.model.localRotation;deathPosition=rig.model.localPosition;abilities.Cancel();ribbon.Clear();trail.emitting=false;Say("Defeated - R to retry",999);Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}}
        void LateUpdate(){if(game!=null&&cam!=null)CameraPose(false);}
        void CameraPose(bool instant){float ud=Time.unscaledDeltaTime;cameraShake=Mathf.MoveTowards(cameraShake,0,ud*3.5f);cameraKick=Mathf.MoveTowards(cameraKick,0,ud*2.8f);cam.fieldOfView=Mathf.Lerp(cam.fieldOfView,baseFov+Mathf.Clamp01(planar.magnitude/7)*4+cameraKick*5+(abilities!=null&&abilities.Boosted?5:0),1-Mathf.Exp(-ud*7));Vector3 focus=transform.position+Vector3.up*(1.37f-landing*.07f);Quaternion rot=Quaternion.Euler(pitch,yaw,0);Vector3 offset=rot*new Vector3(.58f,.28f,-distance);Vector3 dir=offset.normalized;
            float len=offset.magnitude;if(Physics.SphereCast(focus,.16f,dir,out RaycastHit hit,len,game.environmentMask,QueryTriggerInteraction.Ignore))len=Mathf.Max(.5f,hit.distance-.15f);
            Vector3 target=focus+dir*len;cam.transform.position=instant?target:Vector3.Lerp(cam.transform.position,target,1-Mathf.Exp(-Time.unscaledDeltaTime*15));cam.transform.rotation=Quaternion.LookRotation(focus+rot*Vector3.forward*.45f-cam.transform.position,Vector3.up)*Quaternion.Euler(Mathf.Sin(Time.unscaledTime*73)*cameraShake,Mathf.Sin(Time.unscaledTime*91)*cameraShake*.6f,Mathf.Sin(Time.unscaledTime*61)*cameraShake*.4f);
        }
    }
}
