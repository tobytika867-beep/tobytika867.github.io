using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif
namespace KBGame {
    public static class KBInput {
        public enum K { W,A,S,D,Shift,Ctrl,Space,E,F,Q,C,V,M,Tab,R,Escape }
#if ENABLE_INPUT_SYSTEM
        static Key Map(K k) { switch(k) { case K.Shift:return Key.LeftShift; case K.Ctrl:return Key.LeftCtrl; case K.Space:return Key.Space; case K.Tab:return Key.Tab; case K.Escape:return Key.Escape; default:return (Key)System.Enum.Parse(typeof(Key),k.ToString()); } }
        public static bool Held(K k) {return Keyboard.current!=null && Keyboard.current[Map(k)].isPressed;}
        public static bool Down(K k) {return Keyboard.current!=null && Keyboard.current[Map(k)].wasPressedThisFrame;}
        public static bool Attack => Mouse.current!=null && Mouse.current.leftButton.wasPressedThisFrame;
        public static bool Right => Mouse.current!=null && Mouse.current.rightButton.isPressed;
        public static Vector2 MouseDelta => Mouse.current==null?Vector2.zero:Mouse.current.delta.ReadValue()*0.11f;
        public static float Scroll => Mouse.current==null?0:Mouse.current.scroll.ReadValue().y/120f;
#else
        static KeyCode Map(K k) { switch(k) {case K.Shift:return KeyCode.LeftShift;case K.Ctrl:return KeyCode.LeftControl;case K.Space:return KeyCode.Space;case K.Tab:return KeyCode.Tab;case K.Escape:return KeyCode.Escape;default:return (KeyCode)System.Enum.Parse(typeof(KeyCode),k.ToString());} }
        public static bool Held(K k) => Input.GetKey(Map(k));
        public static bool Down(K k) => Input.GetKeyDown(Map(k));
        public static bool Attack => Input.GetMouseButtonDown(0);
        public static bool Right => Input.GetMouseButton(1);
        public static Vector2 MouseDelta => new Vector2(Input.GetAxisRaw("Mouse X"),Input.GetAxisRaw("Mouse Y"))*2.2f;
        public static float Scroll => Input.mouseScrollDelta.y;
#endif
        public static Vector2 Move => Vector2.ClampMagnitude(new Vector2((Held(K.D)?1:0)-(Held(K.A)?1:0),(Held(K.W)?1:0)-(Held(K.S)?1:0)),1);
    }
}
