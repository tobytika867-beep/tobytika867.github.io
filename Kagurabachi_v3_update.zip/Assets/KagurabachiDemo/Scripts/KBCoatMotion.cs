using UnityEngine;
namespace KBGame {
    // Small secondary motion of the coat hem, on a private mesh copy. Original VRM is untouched.
    public class KBCoatMotion {
        Mesh mesh; SkinnedMeshRenderer renderer; Vector3[] rest,work; float[] weight; Transform owner; float sway,back,swaySpeed,backSpeed,lastTurn;
        public KBCoatMotion(Transform model,Transform root){owner=root;foreach(var r in model.GetComponentsInChildren<SkinnedMeshRenderer>(true)){
            if(r.sharedMesh==null||(!r.name.Contains("Open long coat")&&!r.sharedMesh.name.Contains("Open long coat")))continue;
            if(!r.sharedMesh.isReadable){Debug.LogWarning("Coat mesh is not readable; secondary motion disabled.");return;}
            renderer=r;mesh=Object.Instantiate(r.sharedMesh);mesh.name="Runtime coat hem";mesh.MarkDynamic();r.sharedMesh=mesh;rest=mesh.vertices;work=(Vector3[])rest.Clone();weight=new float[rest.Length];
            for(int i=0;i<rest.Length;i++){float y=root.InverseTransformPoint(r.transform.TransformPoint(rest[i])).y;weight[i]=Mathf.Pow(Mathf.Clamp01((1.03f-y)/.72f),1.6f);}break;}}
        public void Update(Vector3 velocity,float phase,bool attack,bool dash,float dt){if(mesh==null||renderer==null)return;Vector3 local=owner.InverseTransformDirection(velocity);float turn=owner.eulerAngles.y;float turnVelocity=Mathf.Clamp(Mathf.DeltaAngle(lastTurn,turn)/Mathf.Max(dt,.001f),-260,260);lastTurn=turn;sway=Mathf.SmoothDamp(sway,Mathf.Clamp(-local.x*.018f-turnVelocity*.00022f+(attack?Mathf.Sin(Time.time*19)*.07f:0),-.16f,.16f),ref swaySpeed,.16f,2,dt);back=Mathf.SmoothDamp(back,Mathf.Clamp(-local.z*.027f-(dash?.085f:0),-.24f,.14f),ref backSpeed,.21f,2,dt);Vector3 x=renderer.transform.InverseTransformVector(owner.right),z=renderer.transform.InverseTransformVector(owner.forward);
            for(int i=0;i<rest.Length;i++){float w=weight[i];work[i]=rest[i]+x*((sway+Mathf.Sin(phase+rest[i].x*13+weight[i]*2.5f)*.022f*Mathf.Clamp01(velocity.magnitude/3f))*w)+z*(back*w);}
            mesh.vertices=work;mesh.RecalculateNormals();mesh.RecalculateBounds();}
        public void Dispose(){if(mesh!=null)Object.Destroy(mesh);}
    }
}
