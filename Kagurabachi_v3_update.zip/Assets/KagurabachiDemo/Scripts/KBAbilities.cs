using UnityEngine;
namespace KBGame {
    public class KBAbilities : MonoBehaviour {
        KBPlayer p; float absorbWindow, stored, boostTime, redCooldown, auraClock; KBSpiritFish boostFish;
        public bool Boosted=>boostTime>0;
        public string RedStatus=>stored>0?"STORED (C release)":absorbWindow>0?"ABSORBING":redCooldown>0?"COOLDOWN":"READY";
        public void Init(KBPlayer player){p=player;}
        public void Tick(float dt){
            absorbWindow=Mathf.Max(0,absorbWindow-dt);redCooldown=Mathf.Max(0,redCooldown-dt);
            if(!Boosted)return;boostTime-=dt;p.energy=Mathf.Max(0,p.energy-12*dt);auraClock-=dt;
            if(auraClock<=0){auraClock=.14f;KBVisuals.Ring(p.transform.position,.43f,new Color(.85f,.67f,.24f),.17f);}
            if(boostTime<=0||p.energy<=0){StopBoost();p.Say("NISHIKI end");}
        }
        public void Black(){KBSpiritFish.Spawn(p.transform,0,.85f);}
        public void Red(){if(stored>0){float damage=stored*1.65f;stored=0;absorbWindow=0;redCooldown=1.2f;p.game.Projectile(p.transform.position+Vector3.up*1.05f+p.transform.forward*.6f,p.transform.forward,true,damage);KBSpiritFish.Spawn(p.transform,1,1f);KBFeedback.Burst(p.transform.position+Vector3.up*1.15f,p.transform.forward,new Color(1,.15f,.08f),30,.55f);p.AbilityCue(1);p.Say("AKA / Release");return;}
            if(redCooldown>0||p.energy<18||absorbWindow>0)return;p.energy-=18;absorbWindow=1.2f;redCooldown=2.0f;KBSpiritFish.Spawn(p.transform,1,1.25f);p.AbilityCue(1);p.Say("AKA / Absorb magic",1.2f);}
        public bool Absorb(float damage,Vector3 source){if(absorbWindow<=0||stored>0)return false;Vector3 d=source-p.transform.position;d.y=0;if(d.sqrMagnitude>.001f&&Vector3.Angle(p.transform.forward,d)>105)return false;stored=damage;absorbWindow=0;p.Impact(p.transform.position+Vector3.up*1.1f,true);p.Say("AKA / Stored! C to release",2);KBVisuals.Ring(p.transform.position,1.1f,new Color(1,.14f,.12f),.45f);return true;}
        public void ToggleBoost(){if(Boosted){StopBoost();p.Say("NISHIKI end");return;}if(p.energy<25)return;p.energy-=10;boostTime=8;KBFeedback.Burst(p.transform.position+Vector3.up*.8f,Vector3.up,new Color(1,.76f,.22f),40,.65f);boostFish=KBSpiritFish.Spawn(p.transform,2,8.2f);p.AbilityCue(2);p.Say("NISHIKI / Speed up",2);}
        void StopBoost(){boostTime=0;if(boostFish!=null)Destroy(boostFish.gameObject);boostFish=null;}
        public void Cancel(){StopBoost();absorbWindow=0;stored=0;}
    }
}
