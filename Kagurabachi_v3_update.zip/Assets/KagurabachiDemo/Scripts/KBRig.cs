using System;
using System.Collections.Generic;
using UnityEngine;
namespace KBGame {
    // VRoid / VRM humanoid bone mapping. Poses use world-space IK, no AnimatorController needed.
    public class KBRig {
        public Transform model,root,hips,spine,chest,head,ru,rl,rh,lu,ll,lh,rt,rs,rf,lt,ls,lf;
        Animator animator; readonly Dictionary<Transform,Quaternion> rest=new Dictionary<Transform,Quaternion>();
        readonly List<Finger> fingers=new List<Finger>();
        Quaternion handBasisR,handBasisL; float palmR=.075f,palmL=.075f; Vector3 hipsRest, footR, footL;
        class Finger {public Transform t; public Vector3 axis;public float bend;public bool right;}
        Transform Find(HumanBodyBones h,string n) {
            if(animator!=null && animator.isHuman){var b=animator.GetBoneTransform(h);if(b!=null)return b;}
            foreach(var t in model.GetComponentsInChildren<Transform>(true))if(t.name==n||t.name.EndsWith("/"+n,StringComparison.Ordinal))return t;
            return null;
        }
        public KBRig(Transform owner, GameObject prefab) {
            root=owner;model=UnityEngine.Object.Instantiate(prefab,owner).transform;model.name="Chihiro v37";model.localPosition=Vector3.zero;model.localRotation=Quaternion.identity;
            animator=model.GetComponentInChildren<Animator>(true);
            hips=Find(HumanBodyBones.Hips,"J_Bip_C_Hips");spine=Find(HumanBodyBones.Spine,"J_Bip_C_Spine");chest=Find(HumanBodyBones.Chest,"J_Bip_C_Chest");head=Find(HumanBodyBones.Head,"J_Bip_C_Head");
            ru=Find(HumanBodyBones.RightUpperArm,"J_Bip_R_UpperArm");rl=Find(HumanBodyBones.RightLowerArm,"J_Bip_R_LowerArm");rh=Find(HumanBodyBones.RightHand,"J_Bip_R_Hand");
            lu=Find(HumanBodyBones.LeftUpperArm,"J_Bip_L_UpperArm");ll=Find(HumanBodyBones.LeftLowerArm,"J_Bip_L_LowerArm");lh=Find(HumanBodyBones.LeftHand,"J_Bip_L_Hand");
            rt=Find(HumanBodyBones.RightUpperLeg,"J_Bip_R_UpperLeg");rs=Find(HumanBodyBones.RightLowerLeg,"J_Bip_R_LowerLeg");rf=Find(HumanBodyBones.RightFoot,"J_Bip_R_Foot");
            lt=Find(HumanBodyBones.LeftUpperLeg,"J_Bip_L_UpperLeg");ls=Find(HumanBodyBones.LeftLowerLeg,"J_Bip_L_LowerLeg");lf=Find(HumanBodyBones.LeftFoot,"J_Bip_L_Foot");
            if(hips==null||head==null||ru==null||rl==null||rh==null||lu==null||ll==null||lh==null||rt==null||rs==null||rf==null||lt==null||ls==null||lf==null) throw new InvalidOperationException("VRM humanoid bones missing. Import Chihiro_outfit_v37.vrm with UniVRM VRM 1.0.");
            // Normalize visual facing from anatomical right/left shoulders.
            Vector3 right=root.InverseTransformDirection(ru.position-lu.position);right.y=0;
            if(right.sqrMagnitude>.001f) model.localRotation=Quaternion.FromToRotation(right.normalized,Vector3.right)*model.localRotation;
            float footY=root.InverseTransformPoint((rf.position+lf.position)*.5f).y;
            model.localPosition+=Vector3.up*(.075f-footY);
            // Do not let a controller overwrite procedural bone rotations.
            if(animator!=null){animator.applyRootMotion=false;animator.enabled=false;}
            foreach(var t in model.GetComponentsInChildren<Transform>(true))rest[t]=t.localRotation;
            foreach(var s in model.GetComponentsInChildren<SkinnedMeshRenderer>(true))s.updateWhenOffscreen=true;
            hipsRest=hips.localPosition;footR=root.InverseTransformPoint(rf.position);footL=root.InverseTransformPoint(lf.position);
            SetupHand(true);SetupHand(false);
        }
        void SetupHand(bool right) {
            Transform h=right?rh:lh;string prefix="J_Bip_"+(right?"R":"L")+"_";
            Transform mid=Find(right?HumanBodyBones.RightMiddleProximal:HumanBodyBones.LeftMiddleProximal,prefix+"Middle1");
            Transform index=Find(right?HumanBodyBones.RightIndexProximal:HumanBodyBones.LeftIndexProximal,prefix+"Index1");
            Transform little=Find(right?HumanBodyBones.RightLittleProximal:HumanBodyBones.LeftLittleProximal,prefix+"Little1");
            Vector3 along=mid!=null?(mid.position-h.position).normalized:(h.position-(right?rl:ll).position).normalized;
            Vector3 thumbSide=index!=null&&little!=null?(index.position-little.position).normalized:root.forward;
            thumbSide=Vector3.ProjectOnPlane(thumbSide,along).normalized;
            if(thumbSide.sqrMagnitude<.1f)thumbSide=Vector3.ProjectOnPlane(root.up,along).normalized;
            Quaternion basis=Quaternion.LookRotation(h.InverseTransformDirection(along),h.InverseTransformDirection(thumbSide));
            float palm=mid!=null?Vector3.Distance(mid.position,h.position)*.83f:.065f;
            if(right){handBasisR=basis;palmR=palm;}else{handBasisL=basis;palmL=palm;}
            string[] names={"Index","Middle","Ring","Little","Thumb"};
            foreach(string f in names) for(int i=1;i<=3;i++) {
                Transform t=null;foreach(var b in model.GetComponentsInChildren<Transform>(true))if(b.name==prefix+f+i){t=b;break;}
                if(t==null)continue;
                Vector3 dir=t.childCount>0?(t.GetChild(0).position-t.position).normalized:along;
                Vector3 axis=Vector3.Cross(dir,-root.up);
                if(axis.sqrMagnitude<.001f)axis=Vector3.Cross(dir,root.forward);
                fingers.Add(new Finger{t=t,axis=t.InverseTransformDirection(axis.normalized),bend=f=="Thumb"?24f:(i==1?58f:i==2?72f:46f),right=right});
            }
        }
        public void ResetPose() {foreach(var p in rest)if(p.Key!=model)p.Key.localRotation=p.Value;hips.localPosition=hipsRest;}
        // Cyclic foot targets: stance moves backwards, swing lifts and returns forward.
        public void MotionLegs(Vector3 velocity,float phase,bool airborne,float vertical,float dash,float land,float stance,float attack,float hurt) {
            Vector3 local=root.InverseTransformDirection(velocity);local.y=0;float speed=local.magnitude;
            float amount=Mathf.Clamp01(speed/2.2f), run=Mathf.InverseLerp(2.1f,6.4f,speed);
            Vector3 dir=speed>.01f?local/speed:Vector3.forward;
            float reach=Mathf.Lerp(.17f,.39f,run)*amount, lift=Mathf.Lerp(.10f,.23f,run)*amount;
            float crouch=.035f*amount+.065f*land+.085f*dash+.048f*stance+.045f*attack+.045f*hurt;
            hips.position+=root.up*(-crouch+Mathf.Abs(Mathf.Sin(phase))*amount*.025f);
            for(int side=0;side<2;side++) {
                bool right=side==0;Transform thigh=right?rt:lt,shin=right?rs:ls,foot=right?rf:lf;
                Vector3 baseFoot=right?footR:footL;Quaternion neutral=foot.rotation;
                float cycle=Mathf.Repeat(phase/(2*Mathf.PI)+side*.5f,1f), stanceTime=Mathf.Lerp(.62f,.48f,run);
                float z,h,angle;
                if(cycle<stanceTime){float u=cycle/stanceTime;z=Mathf.Lerp(reach,-reach,u);h=0;angle=Mathf.Lerp(-12,18,u)*amount;}
                else {float u=(cycle-stanceTime)/(1-stanceTime);z=Mathf.Lerp(-reach,reach,Mathf.SmoothStep(0,1,u));h=Mathf.Sin(u*Mathf.PI)*lift;angle=Mathf.Sin(u*Mathf.PI)*-20*amount;}
                Vector3 target=baseFoot+dir*z+Vector3.up*h;
                target.x+=(right?1:-1)*(.045f*stance+.035f*attack);
                target.z+=(right?-.10f:.12f)*Mathf.Max(stance,attack);
                if(airborne){target=baseFoot+Vector3.forward*(right?-.16f:.15f)+Vector3.up*(right?.20f:.12f);angle=vertical>0?-18:12;}
                if(dash>0){Vector3 dodgeTarget=baseFoot+dir*(right?-.31f:.28f)+Vector3.up*(right?.13f:.04f);target=Vector3.Lerp(target,dodgeTarget,dash);}
                Solve(thigh,shin,foot,root.TransformPoint(target),root.TransformPoint(baseFoot+Vector3.forward*.7f+Vector3.up*.45f));
                foot.rotation=Quaternion.AngleAxis(angle,root.right)*neutral;
            }
        }
        public void BodyMotion(float yaw,float lean,float roll,float headYaw,float headPitch){
            Torso(yaw,lean);if(spine!=null)spine.rotation=Quaternion.AngleAxis(roll,root.forward)*spine.rotation;
            if(head!=null)head.rotation=Quaternion.AngleAxis(headYaw,root.up)*Quaternion.AngleAxis(headPitch,root.right)*head.rotation;
        }
        void Swing(Transform t,float degrees){t.rotation=Quaternion.AngleAxis(degrees,root.right)*t.rotation;}
        public void Torso(float yaw,float lean) {if(spine!=null)spine.rotation=Quaternion.AngleAxis(yaw*.45f,root.up)*Quaternion.AngleAxis(lean,root.right)*spine.rotation;if(chest!=null)chest.rotation=Quaternion.AngleAxis(yaw*.55f,root.up)*chest.rotation;}
        void Solve(Transform upper,Transform lower,Transform hand,Vector3 target,Vector3 pole) {
            Vector3 start=upper.position;float a=Vector3.Distance(start,lower.position),b=Vector3.Distance(lower.position,hand.position);
            Vector3 delta=target-start;float distance=Mathf.Clamp(delta.magnitude,Mathf.Abs(a-b)+.001f,a+b-.002f);Vector3 d=delta.sqrMagnitude>.00001f?delta.normalized:-root.up;
            Vector3 side=Vector3.ProjectOnPlane(pole-start,d).normalized;if(side.sqrMagnitude<.001f)side=Vector3.ProjectOnPlane(root.forward,d).normalized;if(side.sqrMagnitude<.001f)side=root.right;
            float x=(a*a+distance*distance-b*b)/(2*distance);float y=Mathf.Sqrt(Mathf.Max(0,a*a-x*x));Vector3 elbow=start+d*x+side*y;
            upper.rotation=Quaternion.FromToRotation(lower.position-upper.position,elbow-upper.position)*upper.rotation;
            Vector3 end=start+d*distance;lower.rotation=Quaternion.FromToRotation(hand.position-lower.position,end-lower.position)*lower.rotation;
        }
        public Vector3 Arm(bool right,Vector3 gripLocal,Vector3 bladeLocal,bool holding,float grip=1f) {
            Transform u=right?ru:lu,l=right?rl:ll,h=right?rh:lh;
            Vector3 p=root.TransformPoint(gripLocal);Vector3 blade=root.TransformDirection(bladeLocal.normalized);
            Vector3 palmDirection=Vector3.ProjectOnPlane(root.forward*.65f-root.up*.35f,blade).normalized;
            if(palmDirection.sqrMagnitude<.01f)palmDirection=Vector3.ProjectOnPlane(root.right*(right?1:-1),blade).normalized;
            if(palmDirection.sqrMagnitude<.01f)palmDirection=Vector3.ProjectOnPlane(root.up,blade).normalized;
            float palm=right?palmR:palmL;
            Vector3 wrist=holding?p-palmDirection*palm:p;
            Vector3 pole=root.TransformPoint(new Vector3(right?.58f:-.58f,1.02f,-.12f));
            Solve(u,l,h,wrist,pole);
            if(holding)h.rotation=Quaternion.LookRotation(palmDirection,blade)*Quaternion.Inverse(right?handBasisR:handBasisL);
            foreach(var f in fingers)if(f.right==right) f.t.localRotation=rest[f.t]*Quaternion.AngleAxis(f.bend*grip,f.axis);
            return holding?h.position+palmDirection*palm:h.position;
        }
    }
}
